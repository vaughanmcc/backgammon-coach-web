import random, textwrap, time, sys, os, math, json, array, collections, asyncio, re
import pygame
import importlib
try:   # smooth (anti-aliased) shapes on desktop. The web build of pygame has no gfxdraw: UI.poly/circle/ring fall back.
    gfx = importlib.import_module("pygame.gfxdraw")   # imported by name so the web packager doesn't try to download it
except ImportError:
    gfx = None

# --- CONFIGURATION (logical 1000x650 layout; scaled up on high-DPI screens) ---
WIDTH, HEIGHT = 1000, 650
HEADER_H, FRAME = 60, 22                    # two-row header; wooden frame (point numbers and bear-off trays sit on it)
FIELD_X, FIELD_Y = 8 + FRAME, HEADER_H + FRAME
PT_W, BAR_W, FIELD_H = 74, 44, 406
BAR_X = FIELD_X + 6*PT_W                    # bar sits exactly between point 6/7 and 18/19
FIELD_R = BAR_X + BAR_W + 6*PT_W
CHIP_R, CHIP_STEP, TRI_H = 16, 34, 175
MSG_WRAP, MSG_FONT_SIZE = 95, 18

# Colors
COLOR_BOARD, COLOR_BAR, COLOR_BG = (28, 96, 52), (70, 44, 24), (20, 20, 20)
COLOR_FRAME, COLOR_FRAME_EDGE, COLOR_NUM = (104, 66, 36), (52, 32, 16), (232, 212, 172)
COLOR_PT_A, COLOR_PT_B = (226, 208, 168), (156, 64, 46)
COLOR_WHITE, COLOR_BLACK, COLOR_TEXT = (245, 245, 245), (40, 40, 40), (255, 255, 255)
COLOR_HINT_SRC, COLOR_HINT_DST = (0, 255, 255), (255, 0, 255)
COLOR_OPP_ARROW = (255, 150, 40)            # the opponent's last moves (Show opponent's moves ON)
COLOR_FORCED_ARROW = (90, 220, 120)         # forced moves the game played for you (coach on HINTS)
COLOR_TARGET = (60, 220, 90)                # coach on HINTS: where the checker you picked up can go
COLOR_INVALID = (220, 30, 30)
COLOR_ADVICE = (255, 255, 0)

# Board model: index 0-23 = points 1-24, + White (player), - Black. White moves high -> low.
START_POS = {0:-2, 11:-5, 16:-3, 18:-5, 23:2, 12:5, 7:3, 5:5}
MAX_STACK = 5  # Egyptian rule: max 5 checkers of one colour on a point (set_rules('standard') lifts the limit)

def set_rules(rules):
    """'egyptian' (max 5 checkers on a point) or 'standard' (no limit). Affects both players and the coach."""
    global MAX_STACK
    MAX_STACK = 5 if rules == 'egyptian' else 15

def egyptian(): return MAX_STACK == 5

# Strategies: standard opening plays for all 21 rolls: (name, the idea behind it, moves as (src, dst) indices = point - 1)
STRATEGY_MAP = {
    (2, 1): ("Slot the 5-point", "13/11 brings a checker closer to home, and 6/5 puts one on your 5-point, hoping to add a second next turn to make it safe.", [(12, 10), (5, 4)]),
    (3, 1): ("Make the 5-point", "Makes your 5-point safe straight away, the best possible start.", [(7, 4), (5, 4)]),
    (4, 1): ("Split and build", "24/23 moves one back checker so they can find a safe spot more easily; 13/9 brings a checker closer to help build points.", [(23, 22), (12, 8)]),
    (5, 1): ("Split and come down", "13/8 brings a checker home safely; 24/23 moves one back checker so they can find a safe spot more easily.", [(23, 22), (12, 7)]),
    (6, 1): ("Make the bar point", "Makes your bar point (7) safe, starting a wall that traps the opponent's back checkers.", [(12, 6), (7, 6)]),
    (3, 2): ("Split and build", "24/21 heads for a safe spot in the opponent's home board; 13/11 brings a checker closer to help build your home board.", [(23, 20), (12, 10)]),
    (4, 2): ("Strong 4", "Makes your 4-point safe, a strong point in your home board.", [(7, 3), (5, 3)]),
    (5, 2): ("Two builders down", "Brings two checkers closer to home, ready to make your 5-point or bar point (7) next turn.", [(12, 7), (12, 10)]),
    (6, 2): ("Split and build", "24/18 grabs the opponent's bar point (18); 13/11 brings a checker closer to home.", [(23, 17), (12, 10)]),
    (4, 3): ("Split and build", "24/20 heads for the best safe spot in the opponent's home board; 13/10 brings a checker closer to home.", [(23, 19), (12, 9)]),
    (5, 3): ("Make the 3-point", "Makes your 3-point safe, adding to your home board.", [(7, 2), (5, 2)]),
    (6, 3): ("Split and build", "24/18 grabs the opponent's bar point (18); 13/10 brings a checker closer to home.", [(23, 17), (12, 9)]),
    (5, 4): ("Split and come down", "24/20 heads for the best safe spot in the opponent's home board; 13/8 brings a checker home safely.", [(23, 19), (12, 7)]),
    (6, 4): ("Make the 2-point", "Makes your 2-point safe. It is deep in your home board, but better than leaving checkers alone.", [(7, 1), (5, 1)]),
    (6, 5): ("Split and come down", "The usual 24/13 run isn't allowed (only 5 checkers per point), so 24/18 moves a back checker up and 13/8 brings one home safely.", [(23, 17), (12, 7)]),
    (1, 1): ("Double 1s", "Makes your bar point (7) and 5-point safe, a powerful start.", [(7, 6), (7, 6), (5, 4), (5, 4)]),
    (2, 2): ("Double 2s", "Makes your 11-point and 4-point safe.", [(12, 10), (12, 10), (5, 3), (5, 3)]),
    (3, 3): ("Double 3s", "Makes your 10-point and 5-point safe.", [(12, 9), (12, 9), (7, 4), (7, 4)]),
    (4, 4): ("Double 4s", "Makes point 20 safe (the best spot to hold in the opponent's home board) and your 9-point.", [(23, 19), (23, 19), (12, 8), (12, 8)]),
    (5, 5): ("Double 5s", "Makes your 3-point safe with two checkers from your midpoint (13).", [(12, 7), (12, 7), (7, 2), (7, 2)]),
    (6, 6): ("Double 6s", "Makes both bar points safe: yours (7) and the opponent's (18).", [(23, 17), (23, 17), (12, 6), (12, 6)]),
}
BOOK_65_STANDARD = ("Lover's leap", "24/13 runs a back checker all the way to safety on your midpoint (13).", [(23, 17), (17, 12)])

def book_for(key):
    """The opening book entry for a roll under the current rules (6-5 differs: 24/13 needs a 6th checker on 13)."""
    return BOOK_65_STANDARD if key == (6, 5) and not egyptian() else STRATEGY_MAP[key]

# --- PURE GAME LOGIC (no pygame calls, testable without a window) ---
# A position is the 24-point board, optionally followed by [White bar, Black bar, White off, Black off] counts.
# Every rule is written for White (moving 24 -> 1); Black's moves are worked out on mirror(position).
BAR, OFF = 24, -1                            # move source 'from the bar' / move destination 'borne off'
W_BAR, B_BAR, W_OFF, B_OFF = 24, 25, 26, 27  # the extra slots of a full position

def start_board():
    b = [0]*24
    for p, v in START_POS.items(): b[p] = v
    return b

def full(board):
    return list(board) + [0, 0, 0, 0] if len(board) == 24 else list(board)

def mirror(pos):
    """The position from Black's side: Black becomes 'White' moving 24 -> 1, so all the White logic plays Black too.
    Point i <-> 23 - i; a mirrored move's BAR/OFF are Black's bar/off."""
    p = full(pos)
    return [-p[23 - i] for i in range(24)] + [p[B_BAR], p[W_BAR], p[B_OFF], p[W_OFF]]

def all_home(p):
    return p[W_BAR] == 0 and all(v <= 0 for v in p[6:24])

def without(dice, die):
    rest = list(dice); rest.remove(die)
    return rest

def die_for(board, dice, s, d):
    """The die that plays s->d, or None. Bearing off takes the exact die, or a bigger one only if no checker is on a higher point."""
    p = full(board)
    if d != OFF: return s - d if (s - d) in dice else None
    need = s + 1
    if need in dice: return need
    if any(p[i] > 0 for i in range(s + 1, 6)): return None
    bigger = [x for x in dice if x > need]
    return min(bigger) if bigger else None

def move_str(board, s, d):
    src = "bar" if s == BAR else str(s + 1)
    if d == OFF: return f"{src}/off"
    return f"{src}/{d+1}" + ("*" if board[d] == -1 else "")

def blots(board):
    return {i for i in range(24) if board[i] == 1}

def apply_move(board, s, d):
    """White plays s->d. A hit blot goes to Black's bar (kept only when board is a full position)."""
    p = full(board)
    if s == BAR: p[W_BAR] -= 1
    else: p[s] -= 1
    if d == OFF: p[W_OFF] += 1
    else:
        if p[d] == -1: p[d] = 0; p[B_BAR] += 1
        p[d] += 1
    return p[:24] if len(board) == 24 else p

def why_illegal(board, dice, s, d):
    """Return a reason string if White can't play s->d with these dice, else None (the 'use all dice' rule is separate)."""
    p = full(board)
    if not dice: return "Roll the dice first (press SPACE)."
    if s != BAR and p[W_BAR] > 0:
        n = p[W_BAR]
        return (f"You have {'a checker' if n == 1 else f'{n} checkers'} on the bar: {'it' if n == 1 else 'they'} must come back in "
                f"on points 19-24 before anything else can move.")
    if s == BAR:
        if p[W_BAR] <= 0: return "You have no checkers on the bar."
        if d == OFF or d < 18: return "From the bar you come back in on the opponent's home board, points 19-24."
    elif not 0 <= s <= 23 or p[s] <= 0: return f"Point {s+1} has none of your checkers."
    if d != OFF and d >= s: return "Your checkers move toward point 1; you can't move backwards."
    if d == OFF:
        if not all_home(p): return "You can only take checkers off (bear off) once all 15 of yours are in your home board (points 1-6)."
        if die_for(p, dice, s, d) is None:
            if any(x > s + 1 for x in dice): return f"To take a checker off from {s+1} with a bigger die, first move the checkers on higher points."
            return f"Taking a checker off from {s+1} needs a {s+1} or higher, but your dice are {', '.join(map(str, dice))}."
        return None
    if (s - d) not in dice:
        if s == BAR: return f"Coming in on {d+1} needs a {s-d}, but your dice are {', '.join(map(str, dice))}."
        return f"{s+1}/{d+1} is a move of {s-d}, but your dice are {', '.join(map(str, dice))}."
    if p[d] <= -2: return f"Point {d+1} is blocked: the opponent has {-p[d]} checkers there."
    if p[d] >= MAX_STACK: return f"Point {d+1} already has {MAX_STACK} of your checkers (Egyptian rule: max {MAX_STACK})."
    return None

def legal_moves(board, dice):
    """All legal (src, dst, die) for White, one per distinct die value and source; only the bar while White has checkers there."""
    p = full(board)
    srcs = [BAR] if p[W_BAR] > 0 else [s for s in range(23, -1, -1) if p[s] > 0]
    out = []
    for die in sorted(set(dice), reverse=True):
        for s in srcs:
            d = s - die if s - die >= 0 else OFF
            if why_illegal(p, [die], s, d) is None: out.append((s, d, die))
    return out

def max_usable(board, dice, memo):
    key = (tuple(board), tuple(sorted(dice)))
    if key not in memo:
        memo[key] = max((1 + max_usable(apply_move(board, s, d), without(dice, die), memo)
                         for s, d, die in legal_moves(board, dice)), default=0)
    return memo[key]

def allowed_moves(board, dice):
    """Legal first moves under the full rules: use as many dice as possible, and if only one die can be played, the larger."""
    memo = {}
    best = max_usable(board, dice, memo)
    ok = [m for m in legal_moves(board, dice) if 1 + max_usable(apply_move(board, m[0], m[1]), without(dice, m[2]), memo) == best]
    if best == 1 and len(set(dice)) > 1 and ok:
        top = max(m[2] for m in ok)
        ok = [m for m in ok if m[2] == top]
    return ok

def combined_path(board, dice, s, target, prefer=()):
    """One checker from s to target (a point or OFF) using several dice in a row, e.g. 13/9/8 with 4-1:
    the shortest list of (src, dst) hops, each allowed by the rules at its turn, or None.
    Among equal routes: the one the coach's plan `prefer` uses, else the one hitting fewest blots on the way."""
    routes = []   # (hops, blots hit on the way)
    def go(b, dice, cur, path, hit):
        if path and cur == target: routes.append((path, hit)); return
        if cur == OFF: return
        for src, dst, die in allowed_moves(b, dice):
            if src == cur and (dst != OFF or target == OFF):
                passing_hit = dst != OFF and dst != target and b[dst] == -1
                go(apply_move(b, src, dst), without(dice, die), dst, path + [(src, dst)], hit + passing_hit)
    go(list(board), list(dice), s, [], 0)
    if not routes: return None
    shortest = min(len(r) for r, _ in routes)
    return min(((r, h) for r, h in routes if len(r) == shortest), key=lambda rh: (not all(m in prefer for m in rh[0]), rh[1]))[0]

def reachable(board, dice, s):
    """Every point (or OFF) the checker on s can reach this turn, with one die or several in a row (13/8 with 3 and 2)."""
    out = set()
    def go(b, dice, cur):
        for src, dst, die in allowed_moves(b, dice):
            if src == cur and dst not in out:
                out.add(dst)
                if dst != OFF: go(apply_move(b, src, dst), without(dice, die), dst)
    go(list(board), list(dice), s)
    return out

def is_race(board):
    """No contact left: every one of your checkers is past every one of the opponent's (nothing on the bar)."""
    p = full(board)
    if p[W_BAR] or p[B_BAR]: return False
    mine, theirs = [i for i in range(24) if p[i] > 0], [i for i in range(24) if p[i] < 0]
    return not mine or not theirs or max(mine) < min(theirs)

def rule_reason(board, dice):
    """Why a move that is otherwise legal breaks the 'use as many dice as possible' rule."""
    ok = allowed_moves(board, dice)
    if ok and max_usable(board, dice, {}) == 1 and len(set(dice)) > 1:
        return f"Only one of your dice can be played this turn, so the rules say you must play the larger one ({ok[0][2]})."
    return "You must use as many of your dice as possible, and that move would leave a die you can't play."

def point_name(i, opp=False):
    """Plain-English name of point index i ('your 5-point', 'your bar point (7)', 'point 20 in the opponent's home board').
    opp=True: i is on the mirrored board, so the point is named for the opponent, in your point numbers."""
    p = i + 1
    if opp:
        q = 24 - i   # the number you see on the board
        if p <= 6: return f"point {q} in its home board"
        if p == 7: return f"its bar point ({q})"
        if p >= 19: return f"point {q} in your home board"
        return f"point {q}"
    if p == 7: return "your bar point (7)"
    if p == 13: return "your midpoint (13)"
    if p == 18: return "the opponent's bar point (18)"
    if p >= 19: return f"point {p} in the opponent's home board"
    if p >= 14: return f"point {p}"
    return f"your {p}-point"

POINT_VALUE = {5: 10, 7: 9, 4: 8, 20: 7, 21: 7, 6: 6, 3: 5, 18: 5, 8: 4, 9: 4, 2: 3, 19: 3, 22: 3, 10: 2, 11: 2}

def point_role(i):
    """Why holding point index i matters."""
    p = i + 1
    if p == 5: return "the most valuable point in your home board"
    if p == 7: return "it blocks the opponent's back checkers from escaping"
    if p == 4: return "a strong point in your home board"
    if p in (20, 21): return "the best safe spot to hold in the opponent's home board"
    if p >= 19: return "a safe spot for your back checkers"
    if p == 18: return "it blocks the opponent's escape route"
    if p <= 6: return "your home board gets harder to come back into after being hit"
    if p <= 12: return "a safe stepping stone on the way home"
    return "a safe point in the middle of the board"

def for_opp(text):
    """Turn a sentence about you into one about the opponent (its moves are worked out on the mirrored board)."""
    text = text.replace("the opponent's", "\0").replace("the opponent", "\1")
    text = text.replace("your", "its").replace("Your", "Its").replace(" you ", " it ")
    return text.replace("\0", "your").replace("\1", "you")

def join_words(xs):
    xs = list(xs)
    return xs[0] if len(xs) == 1 else ", ".join(xs[:-1]) + " and " + xs[-1]

def join_pts(xs):
    return join_words(str(x + 1) for x in xs)

def cap(s): return s[:1].upper() + s[1:]

def hit_risk(board):
    """Looking one roll ahead: (rolls, pips) - how many of the opponent's 36 rolls hit one of your lone checkers, and
    how many pips that costs you on average per roll. A checker hit on your p-point goes back to the start (25), so it
    loses 25 - p pips; when a roll can hit more than one, the most costly. Black moves toward point 24; points with
    2+ White checkers block it; checkers on its bar must come in first."""
    p = full(board)
    targets = blots(p)
    if not targets: return 0, 0.0
    blacks = [j for j in range(24) if p[j] < 0]
    rolls = lost = 0
    for d1 in range(1, 7):
        for d2 in range(1, 7):
            orders = [[d1] * 4] if d1 == d2 else [[d1, d2], [d2, d1]]
            hit = set().union(*(roll_hits(p, targets, blacks, seq) for seq in orders))
            if hit: rolls += 1; lost += max(24 - i for i in hit)
    return rolls, lost / 36

def hit_rolls(board):
    """How many of the opponent's 36 rolls could hit at least one White blot."""
    return hit_risk(board)[0]

def roll_hits(p, targets, blacks, seq):
    """The White blots Black can hit playing dice `seq` in this order (a set; empty if none). Bar checkers enter first
    (on point die), then one checker - any of them, including one that just came in - uses the dice that are left."""
    froms, bar, hit = list(blacks), p[B_BAR], set()
    while bar and seq:
        entry = seq[0] - 1
        if p[entry] >= 2: return hit     # this die can't bring it in (the other order is tried separately)
        if entry in targets: hit.add(entry)
        froms.append(entry); bar -= 1; seq = seq[1:]
    if bar: return hit                   # still stuck on the bar: nothing else may move
    for j in froms:
        pos = j
        for st in seq:
            pos += st
            if pos > 23 or p[pos] >= 2: break
            if pos in targets: hit.add(pos)
    return hit

def hit_chance(n, many):
    """n of the 36 possible rolls hit one of the lone checkers: as words."""
    if not n: return "no roll can hit " + ("them" if many else "it")
    return f"{round(100 * n / 36)}% chance {'one of them' if many else 'it'} gets hit ({n} of 36 rolls)"

def blot_text(b0, b1, compact=False, opp=False):
    """The lone checkers (blots) a play leaves, and how likely the other side is to hit one next turn."""
    num = (lambda i: 24 - i) if opp else (lambda i: i + 1)
    left = sorted(blots(b1))
    if not left:
        n0 = len(blots(b0))
        return "leaves no lone checkers to be hit" + (f" (covers {'the lone one' if n0 == 1 else f'all {n0} lone ones'})" if n0 and not compact else "")
    (n, lost), many = hit_risk(b1), len(left) > 1
    if compact: return f"leaves {len(left)} lone checker{'s' if many else ''} ({round(100 * n / 36)}% chance of a hit)"
    cost = f"; a hit would cost you about {round(lost * 36 / n)} pips" if n else ""
    return (f"leaves {'a lone checker' if not many else f'{len(left)} lone checkers'} on {join_words(str(num(i)) for i in left)}: "
            + hit_chance(n, many) + (cost.replace("you", "it") if opp else cost))

def longest_run(b):
    best = run = 0
    for v in b[:24]:
        run = run + 1 if v >= 2 else 0
        best = max(best, run)
    return best

def describe_move(board, s, d, with_move=True):
    after = apply_move(board, s, d)
    parts = []
    if s == BAR: parts.append("brings a checker back in from the bar")
    if d == OFF: parts.append(f"takes a checker off from {s+1}")
    elif board[d] == -1: parts.append(f"hits the opponent's lone checker on {d+1}, sending it to the bar")
    if d != OFF and board[d] >= 2: parts.append(f"adds a checker to {point_name(d)} (now {after[d]} there"
                                                 + (", more than it needs)" if after[d] > 5 else ")"))
    elif d != OFF and board[d] == 1: parts.append(f"makes {point_name(d)} safe by joining your lone checker there")
    b0, b1 = blots(board), blots(after)
    new, gone = sorted(b1 - b0), sorted(b0 - b1)
    pts = lambda xs: join_words(str(x+1) for x in xs)
    lone = lambda xs: "a lone checker" if len(xs) == 1 else "lone checkers"
    if d == OFF or s == BAR:
        if new: parts.append(f"leaves {lone(new)} on {pts(new)}")
        elif gone: parts.append(f"cuts your lone checkers from {len(b0)} to {len(b1)}")
    elif new and gone and board[s] == 1 and after[d] == 1:
        parts.append(f"moves your lone checker from {s+1} to {d+1} (it is still on its own)")
    elif new and board[d] == 1:  # the 'makes ... safe by joining' clause already says the checker on d is covered
        parts.append(f"but leaves {lone(new)} behind on {pts(new)}")
    elif new and gone:
        parts.append(f"covers your lone checker on {pts(gone)} but leaves a new one on {pts(new)}")
    elif new:
        parts.append(f"leaves {lone(new)} on {pts(new)} that can be hit")
    elif gone:
        parts.append(f"cuts your lone checkers from {len(b0)} to {len(b1)}")
    else:
        parts.append("leaves no new lone checkers" if not b0 else f"no change to your lone checkers ({len(b0)})")
    return (f"{move_str(board, s, d)} " if with_move else "") + ", ".join(parts)

Outcome = collections.namedtuple("Outcome", "hits off back gain made value safety cover spread strengthened rear")

def opponent_pips(p):
    return sum((24 - i) * -v for i, v in enumerate(p[:24]) if v < 0) + 25 * p[B_BAR]

def stragglers(p):
    """White checkers still on the bar or in the opponent's home board (points 19-24)."""
    return p[W_BAR] + sum(v for v in p[18:24] if v > 0)

def race_is_on(p):
    """The opponent is well advanced (90 pips or less, or already bearing off): time to bring your back checkers home."""
    return p[B_OFF] > 0 or opponent_pips(p) <= 90

# --- The doubling cube (MENU > Doubling cube) ---
DOUBLE_POINT, TAKE_POINT, CUBE_MAX = 0.68, 0.25, 64   # double from about 68% to win; take while still winning 25%

def phi(z): return 0.5 * (1 + math.erf(z / math.sqrt(2)))   # the normal curve: chance of a result below z

def trapping_prime(p):
    """The longest run of White points (2+ checkers) with a Black checker behind it, which it must get past."""
    lo = -1 if p[B_BAR] else min((j for j in range(24) if p[j] < 0), default=24)
    best = run = 0
    for i in range(lo + 1, 24):
        run = run + 1 if p[i] >= 2 else 0
        best = max(best, run)
    return best

def contact_edge(p, on_roll):
    """White's extras in pips once there is contact: the opponent on the bar against White's home board, a prime in
    front of its checkers, and the shots White has at its lone checkers (worth less before White's own roll)."""
    home = sum(1 for i in range(6) if p[i] >= 2)
    edge = p[B_BAR] * (6 + 5 * home)
    run = trapping_prime(p)
    if run >= 4: edge += 6 * (run - 3)
    return edge + hit_risk(mirror(p))[1] * (1.0 if on_roll else 0.5)

def win_chance(pos):
    """A rough chance that White, about to roll, wins the game. In a race: the Kleinman count, a well-tested
    formula on the two pip counts. With contact the same formula, with pips added for checkers on the bar, a prime
    and shots at lone checkers, and more uncertainty: a guide, not an exact figure."""
    p = full(pos)
    mine = sum((i + 1) * v for i, v in enumerate(p[:24]) if v > 0) + 25 * p[W_BAR]
    theirs = opponent_pips(p)
    if p[W_OFF] >= 15 or not mine: return 1.0
    if p[B_OFF] >= 15 or not theirs: return 0.0
    lead, spread = theirs - mine, math.sqrt(2 * max(mine + theirs - 4, 1))
    if is_race(p): return phi((lead + 4) / spread)   # +4: being on roll is worth about half a roll
    lead += contact_edge(p, True) - contact_edge(mirror(p), False)
    return min(0.98, max(0.02, phi((lead + 4) / (1.3 * spread))))

def chance_text(p, only=False):
    """A winning chance in words: 'about 35%' ('only about 18%'), 'less than 1%', 'more than 99%'."""
    if p < 0.005: return "less than 1%"
    if p > 0.995: return "more than 99%"
    return f"{'only ' if only else ''}about {round(100 * p)}%"

def cube_advice(act, p, name="you"):
    """The coach before a cube decision: act 'double' (p = the chance of whoever may double; '' unless it's a good
    time) or 'answer' (p = the chance of whoever must take or pass)."""
    are, pc = ("are" if name == "you" else "is"), chance_text(p)
    if act == 'double':
        return f"Coach: {name} {are} {pc} to win - a good time to double (before rolling)." if p >= DOUBLE_POINT else ""
    return f"Coach: {name} {are} {pc} to win - {'take' if p >= TAKE_POINT else 'pass'} (take from about {round(100 * TAKE_POINT)}%)."

def cube_verdict(act, p, name="you"):
    """The coach after a cube decision: (text, good). act 'double': p = the doubler's chance; 'take' / 'pass': the
    chance of whoever answered."""
    was, pc, dp, tp = ("were" if name == "you" else "was"), chance_text(p), round(100 * DOUBLE_POINT), round(100 * TAKE_POINT)
    only = chance_text(p, only=True)
    if act == 'double':
        if p >= DOUBLE_POINT: return f"Good double: {name} {was} {pc} to win (doubling is usually right from about {dp}%).", True
        return f"Early double: {name} {was} {only} to win - doubling is usually right from about {dp}%.", False
    if act == 'take':
        if p >= TAKE_POINT: return f"Good take: {name} {was} {pc} to win, and taking is right from about {tp}%.", True
        return f"Risky take: {name} {was} {only} to win - below about {tp}%, passing loses less.", False
    if p < TAKE_POINT: return f"Good pass: {name} {was} {only} to win.", True
    return f"Passed too soon: {name} {was} {pc} to win - from about {tp}% it's worth taking.", False

CUBE_HELP = [
    "The doubling cube raises the stakes. A game starts worth 1 point, with the cube in the middle of the bar showing "
    "64 (a cube has no 1).",
    "Doubling: on your turn, before you roll, you may double - tap DOUBLE (or the cube; D on the laptop). The other "
    "side then chooses:",
    "  TAKE: play on for twice the points. The taker now owns the cube (it moves to their side) and is the only one "
    "who may double next, to 4. Redoubles go 4, 8, 16, ...",
    "  PASS: give up at once and lose what the game was worth before the double.",
    "Gammons (2) and backgammons (3) are multiplied by the cube: a gammon with the cube on 4 wins 8 points.",
    "When to double: when you are about 68-70% to win. Earlier gives the opponent a cheap cube; much later and it "
    "will simply pass. If you are so far ahead that you'd probably win a gammon, play on without doubling instead.",
    "When to take: if you still win at least 25% of the time. Passing loses 1 point for sure; taking loses 2 when you "
    "lose but wins 2 when you win - at 25% the two come out the same.",
    "In a race (no contact), count the pips: lead by 8% or more of your count and double; 9% to redouble; with 12% or "
    "more the opponent should pass (the 8-9-12 rule).",
    "The coach gives its winning chances as a rough estimate - good in a race, a guide when checkers can still be hit. "
    "With the cube on, your dice don't roll by themselves while you could double.",
]

def dice_line(name, s):
    """One side's dice: s = [rolls, doubles, pips, checkers sent to the bar]."""
    rolls, doubles, pips, hits = s
    if not rolls: return f"{name}: no rolls yet."
    return (f"{name}: {rolls} roll{'s' if rolls != 1 else ''}, {doubles} double{'s' if doubles != 1 else ''} "
            f"({round(100 * doubles / rolls)}%), {pips / rolls:.1f} pips a roll, hit {hits} checker{'s' if hits != 1 else ''}.")

def luck_text(a, b, names):
    """Who has rolled better and whether it's more than the usual ups and downs (a roll's pips vary by 4.3)."""
    if min(a[0], b[0]) < 10: return "Too few rolls yet to judge the luck."
    diff = a[2] / a[0] - b[2] / b[0]
    z = diff / (4.3 * math.sqrt(1 / a[0] + 1 / b[0]))
    if abs(z) < 1: return f"{names[0]} and {names[1]} have rolled about the same - normal for fair dice."
    ahead = names[0] if diff > 0 else names[1]
    size = ("normal ups and downs for this many rolls" if abs(z) < 2 else "a lucky run, but one that fair dice give now and then"
            if abs(z) < 3 else "an unusually big gap")
    return f"{ahead} rolled {abs(diff):.1f} pips a roll more - {size}."

def dice_stats_text(game):
    """MENU > Dice statistics: this game, and (against the computer) all your games, compared with fair dice."""
    names = ("White", "Black") if game.two_player else ("You", "Opponent")
    you, opp = game.dice_game
    lines = ["This game:", dice_line(names[0], you), dice_line(names[1], opp)]
    if not game.two_player:
        total = [[x + (0 if game.dice_folded else y) for x, y in zip(game.dice_done[i], game.dice_game[i])] for i in (0, 1)]
        lines += ["", "All your games against the computer:", dice_line("You", total[0]), dice_line("Opponent", total[1]),
                  luck_text(total[0], total[1], ("You", "the opponent"))]
    else: lines.append(luck_text(you, opp, names))
    lines += ["", "Fair dice: 1 roll in 6 is a double (17%), and a roll averages 8.17 pips (doubles count 4 times). "
              "The dice come from the computer's random number generator; nothing looks at the board or who is rolling."]
    return lines

def other_numbers(text):
    """Moves written in one player's point numbers ('13/8*') in the other player's (two players: '12/17*')."""
    return re.sub(r"\d+", lambda m: str(25 - int(m.group())), text)

def turn_outcome(b0, b1):
    """Whole-turn score from b0 to b1, in the coach's priority order. Compared as a tuple, so field order is priority:
    hits > checkers borne off > (late in the game) fewer checkers left back > gain: how valuable the new points are,
    plus the pips your hits cost the opponent, less the pips you can expect to lose to a hit next roll (looking at all
    36 of the opponent's rolls), in whole pips
    > new points made > fewest blots left (safety) > fewest rolls that hit them (cover) > points strengthened
    > rear checkers moved up."""
    p0, p1 = full(b0), full(b1)
    hits = sum(1 for i in range(24) if b0[i] == -1 and b1[i] >= 0)
    if all_home(p0): hits = 0   # bearing off: a hit only counts for the pips it costs the opponent (in gain), not first
    made = [i for i in range(24) if b1[i] >= 2 and b0[i] < 2]
    value = sum(POINT_VALUE.get(i + 1, 1) for i in made)
    strengthened = sum(1 for i in range(24) if b1[i] > b0[i] >= 2)
    rear = -sum((i + 1) ** 2 * v for i, v in enumerate(b1[:24]) if v > 0) - 625 * p1[W_BAR]
    back = -stragglers(p1) if race_is_on(p0) else 0
    spread = -sum(v - 5 for v in b1[:24] if v > 5)   # standard rules: checkers piled past 5 on a point do little work
    rolls, lost = hit_risk(b1)
    sent_back = sum(i + 1 for i in range(24) if b0[i] == -1 and b1[i] >= 0)   # pips your hits cost the opponent
    return Outcome(hits, p1[W_OFF] - p0[W_OFF], back, round(value + sent_back - lost), len(made), value, -len(blots(b1)), -rolls,
                   spread, strengthened, rear)

def describe_outcome(b0, b1, detail=False, compact=False, opp=False):
    """What a turn achieved. detail=True adds why the new points matter and any wall; compact shortens the lone-checker
    part. opp=True: b0/b1 are the mirrored board, described as the opponent's play in your point numbers."""
    w = for_opp if opp else (lambda s: s)
    num = (lambda i: 24 - i) if opp else (lambda i: i + 1)
    parts = []
    p0, p1 = full(b0), full(b1)
    hit = [i for i in range(24) if b0[i] == -1 and b1[i] >= 0]
    made = [i for i in range(24) if b1[i] >= 2 and b0[i] < 2]
    strong = [i for i in range(24) if b1[i] > b0[i] >= 2]
    entered, off = p0[W_BAR] - p1[W_BAR], p1[W_OFF] - p0[W_OFF]
    if entered: parts.append(w(f"brings {'your checker' if entered == 1 else f'{entered} checkers'} back in from the bar"))
    if hit: parts.append(w(f"hits the opponent's lone checker{'s' if len(hit) > 1 else ''} on ") + join_words(str(num(i)) for i in hit)
                         + (", sending it back to the start" if detail and len(hit) == 1 else ""))
    if off: parts.append(f"takes {off} checker{'s' if off > 1 else ''} off the board" + (f" ({p1[W_OFF]} of 15 off)" if detail else ""))
    if made:
        best = max(made, key=lambda i: POINT_VALUE.get(i + 1, 1))
        made = sorted(made, key=lambda i: -POINT_VALUE.get(i + 1, 1))   # most valuable first, with its reason next to it
        names = [point_name(i, opp) for i in made]
        why = f" - {w(point_role(best))}" if detail else ""
        parts.append(f"makes {join_words(names)} safe{why}")
    if strong and not made: parts.append(f"adds checkers to {join_words(point_name(i, opp) for i in strong)}")
    run0, run1 = longest_run(b0), longest_run(b1)
    if detail and run1 >= 3 and run1 > run0: parts.append(w(f"gives you {run1} safe points in a row, a wall the opponent must get past"))
    parts.append(blot_text(b0, b1, compact, opp))
    return ". ".join(cap(p) for p in parts) if detail else ", ".join(parts)

def play_plan(board, dice, plan):
    """Board after playing plan in order, or None if any step is illegal at its turn."""
    b, dice = list(board), list(dice)
    for s, d in plan:
        if why_illegal(b, dice, s, d): return None
        dice.remove(die_for(b, dice, s, d)); b = apply_move(b, s, d)
    return b

def plan_text(board, plan):
    """Plan moves as text ('13/8*' marks a hit), played in order from board."""
    b, out = list(board), []
    for s, d in plan: out.append(move_str(b, s, d)); b = apply_move(b, s, d)
    return out

def ranked_plans(board, dice):
    """Every distinct way to play the roll, best first, as (key, final board, plan).
    key = (dice used, *turn_outcome). Tries every order of the dice (moves can depend on earlier ones, e.g. 13/10/5)."""
    finals, seen = {}, set()   # final position -> [(src, dst, die), ...]
    def walk(b, dice, seq):
        key = (tuple(b), tuple(sorted(dice)))
        if key in seen: return
        seen.add(key)
        moves = legal_moves(b, dice)
        if not moves:   # keep the longest route to each final position (e.g. 2/off with the 6 vs 2/1/off using both dice),
            old = finals.get(tuple(b))   # and on a tie the one opening with the larger die (the one-die rule needs it)
            if old is None or len(seq) > len(old) or (len(seq) == len(old) and seq and seq[0][2] > old[0][2]): finals[tuple(b)] = seq
            return
        for s, d, die in sorted(moves, key=lambda m: (m[1] == OFF or b[m[1]] != -1, -m[0])):  # list hits first, then back checkers
            walk(apply_move(b, s, d), without(dice, die), seq + [(s, d, die)])
    walk(list(board), list(dice), [])
    # Only plays the rules allow: as many dice as possible, and if only one die can be played, the larger one
    most = max(len(seq) for seq in finals.values())
    finals = {f: seq for f, seq in finals.items() if len(seq) == most}
    if most == 1 and len(set(dice)) > 1:
        top = max(seq[0][2] for seq in finals.values())
        finals = {f: seq for f, seq in finals.items() if seq[0][2] == top}
    return sorted(((len(seq), *turn_outcome(board, f)), list(f), [(s, d) for s, d, _ in seq]) for f, seq in finals.items())[::-1]

def plan_turn(board, dice):
    """Best plan for the whole roll: list of (src, dst). [] if nothing is legal."""
    return ranked_plans(board, dice)[0][2]

MAIN_KEYS = 1 + Outcome._fields.index("strengthened")   # dice used, then hits ... cover: what 'clearly worse' is judged on

def better_than(start, board, dice, plan):
    """'Better than X, which ...' comparing plan with the best clearly-worse way to play the roll, or ''."""
    end = play_plan(board, dice, plan)
    key = (len(plan), *turn_outcome(board, end))[:MAIN_KEYS]
    alt = next(((k, f, seq) for k, f, seq in ranked_plans(board, dice) if k[:MAIN_KEYS] < key), None)
    if not alt: return ""
    k, alt_end, seq = alt
    a, b = turn_outcome(board, end), turn_outcome(board, alt_end)   # same baseline as the comparison above
    if k[0] < key[0]: why = "which can't use all your dice"
    elif b.hits < a.hits: why = "which misses the chance to hit"
    elif b.off < a.off: why = "which takes fewer checkers off"
    elif b.back < a.back: why = f"which leaves {-b.back} checker{'s' if b.back < -1 else ''} stuck in the opponent's home board"
    elif b.gain < a.gain and b.value >= a.value:
        why = f"which is riskier: it {blot_text(start, alt_end, compact=True)}, costing about {round(hit_risk(alt_end)[1], 1)} pips a roll on average"
    elif b.made < a.made: why = "which makes no new safe point" if b.made == 0 else f"which makes only {b.made} new safe point{'s' if b.made > 1 else ''}"
    elif b.value < a.value: why = "which makes a less useful point safe"
    elif b.safety < a.safety: why = f"which {blot_text(start, alt_end, compact=True)}"
    elif b.cover < a.cover: why = f"which leaves lone checkers that are easier to hit ({round(-100 * b.cover / 36)}% chance)"
    else: why = f"which piles {-b.spread} extra checker{'s' if b.spread < -1 else ''} onto a point that already has plenty"
    return f"Better than {', '.join(plan_text(board, seq))}, {why}."

def coach_key(game):
    """Everything the coach's plan and suggestion depend on. The UI asks for them every frame, so they are cached on it."""
    return (tuple(game.pos), tuple(game.dice), tuple(game.plan or ()), game.plan_kind, game.book_key,
            game.is_rolling, tuple(game.turn_start or ()), MAX_STACK)

def cached(game, name, compute):
    key, cache = coach_key(game), game.__dict__.setdefault('_coach_cache', {})
    if cache.get(name, (None,))[0] != key: cache[name] = (key, compute())
    return cache[name][1]

def opp_play_text(m, seq):
    """The opponent's moves, worked out on the mirrored board m, written in your point numbers ('12/17*')."""
    b, out = list(m), []
    for s, d in seq:
        out.append(("bar" if s == BAR else str(24 - s)) + "/" + ("off" if d == OFF else str(24 - d)) + ("*" if d != OFF and b[d] == -1 else ""))
        b = apply_move(b, s, d)
    return ", ".join(out)

def judge_opp_play(m, plans, pick):
    """(full, short) comment on the opponent's play, judged exactly like yours, from its side of the board (m is
    the mirrored position before its move, plans its ranked_plans, pick the one it chose). ('', '') if it had no move."""
    if not pick[2]: return "", ""
    its = lambda end: describe_outcome(m, end, compact=True, opp=True)
    same, best = 1 + Outcome._fields.index("made"), plans[0]   # dice used, hits, off, back, gain (points less risk)
    if pick[0][:same] >= best[0][:same]:
        return f"Good play by the opponent: it {its(pick[1])}.", "good play"
    a, b = turn_outcome(m, best[1]), turn_outcome(m, pick[1])
    why = ("it missed a chance to hit you" if b.hits < a.hits else "it took fewer checkers off" if b.off < a.off
           else "it left more checkers stuck at the back" if b.back < a.back
           else "it took a bigger risk of being hit" if b.gain < a.gain and b.value >= a.value
           else "it made fewer safe points" if b.made < a.made
           else "it made a less useful point safe" if b.value < a.value else "it left more lone checkers for you to hit")
    better = opp_play_text(m, best[2])
    return (f"The opponent made a mistake: {why}. Its play {its(pick[1])}. {better} was better: it {its(best[1])}.",
            f"a mistake: {better} was better")

MISTAKE_KINDS = {"dice": "not using all the dice", "hit": "missing a hit", "off": "taking fewer checkers off",
                 "back": "leaving checkers stuck at the back", "points": "not making the best point",
                 "risk": "taking too big a risk of being hit", "other": "small differences"}
MISTAKE_TIPS = {"dice": "You must use both dice if you can - look for a play that does.",
                "hit": "Look for hits first: a hit costs the opponent all the pips that checker had travelled.",
                "off": "When bearing off, take a checker off with every die you can.",
                "back": "Once the race is on, bring your back checkers home before they get trapped.",
                "points": "Points in your home board and your bar point (7) matter most - make them when you can.",
                "risk": "Before moving, check where the opponent's checkers can reach, and keep lone checkers out of range - "
                        "especially near your home, where a hit costs you the most.",
                "other": "Compare the arrows in the mistakes list to see what the coach preferred."}

def worse_kind(a, b, fewer_dice=False):
    """Why outcome b falls short of a (both turn_outcome), as a MISTAKE_KINDS key."""
    if fewer_dice: return "dice"
    for field, kind in (("hits", "hit"), ("off", "off"), ("back", "back")):
        if getattr(b, field) < getattr(a, field): return kind
    if b.gain < a.gain: return "points" if b.value < a.value else "risk"
    return "other"

def progress_text(history, game):
    """Lines for MENU > Your progress: games won, coach score per game and its trend, the mistakes you make most."""
    pct = lambda c: round(100 * c[0] / c[1]) if c[1] else None
    lines = []
    if history:
        won = sum(h["won"] for h in history)
        lines.append(f"Games finished: {len(history)}, won {won} ({round(100 * won / len(history))}%).")
    scores = [pct(h["coach"]) for h in history if h["coach"][1]]
    if scores:
        lines.append("Coach score per game, oldest to newest: " + "  ".join(f"{s}%" for s in scores[-10:]))
        if len(scores) >= 6:
            recent, before = sum(scores[-5:]) / 5, sum(scores[:-5]) / len(scores[:-5])
            trend = "improving" if recent > before + 2 else "slipping" if recent < before - 2 else "steady"
            lines.append(f"Last 5 games: {round(recent)}%, before that: {round(before)}% - {trend}.")
    counts = collections.Counter()
    for h in history: counts.update(h["mistakes"])
    counts.update(m["kind"] for m in game.mistakes)
    if counts:
        top = counts.most_common(4)
        lines.append("Your most common mistakes: " + ", ".join(f"{MISTAKE_KINDS[k]} ({n})" for k, n in top) + ".")
        lines.append("Tip: " + MISTAKE_TIPS[top[0][0]])
    if game.game_score[1]:
        m, n = game.game_score
        lines.append(f"This game so far: {m}/{n} moves like the coach ({pct(game.game_score)}%), "
                     f"{len(game.mistakes)} mistake{'' if len(game.mistakes) == 1 else 's'}.")
    return lines or ["Nothing yet. Finish a game with the coach on HINTS or REVIEW and your progress shows here."]

def position(points, bar=(0, 0), off=(0, 0)):
    """A full position from {point number: checkers} (yours positive, the opponent's negative)."""
    b = [0] * 24
    for p, v in points.items(): b[p - 1] = v
    return b + list(bar) + list(off)

# Practice: (title, what to look for, position, roll). Each answer is the coach's best play, checked by hand.
PUZZLES = [
    ("Make the best point", "Which point is worth the most early in the game?",
     position({24: 1, 23: 1, 13: 5, 8: 3, 6: 5, 1: -2, 12: -5, 17: -3, 19: -5}), (3, 1)),
    ("Hit or build?", "Can you do both at once?",
     position({24: 2, 13: 4, 11: 1, 8: 3, 6: 5, 5: -1, 1: -2, 12: -5, 17: -3, 19: -4}), (6, 1)),
    ("Block the back checkers", "Two good points are on offer. Which one hurts the opponent more?",
     position({24: 2, 13: 4, 9: 1, 8: 2, 7: 1, 6: 5, 1: -2, 12: -5, 17: -3, 19: -5}), (2, 1)),
    ("Come in from the bar", "Get your checker back in - and make the opponent pay for its lone checker.",
     position({24: 1, 13: 5, 8: 3, 6: 4, 22: -1, 1: -2, 12: -4, 17: -3, 19: -3, 20: -2}, bar=(1, 0)), (4, 3)),
    ("Run!", "Your last back checker is in danger of being trapped. Can it get to safety?",
     position({24: 1, 13: 4, 8: 4, 6: 5, 4: 1, 1: -2, 12: -4, 17: -2, 19: -3, 20: -2, 21: -2}), (6, 5)),
    ("Bring them home safely", "Everything is nearly home. Which play leaves nothing to hit?",
     position({9: 2, 8: 3, 7: 2, 6: 3, 5: 2, 4: 2, 12: -3, 17: -3, 19: -2, 20: -2, 22: -2, 23: -3}), (5, 3)),
    ("Bear off safely", "The opponent still has a checker on your 1-point. Is hitting it worth the risk?",
     position({6: 2, 5: 3, 3: 2, 2: 1, 1: -1}, off=(7, 14)), (6, 4)),
]

def current_plan(game):
    """The remaining plan for this roll (stored plan if still playable, else a fresh one)."""
    def compute():
        if not game.dice or game.is_rolling: return []
        if game.plan and play_plan(game.pos, game.dice, game.plan) is not None: return list(game.plan)
        return plan_turn(game.pos, game.dice)
    return list(cached(game, 'plan', compute))

def get_sug(game):
    """Coach's next suggestion as (src, dst, die, reason, count) or None. count = how many of this exact move remain in the plan."""
    def compute():
        plan = current_plan(game)
        if not plan: return None
        s, d = plan[0]
        start = game.turn_start or game.pos
        why = describe_outcome(start, play_plan(game.pos, game.dice, plan))
        if game.plan_kind == 'book': why = f"book opening {book_for(game.book_key)[0]}: {why}"
        return (s, d, die_for(game.pos, game.dice, s, d), why, plan.count((s, d)))
    return cached(game, 'sug', compute)

def move_targets(game):
    """Coach on HINTS (shown or hidden): where the checker you picked up can go. Empty when nothing is picked up."""
    if game.selected is None or not game.dice or game.is_rolling or chosen_coach_mode(game) != "hints": return set()
    return cached(game, f"targets{game.selected}", lambda: reachable(game.pos, game.dice, game.selected))

def view_dice(rolled, left):
    """Dice to draw as (value, used): 2 dice, or 4 for doubles, with played ones marked used."""
    if not rolled: return []
    if len(rolled) == 1: return [(rolled[0], False)]   # the opening roll: one die each
    d1, d2 = rolled
    left, out = list(left), []
    for v in ([d1] * 4 if d1 == d2 else [d1, d2]):
        out.append((v, v not in left))
        if v in left: left.remove(v)
    return out

def dice_view(game):
    """White's dice (drawn on the right half)."""
    if game.is_rolling and game.rolling_for == 'white': return [(v, False) for v in game.display_dice]
    return view_dice(game.display_dice, game.dice)

def dice_x(game):
    """Where the dice sit (logical x): (the player to move's, the other side's). White's on the right half, Black's on
    the left - so with two players, Black's own dice are on the left while it moves."""
    right, left = fx((BAR_X + BAR_W + FIELD_R) / 2), fx((FIELD_X + BAR_X) / 2)
    return (left, right) if game.flipped else (right, left)

def die_spots(game):
    """Your dice on the board: (logical centre, value, used) - where they are drawn and tapped."""
    dv, cx, cy = dice_view(game), dice_x(game)[0], FIELD_Y + FIELD_H / 2
    return [((cx + (n - (len(dv) - 1) / 2) * 54, cy), v, used) for n, (v, used) in enumerate(dv)]

# Two players: the engine always moves 'White', so while Black moves its board is turned round (mirror). The screen
# shows the real board throughout: these turn the engine's points and position back the right way round.
def real_pt(game, i):
    """A point of the engine's board as drawn on the screen (and back: it is its own inverse). BAR, OFF, 'bar', 'off'
    and None stay as they are."""
    return 23 - i if game.flipped and type(i) is int and 0 <= i <= 23 else i

def real_view(game):
    """(board, bar, off) the right way round: White positive, [White, Black] on the bar and borne off."""
    if not game.flipped: return game.board, game.bar, game.off
    p = mirror(game.pos)
    return p[:24], p[24:26], p[26:28]

def real_pips(game):
    """(White's pips, Black's pips)."""
    w, b = game.get_pips()
    return (b, w) if game.flipped else (w, b)

def board_pt(game, pos):
    """What a tap at logical pos means to the engine: a point (turned round while Black moves), BAR, OFF (the tray of
    whoever is moving) or None."""
    return real_pt(game, pt_at(pos, 'b' if game.flipped else 'w'))

CUBE_SIZE = 34
def cube_spot(game):
    """The doubling cube on the bar: (logical centre, number shown, offered) or None when the cube is off. In the
    middle while nobody owns it (showing 64), at the owner's end once taken; an offer shows the doubled number."""
    if not (game.cube_on or game.cube > 1): return None
    x, offered = BAR_X + BAR_W / 2, game.cube_offer is not None
    y = {None: FIELD_Y + FIELD_H / 2, 'white': FIELD_Y + FIELD_H - CUBE_SIZE / 2 - 3, 'black': FIELD_Y + CUBE_SIZE / 2 + 3}[
        None if offered else game.cube_owner]
    return (x, y), (game.cube * 2 if offered else (64 if game.cube == 1 else game.cube)), offered

def cube_hit(game, pos):
    c = cube_spot(game)
    return bool(c) and abs(pos[0] - c[0][0]) <= CUBE_SIZE / 2 + 4 and abs(pos[1] - c[0][1]) <= CUBE_SIZE / 2 + 4

def die_at(game, pos):
    """The value of your unplayed die at logical pos, or None."""
    return next((v for (x, y), v, used in die_spots(game) if not used and abs(pos[0] - x) <= 26 and abs(pos[1] - y) <= 26), None)

def starts_label(game):
    return "Who starts: " + ("OPENING ROLL" if game.who_starts == 'rolloff' else "TAKE TURNS")

def cube_action(game):
    """What the HINT button (phones) does for the cube now: 'pass' while a double is on offer (the big button
    is TAKE), 'double' when the player to move may double, else None (it is HINT)."""
    if game.phase == 'cube_offer': return 'pass'
    return 'double' if game.can_double() else None

def undo_label(view):
    return "Undo button: " + ("SHOWN" if view.show_undo else "HIDDEN (no take-backs)")

def play_against(game):
    return "Play against: " + ("A PERSON (2 players)" if game.two_player else "THE COMPUTER")

def opp_dice_view(game):
    """The opponent's dice (drawn on the left half)."""
    if game.is_rolling and game.rolling_for == 'black': return [(v, False) for v in game.opp_display]
    return view_dice(game.opp_display, game.opp_dice)

def arc_ctrl(a, b):
    """Control point for the curved hint arrow / slide path: same-row moves arc toward the middle line."""
    mx, my, cy = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2, FIELD_Y + FIELD_H / 2
    bend = math.copysign(min(abs(cy - my) * 1.7, 0.75 * abs(b[0] - a[0]) + 20), cy - my)  # short hops arc less
    return (mx, my + bend)

def bezier(a, c, b, t):
    return ((1-t)**2 * a[0] + 2*(1-t)*t * c[0] + t*t * b[0], (1-t)**2 * a[1] + 2*(1-t)*t * c[1] + t*t * b[1])

HOME_RIGHT = False   # False: your home board (points 1-6) bottom left; True: bottom right (the board mirrored)
CENTRE_X = (FIELD_X + FIELD_R) / 2   # the middle of the bar: the board is symmetric around it

def set_point_width(w):
    """Point width in logical px: 74 on desktop; narrower on phones, so the board can fill the screen height and
    still leave room for the column beside it (a 20:9 phone is wider than the board, but not by enough)."""
    global PT_W, BAR_X, FIELD_R, CENTRE_X
    PT_W = w
    BAR_X = FIELD_X + 6 * PT_W
    FIELD_R = BAR_X + BAR_W + 6 * PT_W
    CENTRE_X = (FIELD_X + FIELD_R) / 2

def set_home_side(side):
    global HOME_RIGHT
    HOME_RIGHT = side == "right"

def fx(x):
    """Mirror an x position (logical px) when your home board is on the right. Its own inverse."""
    return 2 * CENTRE_X - x if HOME_RIGHT else x

def point_x(i):
    """Left edge of point i (logical px). Home on the left: bottom row 1-12 left->right, top row 24-13.
    Home on the right: the same, mirrored."""
    col = i if i < 12 else 23 - i
    x = FIELD_X + col*PT_W + (BAR_W if col >= 6 else 0)
    return fx(x + PT_W) if HOME_RIGHT else x

def slot_center(i, j, n=0):
    """Centre of the j-th checker (0 = nearest the edge) on point i holding n checkers. Stacks of more than 5
    (standard rules) squeeze together so they stay within the 5-checker height."""
    step = CHIP_STEP if n <= 5 else CHIP_STEP * 4 / (n - 1)
    x = point_x(i) + PT_W/2
    return (x, FIELD_Y + FIELD_H - CHIP_R - 4 - j*step) if i < 12 else (x, FIELD_Y + CHIP_R + 4 + j*step)

def triangle(i):
    x, base = point_x(i), (FIELD_Y + FIELD_H if i < 12 else FIELD_Y)
    return [(x + 1, base), (x + PT_W - 1, base), (x + PT_W/2, base - TRI_H if i < 12 else base + TRI_H)]

BAR_GAP = 26   # bar checkers start this far from the middle: further (44) with the cube on, which sits there

def set_cube_layout(on):
    global BAR_GAP
    BAR_GAP = 44 if on else 26

def bar_slot(colour, j, n=0):
    """Centre of the j-th of n checkers on the bar: White's above the middle, Black's below. More than 5 squeeze together."""
    mid, step = FIELD_Y + FIELD_H / 2, (CHIP_STEP if n <= 5 else CHIP_STEP * 4 / (n - 1))
    return (BAR_X + BAR_W / 2, mid - BAR_GAP - j * step if colour == 'w' else mid + BAR_GAP + j * step)

def tray_slot(colour, k):
    """Centre of the k-th borne-off checker in the frame beside your home board: White's tray at the bottom, Black's at the top."""
    x = fx(FIELD_X - FRAME / 2)
    return (x, FIELD_Y + FIELD_H - 5 - k * 5.5) if colour == 'w' else (x, FIELD_Y + 5 + k * 5.5)

def spot(pos, colour, s, j, n=0):
    """Where checker j of `colour` sits on s (a point index, 'bar' or 'off') - for arrows and slide animations."""
    if s in ('bar', BAR): return bar_slot(colour, j, n)
    if s in ('off', OFF): return tray_slot(colour, j)
    return slot_center(s, j, n)

def pt_at(pos, tray='w'):
    """Map a logical mouse position to a point index, BAR (the bar), OFF (the bear-off tray of `tray`: White's at the
    bottom, Black's at the top), or None."""
    x, y = fx(pos[0]), pos[1]   # work in the unmirrored layout
    if not (FIELD_Y <= y < FIELD_Y + FIELD_H): return None
    if FIELD_X <= x < BAR_X: col = int((x - FIELD_X) // PT_W)
    elif BAR_X + BAR_W <= x < FIELD_R: col = int((x - FIELD_X - BAR_W) // PT_W)
    elif BAR_X <= x < BAR_X + BAR_W: return BAR
    elif FIELD_X - FRAME <= x < FIELD_X and (y >= FIELD_Y + FIELD_H / 2) == (tray == 'w'): return OFF
    else: return None
    return col if y >= FIELD_Y + FIELD_H/2 else 23 - col

class Engine:
    def __init__(self):
        self.board = start_board()
        self.bar, self.off = [0, 0], [0, 0]   # [White, Black] checkers on the bar / borne off
        self.dice, self.display_dice, self.msg = [], [], "Press SPACE to roll."
        self.undo_stack, self.redo_stack = [], []
        self.selected, self.is_rolling, self.active_die_idx = None, False, 0
        self.chosen_die = None   # a die you tapped: the next checker you tap moves by it
        self.carried = None      # the point of a checker kept picked up after its one possible first step: tap it to go on
        self.what_if = False     # WHAT IF: you play out the roll as a trial; the coach judges it all, then puts it back
        self.what_if_from = None # ... the game as it was when WHAT IF was tapped (state, undo, redo, position, dice, plan, book)
        self.what_if_n = 0       # ... how many moves of this turn were played before it (the trial is the rest)
        self.rolling_for, self.roll_start = 'white', 0.0
        self.invalid = None              # point shown in red after an invalid click
        self.plan, self.plan_kind, self.book_key = None, 'coach', None  # remaining planned moves this roll; 'book' or 'coach'
        self.turn_start, self.turn_moves = None, []   # position at the roll; moves played so far this roll (as text)
        self.turn_dice = []                           # the dice as rolled this turn (for the end-of-turn review)
        self.coach = self._coach('info', '', self.msg)
        self.last_move, self.move_seq, self.invalid_seq = None, 0, 0  # not undo state: drive animation and sounds
        self.coaching = True   # preference, not undo state: off hides hints/critique and right-click plays the largest die
        self.review = False    # with hints off: review your whole play at the end of each turn (COACH: REVIEW)
        self.autoplay = False  # PLAY PLAN: main() plays the coach's remaining moves one at a time (not scored)
        self.queue = []        # remaining hops of a one-go move (13/9/8): main() plays them one at a time
        self.turn_score, self.session = [0, 0], [0, 0]   # [moves matching the coach, moves judged] this turn / this session
        # Turn flow: 'white_roll' -> 'white_move' -> 'white_done' -(SPACE)-> 'black' -> 'white_roll' (your dice roll by themselves)
        # 'black_start' when the opponent opens a game; 'over' once someone has borne off all 15.
        self.phase, self.starter = 'white_roll', 'white'
        self.who_starts = 'turns'     # preference: 'turns' (the other side starts each new game) or 'rolloff' (one die each)
        self.opening = False          # this game starts with the roll-off: your next roll is one die each
        self.opening_note = ""        # who won the roll-off, shown with the opponent's first moves
        self.opening_wait = None      # the roll-off is decided: (winner, your die, its die), played after a pause to see them
        self.opp_level, self.rng = 'strong', random.Random()
        self.autoroll = False         # preference: True = your dice roll by themselves after the opponent's turn
        self.opp_comment = ('', '')   # (full, short) verdict on the opponent's last play
        self.opp_trail = []           # its last moves, for numbered arrows until you roll: (src, dst, src j, src n, dst j, dst n)
        self.opp_arrows = True        # preference: show those arrows (whatever the coach mode)
        self.hint_saved = None        # HINT/HIDE: your chosen coach mode, to go back to (None = not pressed)
        self.auto_forced = True       # preference: play your moves for you when there is only one way left
        self.auto_race = False        # preference: once there is no contact, the coach plays your moves for you
        self.played_why = ""          # why a move is being played for you (forced, the race on auto-play)
        self.forced_now = False       # a forced move is being played (not scored)
        self.forced_trail = []        # forced moves played for you this turn, for arrows: (src, dst, src j, src n, dst j, dst n, move no.)
        self.no_forced = False        # after an undo, don't replay the forced move straight away
        self.opp_dice, self.opp_display, self.opp_plan, self.opp_log, self.opp_summary = [], [], [], [], ""
        self.match = [0, 0]   # points won this session: [you, opponent] (1 single, 2 gammon, 3 backgammon)
        self.game_score = [0, 0]   # this game's [moves matching the coach, moves judged]
        self.mistakes = []         # this game's: {pos, roll, dice, played, best, text, kind} - for the mistakes list
        self.finished = None       # when a game ends: its record for the player's progress (main() saves it)
        self.practice = None       # practice: the puzzle on the board (index into PUZZLES), else None
        self.two_player = False    # preference: two people share the screen (no computer opponent, nothing scored)
        self.flipped = False       # two players, Black to move: the engine's board is turned round (see real_view)
        self.match2 = [0, 0]       # two players: points won this session [White, Black]
        self.turn_trail = []       # this turn's moves, shown to the other player as arrows: (src, dst, src j, src n, dst j, dst n)
        self.cube_on = False       # preference: play with the doubling cube
        self.cube, self.cube_owner = 1, None   # what the game is worth, and who owns the cube ('white'/'black'; None: middle)
        self.cube_offer = None     # who has doubled ('white'/'black') while the other side decides: take or pass
        self.dice_game = [[0, 0, 0, 0], [0, 0, 0, 0]]   # this game's dice [White, Black]: rolls, doubles, pips, checkers hit
        self.dice_done = [[0, 0, 0, 0], [0, 0, 0, 0]]   # ... all earlier games against the computer (kept per player)
        self.dice_folded = False   # this game's dice are already counted in dice_done (it has ended)

    @property
    def pos(self):
        """Full position: 24 points + [White bar, Black bar, White off, Black off]."""
        return list(self.board) + list(self.bar) + list(self.off)

    @pos.setter
    def pos(self, p):
        self.board, self.bar, self.off = list(p[:24]), list(p[24:26]), list(p[26:28])

    @staticmethod
    def _coach(kind, verdict, status=""):
        return {'kind': kind, 'verdict': verdict, 'next': None, 'status': status, 'plan': [], 'done': [],
                'why': '', 'why_short': '', 'neutral': verdict}

    def get_pips(self): #
        w = sum((i+1) * v for i, v in enumerate(self.board) if v > 0) + 25 * self.bar[0]
        b = sum((24-i) * abs(v) for i, v in enumerate(self.board) if v < 0) + 25 * self.bar[1]
        return w, b

    def get_state(self):
        return {'board': list(self.board), 'bar': list(self.bar), 'off': list(self.off), 'phase': self.phase,
                'dice': list(self.dice), 'msg': self.msg,
                'idx': self.active_die_idx, 'disp': list(self.display_dice),
                'selected': self.selected, 'invalid': self.invalid,
                'plan': None if self.plan is None else list(self.plan), 'plan_kind': self.plan_kind,
                'book_key': self.book_key, 'turn_start': self.turn_start and list(self.turn_start),
                'turn_moves': list(self.turn_moves), 'coach': dict(self.coach),
                'turn_score': list(self.turn_score), 'session': list(self.session),
                'turn_trail': list(self.turn_trail), 'dice_game': [list(s) for s in self.dice_game]}

    def set_state(self, s):
        self.board, self.bar, self.off, self.phase = list(s['board']), list(s['bar']), list(s['off']), s['phase']
        self.dice, self.msg = list(s['dice']), s['msg']
        self.active_die_idx, self.display_dice = s['idx'], list(s['disp'])
        self.selected, self.invalid = s['selected'], s['invalid']
        self.plan, self.plan_kind = (None if s['plan'] is None else list(s['plan'])), s['plan_kind']
        self.book_key, self.turn_start = s['book_key'], s['turn_start'] and list(s['turn_start'])
        self.turn_moves, self.coach = list(s['turn_moves']), dict(s['coach'])
        self.turn_score, self.session = list(s['turn_score']), list(s['session'])
        self.turn_trail, self.dice_game = list(s['turn_trail']), [list(x) for x in s['dice_game']]   # an undone hit is uncounted

    SAVED = ('board', 'bar', 'off', 'phase', 'dice', 'display_dice', 'active_die_idx', 'starter', 'plan', 'plan_kind',
             'book_key', 'turn_start', 'turn_moves', 'turn_score', 'turn_dice', 'opp_display', 'opp_summary', 'msg', 'opening',
             'opp_trail',   # its arrows come back too when the app reopens (the phone reloads after updates)
             'opp_dice', 'opp_plan', 'opp_log', 'opp_comment', 'opening_note', 'opening_wait',   # mid-way through its turn
             'dice_game', 'cube', 'cube_owner', 'cube_offer', 'flipped', 'match2', 'turn_trail')

    def snapshot(self):
        """The game in progress as plain data, to carry on after the app is closed. Taken at any time except while the
        dice are rolling - also during the opponent's turn, so reopening carries on with the dice it already rolled."""
        return json.loads(json.dumps({k: getattr(self, k) for k in self.SAVED}))

    def restore(self, snap):
        for k in self.SAVED:
            if k in snap: setattr(self, k, snap[k])
        self.plan = [tuple(m) for m in self.plan] if self.plan else self.plan   # JSON turned tuples into lists
        self.opp_plan = [tuple(m) for m in self.opp_plan]
        self.opp_comment = tuple(self.opp_comment)
        self.opening_wait = tuple(self.opening_wait) if self.opening_wait else None
        self.book_key = tuple(self.book_key) if self.book_key else None
        if self.phase == 'opening':
            self.phase, self.opening, self.display_dice, self.opp_display, self.opening_wait = 'white_roll', True, [], [], None
        welcome = "Welcome back - your game carries on."
        if self.phase == 'white_move': self.update_msg(welcome)
        else:
            status = {"white_roll": "Click ROLL for the opening roll." if self.opening else self.roll_status(prompt=True),
                      "white_done": "Turn complete. Press SPACE to roll.",
                      "black_start": "The opponent goes first. Press SPACE to let it roll.", "black": "Opponent's turn.",
                      "cube_offer": self.offer_text()}.get(self.phase, "")
            self.msg = f"{welcome} {status}"; self.coach = self._coach('info', welcome, status)

    def save_state(self):
        self.undo_stack.append(self.get_state()); self.redo_stack.clear()

    def can_undo(self):
        if self.what_if and len(self.undo_stack) <= len(self.what_if_from[1]): return False   # not past the start of a trial
        return bool(self.undo_stack) and not self.is_rolling and self.phase in ('white_move', 'white_done')
    def can_redo(self): return bool(self.redo_stack) and not self.is_rolling and self.phase in ('white_move', 'white_done')

    def undo(self):
        self.autoplay, self.queue, self.no_forced, self.forced_trail, self.chosen_die = False, [], True, [], None
        if not self.can_undo(): return False
        self.redo_stack.append(self.get_state()); self.set_state(self.undo_stack.pop()); return True

    def redo(self):
        self.autoplay, self.queue, self.chosen_die = False, [], None
        if not self.can_redo(): return False
        self.undo_stack.append(self.get_state()); self.set_state(self.redo_stack.pop()); return True

    # --- turn flow (main() drives the timing) ---
    def start_rolling(self, who):
        self.is_rolling, self.rolling_for, self.roll_start = True, who, time.time()
        self.selected = self.invalid = None
        if who == 'white': self.opp_trail = []   # your roll: the opponent's arrows go

    def can_roll(self): return self.phase == 'white_roll' and not self.is_rolling
    def can_what_if(self):
        return (self.phase == 'white_move' and not self.is_rolling and self.practice is None and bool(self.dice)
                and self.forced_plan() is None)   # a forced roll has nothing to ask about
    def can_accept_plan(self):
        return (self.phase == 'white_move' and self.coaching and not self.autoplay and self.practice is None
                and not self.what_if and get_sug(self) is not None)

    def accept_plan(self):
        """PLAY PLAN / Enter: let the coach play the rest of this roll (main() plays one move at a time)."""
        if self.can_accept_plan(): self.autoplay = True; self.selected = self.invalid = None
        return self.autoplay

    def autoplay_step(self):
        """Play the coach's next move while PLAY PLAN is on. Returns True while there is more to play."""
        sug = get_sug(self) if self.autoplay and self.coaching and self.phase == 'white_move' else None
        if sug: self.move(sug[0], sug[1])
        self.autoplay = self.autoplay and self.phase == 'white_move' and self.coaching
        return self.autoplay
    def show_hint(self):
        """HINT / HIDE. Coach on REVIEW or OFF: HINT shows the coach's arrows and plan for the rest of this turn (moves
        made after peeking are not scored). Coach on HINTS: HIDE hides them, and they stay hidden - next turns and
        new games too - until you press HINT again. Press again to undo either."""
        if self.hint_saved is not None:
            self.end_hint(); return True
        if self.phase != 'white_move': return False
        self.hint_saved, self.coaching, self.review = (self.coaching, self.review), not self.coaching, False
        self.selected = self.invalid = None
        return True

    def hints_hidden(self):
        """Coach on HINTS, but you pressed HIDE."""
        return self.hint_saved is not None and self.hint_saved[0] and not self.coaching

    def end_hint(self, turn_over=False):
        """Back to your chosen coach mode. turn_over: a turn or game ended - a HINT peek ends, hidden hints stay hidden."""
        if self.hint_saved is None or (turn_over and self.hints_hidden()): return
        (self.coaching, self.review), self.hint_saved, self.autoplay = self.hint_saved, None, False

    def forced_plan(self):
        """The rest of this roll when there is only one way to play it (cached: the UI asks every frame), else None."""
        if self.phase != 'white_move' or not self.dice or self.is_rolling: return None
        plans = cached(self, 'forced', lambda: ranked_plans(self.pos, self.dice))
        return plans[0][2] if len(plans) == 1 and plans[0][2] else None

    def wants_forced_move(self):
        return self.auto_forced and not self.no_forced and not self.autoplay and not self.queue and self.forced_plan() is not None

    def wants_race_move(self):
        """Auto-play the race (preference): no contact left, so the coach plays your roll, one move at a time."""
        return (self.auto_race and self.phase == 'white_move' and self.practice is None and not self.no_forced
                and not self.what_if and not self.autoplay and not self.queue and not self.is_rolling and is_race(self.pos) and bool(current_plan(self)))

    def play_race_step(self):
        return self.play_forced_step(current_plan(self), "the race on auto-play")

    def play_forced_step(self, plan=None, why="the only possible move"):
        """Play the next move of a forced roll (no choice left), or of the given plan. Not scored; kept for the green arrows."""
        plan = plan or self.forced_plan()
        if not plan: return False
        self.forced_now, self.played_why = True, why
        try: played = self.move(*plan[0])
        finally: self.forced_now = False
        if played: self.forced_trail.append((*self.turn_trail[-1], len(self.turn_moves)))
        return True

    def can_hand_over(self): return self.phase in ('white_done', 'black_start') and not self.is_rolling

    def hand_over(self):
        """SPACE after your turn (or when the opponent opens the game): the opponent rolls and plays - or first
        doubles (cube on), or with two players it is the other player's turn."""
        if not self.can_hand_over(): return False
        self.end_hint(turn_over=True)                      # a HINT peek lasts for your turn only
        self.undo_stack.clear(); self.redo_stack.clear()   # undo works within your own turn only
        self.forced_trail = []                             # the green arrows last for your turn only
        if self.two_player: return self.switch_sides()
        if self.phase == 'white_done' and self.ai_doubles():
            self.phase, self.cube_offer = 'cube_offer', 'black'
            self.offer_msg()
            return True
        self.phase = 'black'
        self.start_rolling('black')
        return True

    # --- two players and the doubling cube ---
    def mover(self):
        """Who is to move, in real colours: 'white' (you), or 'black' while the board is turned round (two players)."""
        return 'black' if self.flipped else 'white'

    def who(self, side):
        """A side in words: you / the opponent, or White / Black with two players."""
        if self.two_player: return side.capitalize()
        return "you" if side == 'white' else "the opponent"

    def says(self, side, verb):
        """'you pass' / 'the opponent passes' / 'Black passes'."""
        w = self.who(side)
        return f"{w} {verb}" if w == "you" else f"{w} {verb}{'es' if verb.endswith('s') else 's'}"

    def roll_status(self, prompt=False):
        """The prompt before the player to move rolls (the cube on: they may double first, so no auto-roll).
        prompt: always say how to roll (AUTO-ROLL only starts after the opponent's turn)."""
        name = f"{self.who(self.mover())}'s turn." if self.two_player else "Your turn."
        if self.can_double(): return f"{name} You may double first. Press SPACE to roll."
        return name if self.autoroll and not prompt else f"{name} Press SPACE to roll."

    def coach_on(self): return self.coaching or self.review or self.hints_hidden()

    def switch_sides(self):
        """Two players: the other player's turn. The engine always moves 'White', so the board is turned round (all
        the rules, taps, hints and undo work the same for both); real_view shows it the right way round, and the moves
        just played show as arrows until the next player rolls."""
        real = lambda x: real_pt(self, x)
        self.opp_trail = [(real(s), real(d), sj, sn, dj, dn) for s, d, sj, sn, dj, dn in self.turn_trail]
        moves = other_numbers(", ".join(self.turn_moves)) or "no move"   # in the next player's point numbers (the board's turn too)
        done = f"{cap(self.who(self.mover()))} rolled {', '.join(map(str, self.display_dice))}: {moves}."
        self.pos, self.flipped = mirror(self.pos), not self.flipped
        self.opp_display, self.opp_dice, self.display_dice, self.dice = list(self.display_dice), [], [], []
        self.turn_trail, self.plan, self.selected, self.invalid, self.chosen_die = [], None, None, None, None
        self.phase = 'white_roll'
        self.opp_summary = done
        self.coach = self._coach('info', self.opp_summary, self.roll_status())
        self.msg = f"{self.opp_summary} {self.coach['status']}"
        if self.coaching and self.can_double():
            hint = cube_advice('double', win_chance(self.pos), self.who(self.mover()))
            if hint: self.coach['status'] += " " + hint
        return True

    def can_double(self):
        """Before rolling, the player to move may double while the cube is in the middle or on their side."""
        return (self.cube_on and self.phase == 'white_roll' and not self.is_rolling and not self.opening
                and self.practice is None and self.cube < CUBE_MAX and self.cube_owner in (None, self.mover())
                and self.pos != full(start_board()))   # not before anyone has moved: nobody is ahead yet

    def ai_view(self, p):
        """The computer's own estimate: exact when strong, with a misjudgement now and then on the easier levels."""
        if self.opp_level == 'strong': return p
        return p + self.rng.gauss(0, 0.05 if self.opp_level == 'intermediate' else 0.12)

    def ai_doubles(self):
        """Cube on, before its roll: does the computer double you? (From about 68% to win, by its own estimate.)"""
        return (self.cube_on and not self.two_player and self.practice is None and self.cube < CUBE_MAX
                and self.cube_owner in (None, 'black') and self.ai_view(win_chance(mirror(self.pos))) >= DOUBLE_POINT)

    def doubler_chance(self):
        """While a double is on offer: the doubler's chance, with the doubler about to roll."""
        return win_chance(self.pos if self.cube_offer == self.mover() else mirror(self.pos))

    def offer_text(self):
        """What a double on offer means for the side that must answer."""
        if not self.cube_offer: return ""
        taker, n, lose = ('black' if self.cube_offer == 'white' else 'white'), 2 * self.cube, self.cube
        lose = f"{lose} point{'s' if lose > 1 else ''}"
        if self.two_player:
            return (f"{cap(self.says(self.cube_offer, 'double'))} to {n}. {self.who(taker)}: TAKE to play on for {n} points "
                    f"(and own the cube), or PASS and lose {lose} now.")
        return f"The opponent doubles to {n}. TAKE: play on for {n} points (the cube is then yours). PASS: lose {lose} now."

    def offer_msg(self):
        """A double on offer: what it means, with the coach's advice first (it must fit the phone's card)."""
        taker = 'black' if self.cube_offer == 'white' else 'white'
        plain = self.offer_text()
        advice = cube_advice('answer', 1 - self.doubler_chance(), self.who(taker)) if self.coaching else ""
        self.msg = plain
        self.coach = {**self._coach('info', f"{advice} {plain}".strip(), "Take or pass?"), 'neutral': plain}

    def double(self):
        """DOUBLE (before rolling): offer to play on for twice the points. The computer answers at once (it takes
        while it still has about 25% by its own estimate); two players: the other one taps TAKE or PASS."""
        if not self.can_double(): return False
        me = self.mover()
        verdict, good = cube_verdict('double', win_chance(self.pos), self.who(me))
        self.cube_offer, self.phase = me, 'cube_offer'
        if self.two_player:
            self.offer_msg()
            if self.coach_on(): self.coach['verdict'] = f"{verdict} {self.coach['verdict']}"
            return True
        note = f" {verdict}" if self.coach_on() else ""
        if self.ai_view(1 - self.doubler_chance()) >= TAKE_POINT:
            self.take()
            t = (f"You double: the opponent takes. The game is now worth {self.cube} points, and the cube is on its side "
                 f"- only it can double next.")
            status = self.roll_status()
            self.msg = f"{t} {status}"
            self.coach = {**self._coach(('good' if good else 'critique') if note else 'info', t + note, status), 'neutral': t + note}
        else:
            self.pass_double(note=note, kind=('good' if good else 'critique') if note else None)
        return True

    def take(self):
        """TAKE: play on at double the points; the cube goes to the taker. Then the doubler rolls."""
        if self.phase != 'cube_offer': return False
        doubler, taker = self.cube_offer, ('black' if self.cube_offer == 'white' else 'white')
        human = self.two_player or taker == 'white'
        verdict = cube_verdict('take', 1 - self.doubler_chance(), self.who(taker)) if human and self.coach_on() else None
        self.cube, self.cube_owner, self.cube_offer = self.cube * 2, taker, None
        if doubler == self.mover():
            self.phase = 'white_roll'
            if human:   # two players (the computer's take is described by double())
                t = f"{cap(self.says(taker, 'take'))}: the game is now worth {self.cube} points."
                self.msg = f"{t} {self.roll_status()}"
                self.coach = self._coach(('good' if verdict[1] else 'critique') if verdict else 'info',
                                         f"{t} {verdict[0]}" if verdict else t, self.roll_status())
            return True
        self.phase = 'black'   # you took the computer's double: now it rolls
        self.start_rolling('black')
        t = f"You take: the game is now worth {self.cube} points, and the cube is yours - only you can double next."
        self.opening_note = t + " "   # shown with the opponent's roll and moves
        self.msg = t; self.coach = self._coach(('good' if verdict[1] else 'critique') if verdict else 'info',
                                              f"{t} {verdict[0]}" if verdict else t, "Opponent's turn.")
        return True

    def pass_double(self, note="", kind=None):
        """PASS: give up rather than play on at double the points: the doubler wins what the game was worth."""
        if self.phase != 'cube_offer': return False
        doubler, taker = self.cube_offer, ('black' if self.cube_offer == 'white' else 'white')
        if (self.two_player or taker == 'white') and self.coach_on():
            text, good = cube_verdict('pass', 1 - self.doubler_chance(), self.who(taker))
            note, kind = f" {text}", ('good' if good else 'critique')
        pts = self.cube
        said = f"{cap(self.says(doubler, 'double'))}: {self.says(taker, 'pass')}" if doubler == 'white' and not self.two_player \
            else cap(self.says(taker, 'pass'))
        self.end_game(0 if doubler == 'white' else 1, pts,
                      f"{said}, so {self.says(doubler, 'win')} {pts} point{'s' if pts > 1 else ''}.", note, kind)
        return True

    def count_roll(self, side, d1, d2):
        s = self.dice_game[side]
        s[0] += 1; s[1] += d1 == d2; s[2] += (d1 + d2) * (2 if d1 == d2 else 1)

    def fold_dice(self):
        """The game is over (or given up for a new one): its dice join the totals for MENU > Dice statistics."""
        if self.dice_folded or self.two_player or self.practice is not None: return
        self.dice_done = [[x + y for x, y in zip(a, b)] for a, b in zip(self.dice_done, self.dice_game)]
        self.dice_folded = True

    def finish_roll(self, d1, d2, counted=True):
        if self.opening: return self.opening_roll(d1, d2)
        if counted and self.practice is None: self.count_roll(1 if self.flipped else 0, d1, d2)
        self.is_rolling = False; self.redo_stack.clear()
        self.end_hint(turn_over=True); self.no_forced = False
        self.phase = 'white_move'
        self.display_dice, self.dice = [d1, d2], [d1, d2] * (2 if d1==d2 else 1)
        self.active_die_idx, self.selected, self.invalid, self.chosen_die, self.what_if = 0, None, None, None, False
        key = (max(d1, d2), min(d1, d2))
        self.turn_start, self.turn_moves, self.turn_score, self.turn_dice = self.pos, [], [0, 0], list(self.dice)
        self.turn_trail = []
        book = book_for(key)[2] if key in STRATEGY_MAP and self.pos == full(start_board()) else None
        if book and play_plan(self.pos, self.dice, book) is not None:
            self.plan, self.plan_kind, self.book_key = list(book), 'book', key
        else:
            self.plan, self.plan_kind, self.book_key = plan_turn(self.pos, self.dice), 'coach', None
        if self.two_player: rolled = f"{cap(self.who(self.mover()))} rolled {d1}, {d2}."
        else: rolled = f"You rolled {d1}, {d2}." if self.opp_summary else f"Rolled {d1}, {d2}."
        self.update_msg(f"{self.opp_summary} {rolled}".strip())
        self.opp_summary = ""

    def starts_changed(self):
        """Who starts was switched: a game that hasn't begun yet (nobody has rolled) uses it now, others from the next game."""
        fresh = self.phase in ('white_roll', 'black_start') and self.pos == full(start_board()) and not self.opp_display
        if not fresh or self.practice is not None: return
        if self.who_starts == 'rolloff':
            self.phase, self.opening, self.display_dice, self.flipped = 'white_roll', True, [], False
            self.msg = "Click ROLL for the opening roll. One die each; the higher one starts and plays both."
        else:
            self.opening = False
            if self.two_player:
                self.flipped, self.phase = self.starter == 'black', 'white_roll'
                self.msg = f"{self.who(self.starter)} goes first. Press SPACE to roll."
            else:
                self.phase = 'black_start' if self.starter == 'black' else 'white_roll'
                self.msg = ("The opponent goes first. Press SPACE to let it roll." if self.phase == 'black_start'
                            else "You go first. Press SPACE to roll.")
        self.coach = self._coach('info', '', self.msg)

    def opening_roll(self, mine, theirs):
        """Who starts (roll-off): one die each, the higher one starts and plays both dice. A tie: roll again.
        (mine: White's die - two players: the engine isn't turned round yet.)"""
        self.is_rolling = False
        dice = f"White {mine}, Black {theirs}" if self.two_player else f"you {mine}, opponent {theirs}"
        if mine == theirs:
            self.display_dice, self.opp_display = [mine], [theirs]
            t = f"Opening roll: {dice}. Tie, roll again."
            self.msg = t; self.coach = self._coach('info', t, "Click ROLL to roll again.")
            return
        # Decided: both dice stay where they landed (yours on your side) for a moment, then play_opening_wait()
        self.opening = False
        self.display_dice, self.opp_display = [mine], [theirs]
        self.undo_stack.clear(); self.redo_stack.clear(); self.forced_trail = []
        if mine > theirs or self.two_player:
            self.starter = 'white' if mine > theirs else 'black'
            self.phase, self.opening_wait = 'opening', (self.starter, mine, theirs)
            self.opp_summary = (f"Opening roll: {dice}, so {self.who(self.starter)} starts and plays both." if self.two_player
                                else f"Opening roll: {dice}, so you start and play both.")
            self.msg = self.opp_summary; self.coach = self._coach('info', self.msg, "Your turn." if not self.two_player else "")
            return
        self.starter, self.phase, self.opening_wait = 'black', 'black', ('black', mine, theirs)
        self.opening_note = f"Opening roll: {dice}, so the opponent starts. "
        self.msg = self.opening_note.strip(); self.coach = self._coach('info', self.msg, "Opponent's turn.")

    def play_opening_wait(self):
        """After the pause: the roll-off winner plays both dice (yours: your move as usual; the opponent's: its moves
        follow one at a time; two players: Black's move, with the board turned round)."""
        who, mine, theirs = self.opening_wait
        self.opening_wait = None
        if who == 'white':
            self.opp_display = []
            return self.finish_roll(mine, theirs, counted=False)
        if self.two_player:
            self.pos, self.flipped, self.opp_display = mirror(self.pos), True, []
            return self.finish_roll(theirs, mine, counted=False)
        self.display_dice = []
        self.opp_roll_done(theirs, mine, counted=False)

    def opp_roll_done(self, d1, d2, counted=True):
        """The opponent's dice have landed: choose its play. Strong: always the coach's best plan.
        Intermediate: the best plan 70% of the time, else one of its next 3 choices (plausible mistakes).
        Easy: the best plan 40% of the time, else any legal play at random."""
        self.is_rolling = False
        if counted: self.count_roll(1, d1, d2)
        self.opp_display, self.opp_dice = [d1, d2], [d1, d2] * (2 if d1 == d2 else 1)
        plans = ranked_plans(mirror(self.pos), self.opp_dice)
        if self.opp_level == 'strong': pick = plans[0]
        elif self.opp_level == 'intermediate': pick = plans[0] if self.rng.random() < 0.7 else self.rng.choice(plans[1:4] or plans)
        else: pick = plans[0] if self.rng.random() < 0.4 else self.rng.choice(plans)
        self.opp_plan, self.opp_log, self.opp_trail = list(pick[2]), [], []
        coach_on = self.coaching or self.review or self.hints_hidden()
        self.opp_comment = judge_opp_play(mirror(self.pos), plans, pick) if coach_on else ("", "")
        self._opp_msg()

    def _opp_msg(self, done=False):
        d1, d2 = self.opp_display
        moves = ", ".join(self.opp_log) if self.opp_log else ("no legal move" if done else "")
        self.msg = self.opening_note + f"Opponent rolled {d1}, {d2}" + (f": {moves}" if moves else "") + ("." if done else "...")
        if done and self.opp_comment[0]: self.msg += " " + self.opp_comment[0]
        self.coach = self._coach('info', self.msg, "" if done else "Opponent's turn.")

    def opp_step(self):
        """Play the opponent's next move. Returns True while it has more moves to make."""
        if self.phase == 'black' and self.opening_wait: self.play_opening_wait(); return True   # after the pause
        if self.phase != 'black' or not self.opp_plan: return False
        s, d = self.opp_plan.pop(0)
        m = mirror(self.pos)
        die = die_for(m, self.opp_dice, s, d)
        if die is None or why_illegal(m, self.opp_dice, s, d): self.opp_plan = []; return False   # never expected
        self.opp_dice.remove(die)
        rs, rd = ('bar' if s == BAR else 23 - s), ('off' if d == OFF else 23 - d)   # back to real point indices
        hit = d != OFF and m[d] == -1
        self.dice_game[1][3] += hit
        self.opp_log.append(f"{'bar' if s == BAR else rs + 1}/{'off' if d == OFF else rd + 1}{'*' if hit else ''}")
        self.last_move, self.move_seq = ('b', rs, rd, hit, ANIM_SLOW), self.move_seq + 1   # slow enough to follow
        black = lambda p, x: p[B_BAR] if x == 'bar' else p[B_OFF] if x == 'off' else max(-p[x], 0)   # its checkers on x
        ns = black(self.pos, rs)
        self.pos = mirror(apply_move(m, s, d))
        nd = black(self.pos, rd)
        self.opp_trail.append((rs, rd, ns - 1, ns, nd - 1, nd))
        if self.check_game_over(): return False
        self._opp_msg()
        return bool(self.opp_plan)

    def opp_finish(self):
        """End the opponent's turn: its moves are summarised and your dice roll next."""
        if self.phase != 'black': return
        self._opp_msg(done=True)
        d1, d2 = self.opp_display
        short = f" ({self.opp_comment[1]})" if self.opp_comment[1] else ""   # the full verdict shows until you roll
        self.opp_summary = self.opening_note + f"Opponent rolled {d1}, {d2}: {', '.join(self.opp_log) or 'no legal move'}{short}."
        self.opening_note = ""
        self.phase = 'white_roll'
        status = self.roll_status()
        if self.coaching and self.can_double():
            hint = cube_advice('double', win_chance(self.pos))
            if hint: status += " " + hint
        self.coach = self._coach('info', self.msg, status)

    def check_game_over(self):
        """First to bear off all 15 wins: 1 point, a gammon (2) if the loser has borne none off,
        a backgammon (3) if the loser also still has a checker on the bar or in the winner's home board.
        Times the doubling cube."""
        for side in (0, 1):
            if self.off[side] < 15: continue
            other = 1 - side
            if self.off[other] > 0: pts, kind = 1, "the game"
            else:
                home = range(0, 6) if side == 0 else range(18, 24)
                caught = self.bar[other] > 0 or any((self.board[i] < 0) if side == 0 else (self.board[i] > 0) for i in home)
                pts, kind = (3, "a backgammon") if caught else (2, "a gammon")
            winner = side ^ self.flipped   # the engine's side 0 is whoever is moving: Black while turned round
            cube = f", times the cube's {self.cube}" if self.cube > 1 else ""
            total = pts * self.cube
            said = cap(self.says('white' if winner == 0 else 'black', 'win'))
            self.end_game(winner, total, f"{said} {kind} ({total} point{'s' if total > 1 else ''}{cube})!")
            return True
        return False

    def end_game(self, winner, pts, text, note="", kind=None):
        """The game is over: winner 0 = White (you), 1 = Black (the opponent), worth pts. text says how it was won;
        note: the coach's verdict on the decision that ended it (a pass)."""
        if self.two_player:
            self.match2[winner] += pts
            tally = f"Games: White {self.match2[0]} - {self.match2[1]} Black."
        else:
            self.match[winner] += pts
            self.finished = {"date": time.strftime("%d %b %Y"), "won": winner == 0, "points": pts, "coach": list(self.game_score),
                             "mistakes": dict(collections.Counter(m["kind"] for m in self.mistakes))}
            tally = f"Games: you {self.match[0]} - {self.match[1]} opponent."
        self.fold_dice()
        self.phase, self.dice, self.opp_dice, self.opp_plan, self.plan, self.cube_offer = 'over', [], [], [], [], None
        self.undo_stack.clear(); self.redo_stack.clear()
        self.msg = f"{text}{note} {tally} Press SPACE for a new game."
        self.coach = self._coach(kind or ('good' if winner == 0 or self.two_player else 'critique'), self.msg)

    def plan_text(self, plan):
        """Plan moves as text ('13/8*' marks a hit), played in order from the current position."""
        return plan_text(self.pos, plan)

    def update_msg(self, verdict="", kind="info", neutral=None):
        """Set coach/msg to verdict + the plan for the rest of the roll, or end the turn when no dice / no legal moves remain.
        kind: 'info' | 'good' | 'critique' | 'invalid' (colours the coach panel).
        neutral: what the panel shows instead of verdict when coaching is off (defaults to verdict)."""
        neutral = verdict if neutral is None else neutral
        if self.dice and not legal_moves(self.pos, self.dice):
            stuck = f"No legal move for the remaining dice ({', '.join(map(str, self.dice))})."
            verdict = (verdict + " " if verdict else "") + stuck
            neutral = (neutral + " " if neutral else "") + stuck
            self.dice = []
        if self.dice and (not self.plan or play_plan(self.pos, self.dice, self.plan) is None):
            self.plan, self.plan_kind = plan_turn(self.pos, self.dice), 'coach'
        sug = get_sug(self)
        if sug:
            self.phase = 'white_move'
            status = f"{len(self.dice)} move{'s' if len(self.dice) != 1 else ''} left."
            nxt = (move_str(self.pos, sug[0], sug[1]) + (f" (x{sug[4]} remaining)" if sug[4] > 1 else ""), sug[3])
            plan, why, why_short = self.plan_text(self.plan), self.explain_plan(), self.explain_plan(short=True)
            tail = f"{status} Next suggested: {nxt[0]} - plan: {', '.join(plan)}. {why}"
        else:
            self.plan, self.dice = [], []
            self.phase = 'white_done'
            if self.practice is not None: self.finish_puzzle(); return
            status, nxt, plan, why = "Turn complete. Press SPACE to roll.", None, [], ""
            why_short = ""
            m, n = self.turn_score
            if n: why = f"This turn you matched the coach on {m} of {n} move{'s' if n > 1 else ''}" + (" - perfect!" if m == n else ".")
            review, review_ok = self.review_turn() if self.review else ("", True)
            tail = status
        if self.two_player and self.practice is None:   # whose turn it is, on every status line
            status = f"{cap(self.who(self.mover()))}: {status[:1].lower()}{status[1:]}"; tail = tail if sug else status
        self.coach = {'kind': kind, 'verdict': verdict, 'next': nxt, 'status': status,
                      'plan': plan, 'done': list(self.turn_moves), 'why': why, 'why_short': why_short, 'neutral': neutral,
                      'review': "" if sug else review, 'review_ok': True if sug else review_ok}
        self.msg = (verdict + " " if verdict else "") + tail
        if self.practice is not None and sug:   # a puzzle: no hints, just the question
            name, goal = PUZZLES[self.practice][:2]
            ask = f"Puzzle {self.practice + 1} of {len(PUZZLES)}: {name}{'' if name[-1] in '?!' else '.'} {goal}"
            self.coach = self._coach('info', verdict if verdict and verdict.startswith("Played") else ask, status)
            self.msg = f"{self.coach['verdict']} {status}"

    def review_turn(self):
        """COACH: REVIEW - compare the whole turn you just played with the coach's play for the same roll.
        Returns (text, as_good)."""
        start, dice, played = self.turn_start, self.turn_dice, list(self.turn_moves)
        if not start or not played: return "", True
        best = ranked_plans(start, dice)[0][2]
        book = book_for(self.book_key)[2] if self.book_key and play_plan(start, dice, book_for(self.book_key)[2]) else None
        best = book or best
        best_end, best_txt = play_plan(start, dice, best), plan_text(start, best)
        same = Outcome._fields.index("made")   # judged like the per-move critique: hits, off, back, gain
        if sorted(played) == sorted(best_txt):
            return f"Review: {', '.join(played)} - exactly the coach's play{' (the book opening)' if book else ''}.", True
        if (len(played), *turn_outcome(start, self.pos)[:same]) >= (len(best), *turn_outcome(start, best_end)[:same]):
            return (f"Review: {', '.join(played)} - as good as the coach's {', '.join(best_txt)}, "
                    f"which {describe_outcome(start, best_end, compact=True)}."), True
        return (f"Review: you played {', '.join(played)}, which {describe_outcome(start, self.pos, compact=True)}. "
                f"The coach would play {', '.join(best_txt)}, which {describe_outcome(start, best_end, compact=True)}."), False

    def explain_plan(self, short=False):
        """'Why' for the rest of this roll's plan: the idea, what it achieves, and why it beats the next-best play.
        short=True is the compact version the coach panel falls back to when the full one doesn't fit."""
        start = self.turn_start or self.pos
        end = play_plan(self.pos, self.dice, self.plan)
        if self.plan_kind == 'book' and self.book_key:
            risk = " Leaving a lone checker is a normal risk in the opening." if blots(end) and not short else ""
            return f"{book_for(self.book_key)[1]} {cap(blot_text(start, end, short))}.{risk}"
        if short: return cap(describe_outcome(start, end, compact=True)) + "."
        text = cap(describe_outcome(start, end, detail=True)) + "."
        alt = better_than(start, self.pos, self.dice, self.plan)
        return f"{text} {alt}" if alt else text

    def mark_invalid(self, pt, reason):
        self.invalid, self.msg = (pt if 0 <= pt <= 23 else None), reason
        self.invalid_seq += 1   # not undo state: lets the UI play the 'invalid' sound once per bad click
        self.coach = {**self.coach, 'kind': 'invalid', 'verdict': reason, 'neutral': reason, 'whatif': None}  # keep showing the next suggestion
        return False

    def move(self, s, d, die_val=None):
        if d < 0: d = OFF
        p = self.pos
        reason = why_illegal(p, self.dice, s, d)
        die = die_for(p, self.dice, s, d) if reason is None else None
        if reason is None and die_val is not None and die_val != die: reason = f"{move_str(p, s, d)} doesn't use a {die_val}."
        if reason is None and (s, d) not in {(m[0], m[1]) for m in allowed_moves(p, self.dice)}: reason = rule_reason(p, self.dice)
        if reason: return self.mark_invalid(d if 0 <= d <= 23 else s, reason)
        plan, book, kind = current_plan(self), self.plan_kind == 'book', None
        if plan != self.plan: book = False   # stored plan was stale; judged against a fresh coach plan
        start = self.turn_start or p
        after, rest_dice = apply_move(p, s, d), without(self.dice, die)
        self.save_state()
        m = move_str(p, s, d)
        rest = list(plan)
        if (s, d) in rest: rest.remove((s, d))
        if (s, d) in plan and play_plan(after, rest_dice, rest) is not None:   # on plan (any order)
            step = f"is step {len(self.turn_moves) + 1} of the plan" if plan[0] == (s, d) else "is part of the plan"
            critique = f"Good: {m} {'follows the book' if book else step}."
        else:
            best_end = play_plan(p, self.dice, plan)
            rest = plan_turn(after, rest_dice)
            new_end = play_plan(after, rest_dice, rest)
            n_best, n_new = len(plan), 1 + len(rest)
            same = Outcome._fields.index("made")   # equally good = same dice used, hits, off, back and gain (points less risk)
            if (n_new, *turn_outcome(start, new_end)[:same]) >= (n_best, *turn_outcome(start, best_end)[:same]):
                critique = f"Good: {m} - a different way to an equally good result."
            else:
                kind = worse_kind(turn_outcome(start, best_end), turn_outcome(start, new_end), n_new < n_best)
                critique = (f"Not the best: {m} {describe_move(p, s, d, with_move=False)}. "
                            f"The coach's {'book ' if book else ''}plan was {', '.join(self.plan_text(plan))}, which {describe_outcome(start, best_end, compact=True)}.")
            book = False
        self.plan, self.plan_kind = rest, ('book' if book else 'coach')
        self.turn_moves.append(m)
        peeked = self.hint_saved is not None and not self.hints_hidden()
        scored = not (self.autoplay or self.forced_now or peeked or self.practice is not None or self.what_if or self.two_player)
        if (self.coaching or self.review or self.hints_hidden()) and scored:
            # score your own choices with hints or reviews on (not PLAY PLAN, forced moves, puzzles, or after a HINT peek)
            good = int(critique.startswith("Good"))
            self.turn_score = [self.turn_score[0] + good, self.turn_score[1] + 1]
            self.session = [self.session[0] + good, self.session[1] + 1]
            self.game_score = [self.game_score[0] + good, self.game_score[1] + 1]
            if kind:   # for the mistakes list at the end of the game
                self.mistakes.append({'pos': list(p), 'roll': list(self.turn_dice), 'dice': list(self.dice), 'played': [s, d],
                                      'best': [list(x) for x in plan], 'text': critique, 'kind': kind})
        hit = d != OFF and p[d] == -1
        sp, dp = ('bar' if s == BAR else s), ('off' if d == OFF else d)
        ns = p[W_BAR] if s == BAR else p[s]
        nd = after[W_OFF] if d == OFF else after[d]
        self.turn_trail.append((sp, dp, ns - 1, ns, nd - 1, nd))   # for arrows: forced moves, the other player's view
        self.dice_game[1 if self.flipped else 0][3] += hit
        self.last_move, self.move_seq = ('b' if self.flipped else 'w', real_pt(self, sp), real_pt(self, dp), hit,   # as drawn
                                         ANIM_SLOW if self.forced_now else ANIM_T), self.move_seq + 1
        self.pos, self.dice = after, rest_dice
        if self.active_die_idx >= len(self.dice): self.active_die_idx = 0
        self.selected, self.invalid, self.chosen_die = None, None, None
        if self.what_if:   # a trial move: judged once the whole roll is played
            left = len(self.dice)
            t = f"What if: {', '.join(self.what_if_moves())} so far."
            self.update_msg(t, 'info')
            self.coach = {**self.coach, 'whatif': ('trying', self.what_if_moves(), left)}
            if self.phase != 'white_move': self.finish_what_if()   # roll used up (or no move left): the verdict
            return True
        if self.practice is None and self.check_game_over(): return True
        if self.practice is not None:   # a puzzle is judged when the roll is used up, not move by move
            self.update_msg(f"Played {m}.", 'info')
        elif self.forced_now:
            self.update_msg(f"Played for you: {m} ({self.played_why}).", 'info', neutral=f"Played for you: {m}.")
        else:
            self.update_msg(critique, 'good' if critique.startswith("Good") else 'critique', neutral=f"Played {m}.")
        return True

    def click(self, pt):
        """Left click: select an own checker (or the bar), or move the selected checker to pt (a point or OFF).
        One tap moves a checker that can only go to one place (bearing off too), or plays its first step when every way
        it can go starts with the same step (it stays picked up to go on: tap it again, or tap further along).
        With a real choice the first tap picks it up, and when it can bear off, a second tap on it takes it off."""
        self.autoplay, self.queue = False, []   # taking over by hand stops PLAY PLAN and any queued hops
        if not self.dice or self.is_rolling: return False
        p, sel = self.pos, self.selected
        ok = allowed_moves(p, self.dice)
        if sel is not None and pt != sel and pt != BAR:
            own = 0 <= pt <= 23 and p[pt] > 0
            if any(m[0] == sel and m[1] == pt for m in ok): return self.move(sel, pt)   # one die
            hops = combined_path(p, self.dice, sel, pt, current_plan(self)) if self.dice else None
            if hops: return self.move_hops(hops)                                      # several dice: 13/9/8
            # Empty/opponent point or the tray: try it so the red highlight explains why not. Own point: select it.
            if not own: return self.move(sel, pt)
        bears_off = lambda q: any(m[0] == q and m[1] == OFF for m in ok)
        if pt == sel:
            if bears_off(sel): return self.move(sel, OFF)   # tapped again: take it off
            self.selected = None
            if self.carried != sel: return False            # (a carried checker goes on to its next step, below)
        if pt == OFF: return self.mark_invalid(OFF, "To bear off, select a checker in your home board first, then click here (or right-click the checker).")
        if p[W_BAR] > 0 and pt != BAR and sel is None and any(m[0] == BAR for m in ok):
            # A checker on the bar has to come in first. Tapped where it can come in: it does. Tapped anything else
            # (one of your other checkers, say): pick up the bar checker instead and show where it can go.
            if any(m[0] == BAR and m[1] == pt for m in ok): return self.move(BAR, pt)
            if self.click(BAR): return True   # only one place to come in: done
            t = "Your checker on the bar must come in first: it's picked up now, tap where it should go."
            self.msg = t; self.coach = {**self.coach, 'kind': 'invalid', 'verdict': t, 'neutral': t, 'whatif': None}
            self.invalid_seq += 1
            return False
        if pt == BAR and p[W_BAR] <= 0: return self.mark_invalid(BAR, "You have no checkers on the bar.")
        if pt != BAR and p[pt] <= 0: return self.mark_invalid(pt, "Select one of your own (white) checkers first.")
        if not any(m[0] == pt for m in ok): return self.mark_invalid(pt, self.why_stuck(pt))
        if self.chosen_die is not None: return self.move_by(pt, self.chosen_die)
        entries = {m[1] for m in ok if m[0] == BAR}
        if pt == BAR and len(entries) == 1: return self.move(BAR, entries.pop())   # only one point to come in on: in it comes
        dests = reachable(p, self.dice, pt)
        if len(dests) == 1:   # only one place this checker can go: one tap moves it there
            d = next(iter(dests))
            if any(m[0] == pt and m[1] == d for m in ok): return self.move(pt, d)
            hops = combined_path(p, self.dice, pt, d, current_plan(self))
            if hops: return self.move_hops(hops)
        firsts = {m[1] for m in ok if m[0] == pt}
        if len(firsts) == 1 and pt != BAR:   # further on is possible, but only by this step first (8/4, then 4/off)
            d, trial = firsts.pop(), self.what_if
            if not self.move(pt, d): return False
            if (d != OFF and self.phase == 'white_move' and self.what_if == trial and self.dice and self.forced_plan() is None
                    and any(m[0] == d for m in allowed_moves(self.pos, self.dice))):
                self.selected = self.carried = d
            return True
        self.selected, self.invalid, self.carried = pt, None, None
        return False

    def toggle_what_if(self):
        """WHAT IF: ask about a play without it counting. You play out the rest of the roll as a trial (UNDO works);
        when the dice are used up the coach judges the whole play against its own, and everything goes back.
        Not scored or listed as a mistake. Tap again during the trial to cancel it."""
        if self.what_if:
            self.put_back_what_if(); self.update_msg("What if cancelled: everything is back."); return True
        if not self.can_what_if(): return False
        self.autoplay, self.queue, self.selected, self.chosen_die = False, [], None, None
        plan = current_plan(self)
        self.what_if, self.what_if_n = True, len(self.turn_moves)
        self.what_if_from = (self.get_state(), list(self.undo_stack), list(self.redo_stack), list(self.pos), list(self.dice),
                             list(plan), self.plan_kind == 'book' and plan == self.plan)
        n = len(self.dice)
        t = f"What if? Play all {n} moves you have in mind; the coach then judges them and puts everything back."
        self.msg = t; self.coach = {**self.coach, 'kind': 'info', 'verdict': t, 'neutral': t, 'whatif': ('trying', [], n)}
        return True

    def what_if_moves(self):
        """The trial moves so far (UNDO / REDO inside the trial keep this right: the turn's move list is undo state)."""
        return list(self.turn_moves[self.what_if_n:])

    def put_back_what_if(self):
        """End the trial: the board, dice, plan and undo history as they were when WHAT IF was tapped."""
        state, undo, redo = self.what_if_from[:3]
        self.set_state(state); self.undo_stack, self.redo_stack = undo, redo
        self.what_if, self.what_if_from, self.queue, self.selected, self.invalid = False, None, [], None, None

    def finish_what_if(self):
        """The trial roll is used up: compare the whole play with the coach's, then put everything back."""
        p0, dice0, plan, book = self.what_if_from[3:]
        end, moves = list(self.pos), self.what_if_moves()
        base = self.turn_start or p0   # judged from the start of your turn, like each move
        best_end, best_txt = play_plan(p0, dice0, plan), plan_text(p0, plan)
        same = Outcome._fields.index("made")   # equally good = same dice used, hits, off, back and gain
        played = ", ".join(moves)
        whose = f"the coach's {'book ' if book else ''}play"
        if sorted(moves) == sorted(best_txt):
            good, verdict = True, f"Good: that is exactly {whose}."
        elif (len(moves), *turn_outcome(base, end)[:same]) >= (len(plan), *turn_outcome(base, best_end)[:same]):
            good, verdict = True, f"Good: as good as {whose}, {', '.join(best_txt)} - a different way to an equally good result."
        else:
            good = False
            verdict = (f"Not the best: your play {describe_outcome(base, end, compact=True)}. "
                       f"{whose[0].upper() + whose[1:]} is {', '.join(best_txt)}, which {describe_outcome(base, best_end, compact=True)}.")
        self.put_back_what_if()
        text = f"What if {played}? {verdict} (Not played: everything is back.)"
        self.update_msg(text, 'good' if good else 'critique', neutral=text)
        self.coach = {**self.coach, 'whatif': ('done', moves, good)}

    def choose_die(self, v):
        """Tap one of your dice: the next checker you tap moves by that number (tap the die again to drop it).
        With a checker already picked up, that checker moves by it straight away. Doubles need no choice: False."""
        if self.phase != 'white_move' or self.is_rolling or v not in self.dice or len(set(self.dice)) < 2: return False
        self.autoplay, self.queue = False, []
        if self.selected is not None:
            sel = self.selected; self.selected = None
            return self.move_by(sel, v) or True
        self.chosen_die = None if self.chosen_die == v else v
        t = f"Using the {v}: tap the checker to move {v}." if self.chosen_die else "Tap a checker to move it."
        self.invalid, self.msg = None, t
        self.coach = {**self.coach, 'kind': 'info', 'verdict': t, 'neutral': t, 'whatif': None}
        return True

    def move_by(self, pt, v):
        """Move the checker on pt (or the bar) by the die v, or explain why it can't."""
        go = [m for m in allowed_moves(self.pos, self.dice) if m[0] == pt and m[2] == v]
        if go: return self.move(pt, go[0][1])
        d = pt - v if pt - v >= 0 else OFF
        why = why_illegal(self.pos, [v], pt, d) or rule_reason(self.pos, self.dice) or ""
        return self.mark_invalid(pt, f"{'The bar' if pt == BAR else f'Point {pt+1}'} can't move {v}. {why}".strip())

    def auto_move(self, pt):
        """Right click: play the coach's move from pt if it suggests one (coaching on), else the largest legal die."""
        self.autoplay, self.queue = False, []
        if not self.dice or self.is_rolling: return False
        p = self.pos
        if pt == OFF: return self.mark_invalid(OFF, "Right-click one of your checkers to move it.")
        if (pt == BAR and p[W_BAR] <= 0) or (pt != BAR and p[pt] <= 0):
            return self.mark_invalid(pt, f"{'The bar' if pt == BAR else f'Point {pt+1}'} has none of your checkers to auto-move.")
        sug = get_sug(self) if self.coaching and self.practice is None else None   # no answers in a puzzle
        if sug and sug[0] == pt: return self.move(pt, sug[1])
        opts = [m for m in allowed_moves(p, self.dice) if m[0] == pt]
        if not opts: return self.mark_invalid(pt, self.why_stuck(pt))
        s, d, die = max(opts, key=lambda m: m[2])
        return self.move(s, d)

    def move_hops(self, hops):
        """A one-go move over several dice: play the first hop now, queue the rest (each is judged and undone on its own)."""
        if not self.move(*hops[0]): return False
        self.queue = list(hops[1:])
        return True

    def play_queued(self):
        """Play the next queued hop. Returns True while more are waiting."""
        if self.queue and self.phase == 'white_move' and not self.move(*self.queue.pop(0)): self.queue = []
        if self.phase != 'white_move': self.queue = []
        return bool(self.queue)

    def rules_changed(self):
        """After switching Egyptian/standard rules: re-plan the current roll under the new rules and say what changed."""
        note = ("Egyptian rules: at most 5 checkers of one colour on a point." if egyptian()
                else "Standard rules: any number of checkers may share a point.")
        self.autoplay = False
        if self.phase == 'white_move':
            self.plan = None
            self.update_msg(note)
        else:
            self.coach = {**self.coach, 'verdict': note, 'neutral': note, 'whatif': None}

    def new_game(self):
        """Fresh board and empty undo history. Keeps your preferences and scores. Who starts: the other side this time,
        or (Who starts: OPENING ROLL) one die each when you tap ROLL."""
        self.end_hint(turn_over=True)
        keep = (self.coaching, self.review, self.move_seq, self.invalid_seq, self.session, self.match, self.opp_level, self.starter,
                self.autoroll, self.auto_forced, self.opp_arrows, self.hint_saved, self.auto_race, self.who_starts,
                self.two_player, self.cube_on, self.dice_done, self.match2)
        self.__init__()
        (self.coaching, self.review, self.move_seq, self.invalid_seq, self.session, self.match, self.opp_level, last,
         self.autoroll, self.auto_forced, self.opp_arrows, self.hint_saved, self.auto_race, self.who_starts,
         self.two_player, self.cube_on, self.dice_done, self.match2) = keep
        self.starter = 'black' if last == 'white' else 'white'
        if self.who_starts == 'rolloff':
            self.starter, self.opening = last, True
            self.msg = "New game: click ROLL for the opening roll. One die each; the higher one starts and plays both."
        elif self.two_player:
            self.flipped = self.starter == 'black'   # Black starts: the engine's board is turned round for its move
            self.msg = f"New game: {self.who(self.starter)} goes first. Press SPACE to roll."
        elif self.starter == 'black':
            self.phase, self.msg = 'black_start', "New game: the opponent goes first this time. Press SPACE to let it roll."
        else:
            self.msg = "New game: you go first. Press SPACE to roll."
        self.coach = self._coach('info', '', self.msg)

    def start_puzzle(self, i):
        """Practice: puzzle i on the board with its roll. Your play is judged when the roll is used up; no hints."""
        keep = (self.coaching, self.review, self.move_seq, self.invalid_seq, self.session, self.match, self.opp_level,
                self.autoroll, self.auto_forced, self.opp_arrows, self.hint_saved, self.auto_race, self.who_starts,
                self.two_player, self.cube_on, self.dice_done, self.match2)
        self.__init__()
        (self.coaching, self.review, self.move_seq, self.invalid_seq, self.session, self.match, self.opp_level,
         self.autoroll, self.auto_forced, self.opp_arrows, self.hint_saved, self.auto_race, self.who_starts,
         self.two_player, self.cube_on, self.dice_done, self.match2) = keep
        self.practice, self.pos = i % len(PUZZLES), PUZZLES[i % len(PUZZLES)][2]
        self.finish_roll(*PUZZLES[self.practice][3])

    def finish_puzzle(self):
        """The roll is used up: was it the coach's play (or as good)?"""
        start, dice = self.turn_start, self.turn_dice
        best = ranked_plans(start, dice)[0]
        same = 1 + Outcome._fields.index("made")   # dice used, hits, off, back, gain - as for your moves in a game
        played = ", ".join(self.turn_moves)
        if (len(self.turn_moves), *turn_outcome(start, self.pos))[:same] >= best[0][:same]:
            kind, text = 'good', f"Correct! {played} {describe_outcome(start, self.pos, compact=True)}."
        else:
            kind, text = 'critique', (f"Not quite. {played} {describe_outcome(start, self.pos, compact=True)}. "
                                      f"Best is {', '.join(plan_text(start, best[2]))}: {describe_outcome(start, best[1], detail=True)}.")
        self.coach = self._coach(kind, text, "Tap NEXT for the next puzzle (or UNDO to try again).")
        self.msg = f"{text} Press SPACE for the next puzzle."

    def why_stuck(self, pt):
        p, reasons = self.pos, []
        for die in sorted(set(self.dice), reverse=True):
            d = pt - die if pt - die >= 0 else OFF
            r = why_illegal(p, [die], pt, d) or rule_reason(p, self.dice)
            if r not in reasons: reasons.append(r)
        return f"No legal move from {'the bar' if pt == BAR else f'point {pt+1}'}: " + " ".join(reasons)

def race_text(mine, theirs, short=False):
    """Who is ahead in the race, from the pip counts (fewer pips to go is better)."""
    lead = theirs - mine
    if short: return f"+{lead}" if lead > 0 else str(lead) if lead < 0 else "="
    return f"{lead} ahead" if lead > 0 else f"{-lead} behind" if lead < 0 else "level"

ANIM_T = 0.2     # seconds for a checker to slide to its new point
ANIM_SLOW = 0.7  # ... when the game plays a forced move for you, so you can follow it
KIND_COLORS = {'good': (90, 210, 110), 'critique': (255, 190, 60), 'invalid': (255, 90, 90), 'info': (235, 235, 235)}

class UI:
    def __init__(self, screen, k=1.0):
        self.screen, self.k, self.ox, self.oy = screen, k, 0, 0   # k = pixels per logical px; (ox, oy) = margin when letterboxed
        self.layout, self.overlay = 'desktop', None   # 'phone' on small touch screens; overlay: None / 'menu' / 'details' / 'players'
        self.player, self.players = DEFAULT_PLAYER, [DEFAULT_PLAYER]   # who is playing; everyone who has played here
        self.entry = None   # typing a name: {'title', 'text', 'purpose'} (desktop; phones use their own keyboard)
        self.text_scale = 1.0          # phones: 1.25 for MENU > Text size: LARGE
        self.dice_pick = []            # Enter your own dice: the values tapped so far
        self.reviewing = None          # stepping through this game's mistakes: which one is on the board
        self.review_count = 0          # ... out of how many
        self.remove_until = 0.0        # 'Remove player' asks twice: until when the second tap counts
        self.progress = []             # a page of text (MENU > Your progress, Dice statistics...): its lines, when opened
        self.page_title, self.page_no = "Your progress", 0   # ... its title, and which page of it is showing
        self.own_dice = False          # preference: you tap in your own dice
        self.show_undo = True          # preference: the UNDO / REDO buttons are there (MENU > Undo button)
        self.make_fonts()
        self.panel = pygame.Rect(8, 516, 818, 120)   # wide enough for 95-char lines at size 18
        self.btn_r = pygame.Rect(834, 516, 150, 56)
        self.btn_u = pygame.Rect(834, 580, 71, 56)
        self.btn_redo = pygame.Rect(913, 580, 71, 56)
        self.btn_coach = pygame.Rect(412, 7, 158, 22)  # COACH: HINTS / REVIEW / OFF, in the header gap between the pip counts
        self.btn_new = pygame.Rect(262, 7, 136, 22)    # NEW GAME: first click/N asks, second click/Y confirms
        self.confirm_until = 0.0
        self._inv_key, self._inv_t = None, 0.0
        self._seen_seq, self._anim = 0, None      # (src, dst, hit, start_time)
        self._hand = False
        self.btn_sound = pygame.Rect(580, 7, 30, 22)   # speaker on/off (S)
        self.btn_opp = pygame.Rect(FIELD_X, 34, 196, 22)  # header row 2: opponent Easy / Intermediate / Strong (O)
        self.btn_rules = pygame.Rect(234, 34, 160, 22)    # header row 2: Egyptian (max 5 per point) / standard rules (R)
        self.btn_home = pygame.Rect(626, 7, 140, 22)      # header row 1: your home board on the left or right (H)
        self.btn_auto = pygame.Rect(402, 34, 146, 22)     # header row 2: your dice roll by themselves after its turn (A)
        self.btn_menu = pygame.Rect(556, 34, 150, 22)     # header row 2: the menu (player, mistakes, progress, practice...)
        self.sounds, self.sound_on, self._seen_inv = {}, True, 0

    def play(self, name):
        if self.sound_on and name in self.sounds: self.sounds[name].play()

    def confirming(self): return time.time() < self.confirm_until

    def request_new_game(self, game, confirm=False):
        """N / button: ask first (3 s window); a second press, or Y while asking, starts the new game."""
        if self.confirming() or confirm:
            if self.confirming(): game.fold_dice(); game.new_game()   # the game given up still counts in Dice statistics
            self.confirm_until = 0.0
        else:
            self.confirm_until = time.time() + 3

    # --- logical -> screen helpers ---
    def make_fonts(self):
        if WEB: font = lambda size, bold=False: pygame.font.Font(None, max(8, int(self.S(size) * 1.3)))   # no Arial in browsers
        else: font = lambda size, bold=False: pygame.font.SysFont("Arial", self.S(size), bold)
        self.fnt, self.msg_fnt, self.num_fnt = font(19, True), font(MSG_FONT_SIZE), font(14, True)
        self.msg_bold, self.small_fnt = font(MSG_FONT_SIZE, True), font(12)

    def resize(self, screen):
        """The window was resized or maximised: scale the 1000x650 layout to fit, centred, keeping its shape."""
        w, h = screen.get_size()
        self.screen = screen
        if self.layout == 'phone': self.phone_resize(w, h)
        else:
            set_point_width(74)
            self.k = max(0.3, min(w / WIDTH, h / HEIGHT))
            self.ox, self.oy = (w - round(WIDTH * self.k)) // 2, (h - round(HEIGHT * self.k)) // 2
        self.make_fonts()

    def S(self, v): return int(round(v * self.k))   # a length
    def P(self, p): return (self.S(p[0]) + self.ox, self.S(p[1]) + self.oy)   # a position
    def R(self, r): return pygame.Rect(self.S(r[0]) + self.ox, self.S(r[1]) + self.oy, self.S(r[2]), self.S(r[3]))
    def to_logical(self, pos): return ((pos[0] - self.ox) / self.k, (pos[1] - self.oy) / self.k)

    def blend(self, color, box, draw):
        """Without gfxdraw (web), plain pygame.draw ignores transparency: draw see-through shapes on a temporary
        layer covering `box` (screen px) and blend that in. draw(surface, offset_x, offset_y) does the drawing."""
        if len(color) < 4 or color[3] >= 255: draw(self.screen, 0, 0); return
        box = pygame.Rect(box).inflate(4, 4)
        layer = pygame.Surface(box.size, pygame.SRCALPHA)
        draw(layer, -box.x, -box.y)
        self.screen.blit(layer, box.topleft)

    def poly(self, pts, color):
        pts = [self.P(p) for p in pts]
        if gfx:
            gfx.filled_polygon(self.screen, pts, color); gfx.aapolygon(self.screen, pts, color); return
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        self.blend(color, (min(xs), min(ys), max(xs) - min(xs) + 1, max(ys) - min(ys) + 1),
                   lambda s, dx, dy: pygame.draw.polygon(s, color, [(x + dx, y + dy) for x, y in pts]))

    def circle(self, c, r, color):
        x, y = self.P(c); r = max(1, self.S(r))
        if gfx:
            gfx.filled_circle(self.screen, x, y, r, color); gfx.aacircle(self.screen, x, y, r, color); return
        smooth = getattr(pygame.draw, "aacircle", None)   # pygame-ce (the web build) has an anti-aliased circle
        self.blend(color, (x - r, y - r, 2 * r + 1, 2 * r + 1),
                   lambda s, dx, dy: (smooth or pygame.draw.circle)(s, color, (x + dx, y + dy), r))

    def ring(self, c, r, color, width):
        x, y = self.P(c)
        if gfx:
            for d in range(max(1, self.S(width))): gfx.aacircle(self.screen, x, y, self.S(r) + d, color)
            return
        r0, w = self.S(r), max(1, self.S(width))
        smooth = getattr(pygame.draw, "aacircle", None)
        self.blend(color, (x - r0 - w, y - r0 - w, 2 * (r0 + w) + 1, 2 * (r0 + w) + 1),
                   lambda s, dx, dy: (smooth or pygame.draw.circle)(s, color, (x + dx, y + dy), r0 + w, w))

    def text(self, font, s, color, pos, anchor="topleft"):
        img = font.render(s, True, color)
        rect = img.get_rect(**{anchor: self.P(pos)}); self.screen.blit(img, rect)
        return rect

    def checker(self, c, white, r=CHIP_R, lift=0):
        f = r / CHIP_R
        self.circle((c[0] + 1.5 + lift, c[1] + 2.5 + lift), r, (0, 0, 0, 90 if not lift else 70))  # shadow
        self.circle(c, r, (150, 148, 138) if white else (8, 8, 10))                                  # rim
        self.circle(c, r - 2*f, (242, 240, 230) if white else (48, 48, 52))                         # face
        if r > 8: self.ring(c, r - 7*f, (212, 208, 194) if white else (70, 70, 76), 1.5)             # groove
        self.circle((c[0] - 5*f, c[1] - 5*f), 4*f, (255, 255, 255, 110 if white else 40))          # shine

    def arrow(self, a, b, color, width=4):
        """Curved arrow from checker centre a to landing spot b (dark outline for contrast)."""
        ctrl = arc_ctrl(a, b)
        pts = [p for p in (bezier(a, ctrl, b, n / 40) for n in range(41))
               if math.dist(p, a) > CHIP_R + 5 and math.dist(p, b) > CHIP_R + 12]
        if len(pts) < 2: return
        (x1, y1), (x2, y2) = pts[-2], pts[-1]
        ang = math.atan2(y2 - y1, x2 - x1)
        tip = (x2 + 12 * math.cos(ang), y2 + 12 * math.sin(ang))
        head = [tip, (x2 + 7 * math.cos(ang + 2.2), y2 + 7 * math.sin(ang + 2.2)), (x2 + 7 * math.cos(ang - 2.2), y2 + 7 * math.sin(ang - 2.2))]
        for col, w in [((20, 20, 20), width + 3), (color, width)]:
            pygame.draw.lines(self.screen, col, False, [self.P(p) for p in pts], self.S(w))
            for p in pts: self.circle(p, w / 2 - 0.5, col)
        self.poly(head, color)

    def die(self, center, value, used, size=44, jitter=(0, 0), dark=False):
        x, y = center[0] - size/2 + jitter[0], center[1] - size/2 + jitter[1]
        r = (x, y, size, size)
        if not used: pygame.draw.rect(self.screen, (10, 10, 10), self.R((x + 2, y + 3, size, size)), border_radius=self.S(7))
        if dark:   # the opponent's dice: black with white pips
            face, pip = ((70, 70, 72), (130, 130, 130)) if used else ((38, 38, 42), (240, 240, 240))
            pygame.draw.rect(self.screen, face, self.R(r), border_radius=self.S(7))
            pygame.draw.rect(self.screen, (110, 110, 115), self.R(r), max(1, self.S(1)), border_radius=self.S(7))
        else:
            pygame.draw.rect(self.screen, (120, 118, 110) if used else (250, 248, 240), self.R(r), border_radius=self.S(7))
            pip = (85, 83, 78) if used else (20, 20, 20)
        q = size / 4
        spots = {1:[(2,2)], 2:[(1,1),(3,3)], 3:[(1,1),(2,2),(3,3)], 4:[(1,1),(3,1),(1,3),(3,3)],
                 5:[(1,1),(3,1),(2,2),(1,3),(3,3)], 6:[(1,1),(3,1),(1,2),(3,2),(1,3),(3,3)]}[value]
        for sx, sy in spots: self.circle((x + sx*q, y + sy*q), size * 0.085, pip)

    def button(self, rect, label, sub, base, fg, enabled, hover):
        col = base if enabled else (58, 58, 58)
        if enabled and hover: col = tuple(min(255, c + 25) for c in col)
        pygame.draw.rect(self.screen, (10, 10, 10), self.R(rect.move(0, 3)), border_radius=self.S(8))
        pygame.draw.rect(self.screen, col, self.R(rect), border_radius=self.S(8))
        fg = fg if enabled else (125, 125, 125)
        font = self.fnt if self.fnt.size(label)[0] <= self.S(rect.w - 6) else self.num_fnt   # DOUBLE on a small button
        self.text(font, label, fg, (rect.centerx, rect.centery - 7), "center")
        self.text(self.small_fnt, sub, fg, (rect.centerx, rect.centery + 13), "center")

    def new_game_button(self, hover):
        r, asking = self.btn_new, self.confirming()
        col = (200, 60, 60) if asking else (70, 70, 70)
        if hover: col = tuple(min(255, c + 30) for c in col)
        pygame.draw.rect(self.screen, col, self.R(r), border_radius=self.S(11))
        self.text(self.num_fnt, "CONFIRM? (Y)" if asking else "NEW GAME (N)", COLOR_TEXT, r.center, "center")

    def sound_button(self, hover):
        r, on = self.btn_sound, self.sound_on
        col = (COLOR_TEXT if on else (150, 150, 150))
        if hover: col = tuple(min(255, c + 30) for c in col)
        x, cy = r.x + 4, r.centery
        self.poly([(x, cy - 4), (x + 5, cy - 4), (x + 11, cy - 9), (x + 11, cy + 9), (x + 5, cy + 4), (x, cy + 4)], col)
        if on:
            for rad in (6, 10):
                pygame.draw.arc(self.screen, col, self.R((x + 9 - rad, cy - rad, 2 * rad, 2 * rad)), -0.8, 0.8, max(1, self.S(2)))
        else:
            pygame.draw.line(self.screen, (230, 80, 80), self.P((x - 2, cy + 10)), self.P((x + 22, cy - 10)), max(1, self.S(3)))

    def score_text(self, game):
        """Header row 2: games won (centre) and how often you matched the coach (right)."""
        if game.two_player:
            self.text(self.num_fnt, f"TWO PLAYERS   WHITE {game.match2[0]} : {game.match2[1]} BLACK", (215, 215, 215), (FIELD_R, 45), "midright")
            return
        m, n = game.session
        score = f"{m}/{n} ({round(100 * m / n)}%)" if n else "-"
        self.text(self.num_fnt, f"GAMES {game.match[0]}:{game.match[1]}   SCORE {score}", (215, 215, 215), (FIELD_R, 45), "midright")

    def menu_button(self, hover):
        r = self.btn_menu
        pygame.draw.rect(self.screen, (120, 95, 50) if hover else (95, 75, 40), self.R(r), border_radius=self.S(11))
        name = self.player if len(self.player) <= 12 else self.player[:11] + "."
        self.text(self.num_fnt, f"MENU: {name}", COLOR_TEXT, r.center, "center")

    # Players: a list to pick from (MENU > Player on phones, the PLAYER button on the laptop), and a box to type a name
    def player_rows(self):
        rows = [(("pick", n), f"{n}   (playing now)" if n == self.player else n) for n in self.players[:8]]
        remove = f"Tap again to remove {self.player}" if time.time() < self.remove_until else f"Remove {self.player}"
        return rows + [("newplayer", "+ New player"), ("rename", f"Change the name {self.player}"), ("removeplayer", remove),
                       ("close", "Cancel")]

    LISTS = ('menu', 'players', 'mistakes', 'practice')   # overlays that are a list of choices

    def overlay_rows(self, game):
        """(title, rows) for the list overlay that is open: rows are (action, label); action None = just text."""
        if self.overlay == 'menu':
            return "Menu", (self.phone_menu_rows(game) if self.layout == 'phone' else self.desk_menu_rows(game))
        if self.overlay == 'players': return "Who is playing?", self.player_rows()
        if self.overlay == 'mistakes':
            rows = [(("mistake", i), f"{i + 1}. {move_str(m['pos'], *m['played'])} - {MISTAKE_KINDS[m['kind']]}")
                    for i, m in enumerate(game.mistakes[:12])]
            return "Mistakes this game", (rows or [(None, "No mistakes this game (yet).")]) + [("close", "Close")]
        return "Practice puzzles", [(("puzzle", i), f"{i + 1}. {p[0]}") for i, p in enumerate(PUZZLES)] + [("close", "Close")]

    def desk_menu_rows(self, game):
        """The laptop's menu: what the header buttons don't already do."""
        on = lambda x: "ON" if x else "OFF"
        practice = ("leavepractice", "Leave practice") if game.practice is not None else ("practice", "Practice puzzles")
        return [("player", f"Player: {self.player}   (change)"),
                ("whatif", "What if? Try a play without it counting (W)" if not game.what_if else "What if: ON - play your moves (W cancels)"),
                ("owndice", f"Enter your own dice: {on(self.own_dice)}"),
                ("autoforced", f"Auto-play forced moves: {on(game.auto_forced)}"),
                ("opparrows", f"Opponent's moves as arrows (M): {on(game.opp_arrows)}"),
                ("autorace", f"Auto-play the race: {on(game.auto_race)}"), ("whostarts", starts_label(game)),
                ("twoplayer", play_against(game)), ("cube", f"Doubling cube: {on(game.cube_on)}"),
                ("cubehelp", "How the doubling cube works"), ("showundo", undo_label(self)),
                ("mistakes", f"Mistakes this game ({len(game.mistakes)})"), ("progress", "Your progress"),
                ("dicestats", "Dice statistics"), practice]

    def desk_list_rects(self, rows):
        h = 34 if len(rows) <= 11 else 30
        box = pygame.Rect(300, 70, 400, 52 + (h + 4) * len(rows))
        return box, [(act, label, pygame.Rect(box.x + 14, box.y + 46 + (h + 4) * i, box.w - 28, h)) for i, (act, label) in enumerate(rows)]

    def dice_rects(self):
        """The six dice to tap (Enter your own dice): screen pixels on phones, logical on the laptop."""
        if self.layout == 'phone':
            s = self.sheet; size = min(s.w // 8, s.h // 3); gap = size // 4
            x0 = s.centerx - (6 * size + 5 * gap) // 2
            return s, [(v, pygame.Rect(x0 + (v - 1) * (size + gap), s.centery - size // 2, size, size)) for v in range(1, 7)]
        box = pygame.Rect(300, 190, 400, 170)
        return box, [(v, pygame.Rect(box.x + 22 + (v - 1) * 60, box.y + 70, 52, 52)) for v in range(1, 7)]

    def dice_title(self, game):
        if game.opening and game.two_player:
            return "Opening roll: tap White's die" if not self.dice_pick else f"White's die: {self.dice_pick[0]}. Now Black's."
        if game.opening: return "Opening roll: tap your die" if not self.dice_pick else f"Your die: {self.dice_pick[0]}. Now the opponent's."
        whose = f"{game.who(game.mover())}'s" if game.two_player else "Your"
        return f"{whose} dice: tap the first one" if not self.dice_pick else f"First die: {self.dice_pick[0]}. Now tap the second."

    def desk_tap(self, pos, game):
        """A click (logical position) while an overlay is open on the laptop: an action, None, or 'close' outside."""
        if self.overlay == 'dice':
            box, rects = self.dice_rects()
            for v, r in rects:
                if r.collidepoint(pos): return ("die", v)
            return None if box.collidepoint(pos) else "close"
        if self.overlay not in self.LISTS:   # a page of text: a click turns the page, or closes the last one
            return "nextpage" if self.page_no + 1 < len(self.desk_pages()) else "close"
        box, rows = self.desk_list_rects(self.overlay_rows(game)[1])
        for act, _, r in rows:
            if r.collidepoint(pos) and act: return act
        return None if box.collidepoint(pos) else "close"

    def desk_overlay(self, game):
        """The laptop's open overlay: a list, the dice to tap, or a page of text."""
        mouse = self.to_logical(pygame.mouse.get_pos())
        frame = lambda box: (pygame.draw.rect(self.screen, (30, 34, 32), self.R(box), border_radius=self.S(10)),
                             pygame.draw.rect(self.screen, (130, 130, 130), self.R(box), self.S(2), border_radius=self.S(10)))
        if self.overlay == 'dice':
            box, rects = self.dice_rects(); frame(box)
            self.text(self.fnt, self.dice_title(game), COLOR_TEXT, (box.x + 16, box.y + 14))
            for v, r in rects:
                pygame.draw.rect(self.screen, (250, 248, 240) if r.collidepoint(mouse) else (232, 230, 220), self.R(r), border_radius=self.S(8))
                self.text(self.fnt, str(v), (20, 20, 20), r.center, "center")
            self.text(self.msg_fnt, "Or press 1-6.  Esc cancels.", (190, 196, 192), (box.x + 16, box.bottom - 30))
            return
        if self.overlay not in self.LISTS:
            box = pygame.Rect(110, 66, 780, 540); frame(box)
            pages = self.desk_pages()
            n = min(self.page_no, len(pages) - 1)
            more = f"   (page {n + 1} of {len(pages)})" if len(pages) > 1 else ""
            self.text(self.fnt, self.page_title + more, COLOR_TEXT, (box.x + 16, box.y + 12))
            y = box.y + 50
            for part in pages[n] + ["", "(Click for the next page.)" if n + 1 < len(pages) else "(Click anywhere to close.)"]:
                self.text(self.msg_fnt, part, COLOR_TEXT, (box.x + 16, y)); y += 22
            return
        title, rows = self.overlay_rows(game)
        box, rects = self.desk_list_rects(rows); frame(box)
        self.text(self.fnt, title, COLOR_TEXT, (box.x + 16, box.y + 12))
        for act, label, r in rects:
            if act and act != 'close':
                pygame.draw.rect(self.screen, (80, 88, 84) if r.collidepoint(mouse) else (55, 60, 58), self.R(r), border_radius=self.S(6))
            self.text(self.msg_fnt, label, COLOR_TEXT if act else (190, 196, 192), (r.x + 12, r.centery), "midleft")

    def desk_pages(self):
        """The page of text (progress, dice statistics, cube help) wrapped for the laptop, 19 lines a page."""
        lines = [part for line in self.progress for part in (textwrap.wrap(line, 88) or [""])]
        return [lines[i:i + 19] for i in range(0, len(lines), 19)] or [[]]

    def phone_pages(self, game):
        """The details sheet or a page of text, wrapped to the sheet, as pages that fit it."""
        s, line_h = self.sheet, self.pf_small.get_linesize()
        if self.overlay == 'progress': text = "\n\n".join([self.page_title.upper()] + self.progress)
        else: text = self.phone_details(game)
        lines = self.wrap_px(self.pf_small, text, s.w - 2 * (s.w // 30))
        per = max(1, (s.h - s.h // 20) // line_h - 2)   # room for the 'tap' line
        return [lines[i:i + per] for i in range(0, len(lines), per)] or [[]]

    # Reviewing this game's mistakes: the position before the move, what you played (red) and the coach's play (cyan)
    def review_engine(self, game):
        m, n = game.mistakes[self.reviewing], len(game.mistakes)
        r = Engine()
        r.pos, r.dice, r.display_dice, r.phase = list(m["pos"]), list(m["dice"]), list(m["roll"][:2]), 'white_move'
        r.coaching = r.opp_arrows = False
        r.hint_saved, r.opp_level, r.autoroll = (game.coaching or game.hints_hidden(), game.review), game.opp_level, game.autoroll
        r.move_seq, r.invalid_seq, r.last_move = game.move_seq, game.invalid_seq, None   # no slide or sound
        steps = "NEXT / BACK to step through, MENU when done." if self.layout == 'phone' else "Space: next   Backspace: back   Esc: done"
        r.coach = r._coach('critique', f"Mistake {self.reviewing + 1} of {n}: {m['text']}", steps)
        r.msg = r.coach['verdict']
        r.review_arrows, r.is_review = (tuple(m["played"]), [tuple(x) for x in m["best"]]), True
        self.review_count = n
        return r

    def plan_steps(self, pos, plan, flip=False):
        """Arrow ends for a plan of your moves played in order from pos: [(from, to, borne off)].
        flip: pos is the engine's board turned round for Black (two players): the arrows go on the real board."""
        b_sim, steps = list(pos), []
        me, P = ('b', lambda i: 23 - i) if flip else ('w', lambda i: i)
        for s, d in plan:
            a = bar_slot(me, b_sim[W_BAR] - 1, b_sim[W_BAR]) if s == BAR else slot_center(P(s), b_sim[s] - 1, b_sim[s])
            b = tray_slot(me, b_sim[W_OFF]) if d == OFF else slot_center(P(d), max(b_sim[d], 0), max(b_sim[d], 0) + 1)
            steps.append((a, b, d == OFF))
            b_sim = apply_move(b_sim, s, d)
        return steps

    def entry_box(self):
        """The name being typed (laptop keyboard)."""
        e, scr = self.entry, self.screen
        text = e["text"] + ("|" if int(time.time() * 2) % 2 else " ")
        if self.layout == 'phone':
            w, h = scr.get_size(); r = pygame.Rect(w // 6, h // 4, w * 2 // 3, h // 2)
            pygame.draw.rect(scr, (30, 34, 32), r, border_radius=12); pygame.draw.rect(scr, (130, 130, 130), r, 2, border_radius=12)
            self.phone_text(self.pf, e["title"], COLOR_TEXT, (r.x + 20, r.y + 16))
            self.phone_text(self.pf_big, text, (255, 230, 120), (r.x + 20, r.centery), "midleft")
            self.phone_text(self.pf_small, "Enter: OK     Esc: cancel", (190, 196, 192), (r.x + 20, r.bottom - 12), "bottomleft")
            return
        r = pygame.Rect(300, 200, 400, 140)
        pygame.draw.rect(scr, (30, 34, 32), self.R(r), border_radius=self.S(10))
        pygame.draw.rect(scr, (130, 130, 130), self.R(r), self.S(2), border_radius=self.S(10))
        self.text(self.fnt, e["title"], COLOR_TEXT, (r.x + 16, r.y + 14))
        self.text(self.fnt, text, (255, 230, 120), (r.x + 16, r.y + 60))
        self.text(self.msg_fnt, "Type the name, then press Enter (Esc cancels).", (190, 196, 192), (r.x + 16, r.y + 106))

    def auto_button(self, game, hover):
        r = self.btn_auto
        col = ((50, 120, 150) if game.autoroll else (90, 90, 90))
        if hover: col = tuple(min(255, c + 30) for c in col)
        pygame.draw.rect(self.screen, col, self.R(r), border_radius=self.S(11))
        self.text(self.num_fnt, f"AUTO-ROLL: {'ON' if game.autoroll else 'OFF'} (A)", COLOR_TEXT, r.center, "center")

    def home_button(self, hover):
        r = self.btn_home
        col = (90, 90, 90) if not hover else (120, 120, 120)
        pygame.draw.rect(self.screen, col, self.R(r), border_radius=self.S(11))
        self.text(self.num_fnt, f"HOME: {'RIGHT' if HOME_RIGHT else 'LEFT'} (H)", COLOR_TEXT, r.center, "center")

    def rules_button(self, hover):
        r, egy = self.btn_rules, egyptian()
        col = (95, 75, 140) if egy else (60, 95, 140)
        if hover: col = tuple(min(255, c + 30) for c in col)
        pygame.draw.rect(self.screen, col, self.R(r), border_radius=self.S(11))
        self.text(self.num_fnt, f"RULES: {'EGYPTIAN' if egy else 'STANDARD'} (R)", COLOR_TEXT, r.center, "center")

    def opponent_button(self, game, hover):
        r = self.btn_opp
        col = {'easy': (60, 120, 70), 'intermediate': (165, 120, 40), 'strong': (150, 70, 50)}[game.opp_level]
        if hover: col = tuple(min(255, c + 30) for c in col)
        pygame.draw.rect(self.screen, col, self.R(r), border_radius=self.S(11))
        self.text(self.num_fnt, f"OPP: {game.opp_level.upper()} (O)", COLOR_TEXT, r.center, "center")

    def coach_switch(self, game, hover):
        """COACH: HINTS (arrows + comments) / REVIEW (no hints, verdict at the end of your turn) / OFF.  C cycles."""
        r, mode = self.btn_coach, chosen_coach_mode(game)   # your setting, even with hints hidden
        col = {'hints': (50, 150, 80), 'review': (40, 120, 150), 'off': (85, 85, 85)}[mode]
        if hover: col = tuple(min(255, c + 30) for c in col)
        pygame.draw.rect(self.screen, col, self.R(r), border_radius=self.S(11))
        self.text(self.num_fnt, f"COACH: {mode.upper()} (C)", COLOR_TEXT, r.center, "center")

    def rich_text(self, spans, y, max_y):
        """Draw (text, colour, bold) spans wrapped with textwrap at MSG_WRAP chars, keeping each span's style."""
        full, styles = "", []
        for t, col, bold in spans: full += t; styles += [(col, bold)] * len(t)
        pos = 0
        for line in textwrap.wrap(full, MSG_WRAP):
            if y + 21 > max_y: break
            start = full.find(line, pos); pos = start + len(line)
            x, i = self.panel.x + 16, start
            while i < pos:
                j = i
                while j < pos and styles[j] == styles[i]: j += 1
                col, bold = styles[i]
                x = self.to_logical(self.text(self.msg_bold if bold else self.msg_fnt, full[i:j], col, (x, y)).topright)[0]
                i = j
            y += 21
        return y

    def coach_panel(self, game):
        p = self.panel
        pygame.draw.rect(self.screen, (32, 36, 34), self.R(p), border_radius=self.S(8))
        if game.is_rolling:
            self.text(self.msg_fnt, "Rolling...", KIND_COLORS['info'], (p.x + 16, p.y + 8)); return
        c = game.coach
        if not game.coaching:   # plain game log: what happened + moves left (invalid-click reasons still shown)
            review = c.get('review', '') if game.review else ''   # COACH: REVIEW - the end-of-turn verdict on your whole play
            kind = 'invalid' if c['kind'] == 'invalid' else (('good' if c.get('review_ok', True) else 'critique') if review else 'info')
            said, colour = c['neutral'], KIND_COLORS['invalid' if kind == 'invalid' else 'info']
            if verdict_shown(game):   # hints hidden: still good or not
                kind = c['kind']; said, colour = c['verdict'], KIND_COLORS[kind]
            pygame.draw.rect(self.screen, KIND_COLORS[kind] if kind != 'info' else (90, 90, 90), self.R((p.x, p.y, 5, p.h)), border_top_left_radius=self.S(8), border_bottom_left_radius=self.S(8))
            y = self.rich_text([(said, colour, False)], p.y + 7, p.bottom) if said else p.y + 7
            if review: y = self.rich_text([(review, KIND_COLORS[kind], False)], y, p.bottom)
            self.rich_text([(c['status'], COLOR_TEXT, True)], y, p.bottom)
            return
        pygame.draw.rect(self.screen, KIND_COLORS[c['kind']], self.R((p.x, p.y, 5, p.h)), border_top_left_radius=self.S(8), border_bottom_left_radius=self.S(8))
        y = self.rich_text([(c['verdict'], KIND_COLORS[c['kind']], False)], p.y + 7, p.bottom) if c['verdict'] else p.y + 7
        if c['plan']:
            # Plan (2 moves left): 1. 13/11  2. 13/11  3. 6/4  4. 6/4 - makes ...   (played grey, next cyan, rest white)
            label = f"Book plan, {book_for(game.book_key)[0]}" if game.plan_kind == 'book' and game.book_key else "Plan"
            spans = [(f"{label} ({c['status'][:-1]}): ", COLOR_TEXT, True)]
            for n, mv in enumerate(c['done'] + c['plan']):
                if n < len(c['done']): style = ((125, 130, 127), False)
                elif n == len(c['done']): style = (COLOR_HINT_SRC, True)
                else: style = (COLOR_TEXT, False)
                spans.append((f"{n + 1}. {mv}  ", *style))
            used = len(textwrap.wrap(c['verdict'], MSG_WRAP))
            full = "".join(t for t, _, _ in spans) + f"- {c['why']}"
            why = c['why'] if used + len(textwrap.wrap(full, MSG_WRAP)) <= 5 else c.get('why_short', c['why'])
            spans.append((f"- {why}", (190, 196, 192), False))
            self.rich_text(spans, y, p.bottom)
        else:   # turn over: how this turn went, then the prompt to roll
            if c['why']:
                m, n = game.turn_score
                y = self.rich_text([(c['why'], KIND_COLORS['good'] if m == n else KIND_COLORS['critique'], False)], y, p.bottom)
            self.rich_text([(c['status'], COLOR_TEXT, True)], y, p.bottom)

    @staticmethod
    def count_at(view, colour, s):
        """How many `colour` checkers ('w'/'b') are on s (a point index, 'bar' or 'off'); view = real_view(game)."""
        board, bar, off = view
        side = 0 if colour == 'w' else 1
        if s == 'bar': return bar[side]
        if s == 'off': return off[side]
        v = board[s]
        return max(v, 0) if colour == 'w' else max(-v, 0)

    def draw_cube(self, game):
        """The doubling cube on the bar; a double on offer pulses gold."""
        c = cube_spot(game)
        if not c: return
        (x, y), value, offered = c
        h = CUBE_SIZE / 2
        pygame.draw.rect(self.screen, (10, 10, 10), self.R((x - h + 2, y - h + 3, CUBE_SIZE, CUBE_SIZE)), border_radius=self.S(6))
        pygame.draw.rect(self.screen, (238, 226, 196), self.R((x - h, y - h, CUBE_SIZE, CUBE_SIZE)), border_radius=self.S(6))
        if offered:
            glow = int(170 + 85 * math.sin(time.time() * 5))
            pygame.draw.rect(self.screen, (255, glow, 40), self.R((x - h - 3, y - h - 3, CUBE_SIZE + 6, CUBE_SIZE + 6)),
                             max(2, self.S(3)), border_radius=self.S(8))
        elif game.can_double():
            pygame.draw.rect(self.screen, (190, 140, 230), self.R((x - h, y - h, CUBE_SIZE, CUBE_SIZE)), max(1, self.S(2)), border_radius=self.S(6))
        self.text(self.fnt, str(value), (60, 30, 20), (x, y), "center")

    def render(self, game, sug):
        if self.reviewing is not None and not getattr(game, 'is_review', False):   # a mistake on the board instead
            if self.reviewing < len(game.mistakes): return self.render(self.review_engine(game), None)
            self.reviewing = None
        scr, now = self.screen, time.time()
        scr.fill(COLOR_BG)

        # Slide animation + sounds: (colour, src, dst, hit, start, seconds). Cancelled if undo/redo changed the board underneath it.
        if game.move_seq != self._seen_seq:
            self._seen_seq = game.move_seq
            lm = game.last_move
            self._anim = (*lm[:4], now, lm[4] if len(lm) > 4 else ANIM_T) if lm else None
            if game.last_move: self.play('hit' if game.last_move[3] else 'move')
        if game.invalid_seq != self._seen_inv:
            self._seen_inv = game.invalid_seq
            self.play('invalid')
        # Two players, Black to move: the engine's board is turned round. Draw the real one; R turns engine points
        # into screen points, `me` is the colour of whoever is moving.
        view = real_view(game)
        board, bar, off = view
        flip = game.flipped
        R = lambda i: real_pt(game, i)
        me, them = ('b', 'w') if flip else ('w', 'b')
        my_side = 1 if flip else 0
        anim = self._anim if self._anim and now - self._anim[4] < self._anim[5] and self.count_at(view, self._anim[0], self._anim[2]) > 0 else None
        if anim or not game.coaching or game.practice is not None: sug = None   # hints: coaching on, not in a puzzle, once landed

        if self.layout != 'phone':   # header row 1: pip counts (the phone layout shows them in its column)
            wp, bp = real_pips(game)
            if game.two_player:
                self.text(self.fnt, f"WHITE PIPS: {wp} ({race_text(wp, bp)})", COLOR_WHITE, (FIELD_X, 6))
                self.text(self.fnt, f"BLACK PIPS: {bp}", (180, 180, 180), (FIELD_R, 6), "topright")
            else:
                self.text(self.fnt, f"PIPS: {wp} ({race_text(wp, bp)})", COLOR_WHITE, (FIELD_X, 6))
                self.text(self.fnt, f"OPP PIPS: {bp}", (180, 180, 180), (FIELD_R, 6), "topright")

        # Frame, felt, bar, bear-off trays (recessed into the left frame: White's by its home at the bottom, Black's at the top)
        frame = (FIELD_X - FRAME, FIELD_Y - FRAME, FIELD_R - FIELD_X + 2*FRAME, FIELD_H + 2*FRAME)
        pygame.draw.rect(scr, COLOR_FRAME, self.R(frame), border_radius=self.S(12))
        pygame.draw.rect(scr, COLOR_FRAME_EDGE, self.R(frame), self.S(2), border_radius=self.S(12))
        for x0, x1 in [(FIELD_X, BAR_X), (BAR_X + BAR_W, FIELD_R)]:
            pygame.draw.rect(scr, COLOR_BOARD, self.R((x0, FIELD_Y, x1 - x0, FIELD_H)))
            pygame.draw.rect(scr, COLOR_FRAME_EDGE, self.R((x0 - 2, FIELD_Y - 2, x1 - x0 + 4, FIELD_H + 4)), self.S(2))
        pygame.draw.rect(scr, COLOR_BAR, self.R((BAR_X, FIELD_Y - FRAME, BAR_W, FIELD_H + 2*FRAME)))
        tray_x = min(fx(FIELD_X - FRAME + 3), fx(FIELD_X - 3))   # left edge of the tray, whichever side it is on
        for y0 in (FIELD_Y, FIELD_Y + FIELD_H / 2 + 4):
            pygame.draw.rect(scr, (66, 40, 20), self.R((tray_x, y0, FRAME - 6, FIELD_H / 2 - 4)), border_radius=self.S(4))

        # Points, hint/invalid tints, numbers on the frame
        src, dst = (R(sug[0]), R(sug[1])) if sug else (None, None)
        targets = move_targets(game)   # engine points (OFF: the mover's tray)
        shown_targets = {R(t) for t in targets}
        invalid = R(game.invalid)
        if (game.invalid, game.msg) != self._inv_key: self._inv_key, self._inv_t = (game.invalid, game.msg), now
        flash = max(0.0, 1 - (now - self._inv_t) / 0.6)
        for i in range(24):
            tri = triangle(i)
            self.poly(tri, COLOR_PT_A if i % 2 == 0 else COLOR_PT_B)
            num_col = COLOR_NUM
            if i == invalid:
                self.poly(tri, (255, 40, 40, int(110 + 120 * flash))); num_col = (255, 70, 70)
            elif i in shown_targets: self.poly(tri, (*COLOR_TARGET, 85)); num_col = COLOR_TARGET
            elif i == src: self.poly(tri, (*COLOR_HINT_SRC, 80)); num_col = COLOR_HINT_SRC
            elif i == dst: self.poly(tri, (*COLOR_HINT_DST, 80)); num_col = COLOR_HINT_DST
            if num_col != COLOR_NUM:
                pygame.draw.polygon(scr, num_col, [self.P(p) for p in tri], self.S(3 if i == invalid else 2))
            cx = point_x(i) + PT_W / 2
            num = 24 - i if flip else i + 1   # the numbers of whoever is moving (Black counts from its own side)
            self.text(self.num_fnt, str(num), num_col, (cx, FIELD_Y + FIELD_H + FRAME / 2 if i < 12 else FIELD_Y - FRAME / 2), "center")

        # Checkers on points, the bar and in the trays (the one being animated is drawn separately, on top)
        mover, a_src, a_dst, a_hit = anim[:4] if anim else (None, None, None, False)
        other = 'b' if mover == 'w' else 'w'
        for i in range(24):
            colour, n = ('w' if board[i] > 0 else 'b'), abs(board[i])
            for j in range(n):
                if anim and i == a_dst and j == n - 1: continue
                self.checker(slot_center(i, j, n), colour == 'w')
        for colour, side in (('w', 0), ('b', 1)):
            for j in range(bar[side]):
                if anim and a_hit and colour == other and j == bar[side] - 1: continue   # still shrinking on its point
                self.checker(bar_slot(colour, j, bar[side]), colour == 'w')
            for k in range(off[side]):
                if anim and a_dst == 'off' and colour == mover and k == off[side] - 1: continue
                x, y = tray_slot(colour, k)
                pygame.draw.rect(scr, (242, 240, 230) if colour == 'w' else (30, 30, 34), self.R((x - 7, y - 2, 14, 4)), border_radius=self.S(2))
        self.draw_cube(game)
        if game.selected is not None:
            s = R(game.selected)
            n = self.count_at(view, me, s) if s != BAR else 0
            sel = bar_slot(me, bar[my_side] - 1, bar[my_side]) if s == BAR else slot_center(s, max(n, 1) - 1, n)
            self.ring(sel, CHIP_R + 2, (0, 230, 0), 3)
            for t in shown_targets:   # where it would land
                n = self.count_at(view, me, t) if t != OFF else 0
                self.ring(tray_slot(me, off[my_side]) if t == OFF else slot_center(t, n, n + 1), 7 if t == OFF else CHIP_R - 1, COLOR_TARGET, 2)

        if anim:
            t = (now - anim[4]) / anim[5]; e = 1 - (1 - t) ** 3      # ease-out
            ns, nd = self.count_at(view, mover, a_src), self.count_at(view, mover, a_dst)
            a, b = spot(None, mover, a_src, ns, ns + 1), spot(None, mover, a_dst, nd - 1, nd)
            if a_hit: self.checker(slot_center(a_dst, 0), other == 'w', r=CHIP_R * (1 - e))   # hit blot shrinks off to the bar
            self.checker(bezier(a, arc_ctrl(a, b), b, e), mover == 'w', lift=4 * math.sin(math.pi * t))

        # The whole plan: numbered arrows. Next step bright (pulsing cyan ring, magenta ghost); later steps faded.
        badges = []   # step numbers: (centre, fill, edge, number, number colour), drawn last, above the dice
        if getattr(game, 'review_arrows', None):   # a mistake: what you played in red, the coach's play numbered in cyan
            played, best = game.review_arrows
            for a, b, off in self.plan_steps(game.pos, [played]):
                self.ring(b, 6 if off else CHIP_R - 1, (235, 70, 70), 2)
                self.arrow(a, b, (235, 70, 70))
            for k, (a, b, off) in enumerate(self.plan_steps(game.pos, best)):
                self.ring(b, 6 if off else CHIP_R - 1, COLOR_HINT_SRC, 2)
                self.arrow(a, b, COLOR_HINT_SRC, width=3)
                badges.append((bezier(a, arc_ctrl(a, b), b, 0.5), COLOR_HINT_SRC, (20, 20, 20), k + 1, (10, 10, 10)))
        if sug:
            plan = current_plan(game)
            steps = self.plan_steps(game.pos, plan, flip)
            for a, b, off in reversed(steps[1:]):
                self.circle(b, 7 if off else CHIP_R, (*COLOR_HINT_DST, 30))
                self.ring(b, 6 if off else CHIP_R - 1, (215, 150, 225), 1)
                self.arrow(a, b, (200, 150, 210), width=3)
            a, b, off = steps[0]
            pulse = 0.5 + 0.5 * math.sin(now * 5)
            self.circle(b, 7 if off else CHIP_R, (*COLOR_HINT_DST, 70))
            self.ring(b, 6 if off else CHIP_R - 1, COLOR_HINT_DST, 2)
            self.arrow(a, b, (255, 110, 255))
            self.ring(a, CHIP_R + 2, (*COLOR_HINT_SRC, int(140 + 115 * pulse)), 3)
            first_no = len(game.turn_moves) + 1
            for k, (a, b, _) in reversed(list(enumerate(steps))):
                n, nth = plan.count(plan[k]), plan[:k].count(plan[k])   # repeated moves: spread badges along the arrow
                badges.append((bezier(a, arc_ctrl(a, b), b, (nth + 1) / (n + 1)), COLOR_HINT_SRC if k == 0 else (30, 30, 30),
                               (20, 20, 20) if k == 0 else (200, 150, 210), first_no + k, (10, 10, 10) if k == 0 else COLOR_TEXT))

        # The opponent's moves (Show opponent's moves ON): numbered orange arrows, from its turn until you roll
        if game.opp_arrows and game.opp_trail:   # (two players: the other player's moves, in its colour)
            steps = [(s, d, spot(None, them, s, sj, sn), spot(None, them, d, dj, dn)) for s, d, sj, sn, dj, dn in game.opp_trail]
            for _, d, a, b in steps:
                self.ring(b, 6 if d == 'off' else CHIP_R + 1, COLOR_OPP_ARROW, 2)
                self.arrow(a, b, COLOR_OPP_ARROW, width=3)
            moves = [(s, d) for s, d, _, _ in steps]
            for k, (s, d, a, b) in enumerate(steps):
                n, nth = moves.count((s, d)), moves[:k].count((s, d))   # repeated moves: spread badges along the arrow
                badges.append((bezier(a, arc_ctrl(a, b), b, (nth + 1) / (n + 1)), COLOR_OPP_ARROW, (20, 20, 20), k + 1, (10, 10, 10)))

        # Forced moves the game played for you (coach on HINTS): green arrows numbered by move, until your turn ends
        if game.coaching and game.forced_trail:
            moves = [(s, d) for s, d, *_ in game.forced_trail]
            for k, (s, d, sj, sn, dj, dn, no) in enumerate(game.forced_trail):
                a, b = spot(None, me, R(s), sj, sn), spot(None, me, R(d), dj, dn)
                self.ring(b, 6 if d == 'off' else CHIP_R + 1, COLOR_FORCED_ARROW, 2)
                self.arrow(a, b, COLOR_FORCED_ARROW, width=3)
                n, nth = moves.count((s, d)), moves[:k].count((s, d))
                badges.append((bezier(a, arc_ctrl(a, b), b, (nth + 1) / (n + 1)), COLOR_FORCED_ARROW, (20, 20, 20), no, (10, 10, 10)))

        # Dice: yours on the right half, the opponent's (dark) on the left half; played dice greyed out.
        # Drawn over the arrows so a long arrow never hides them; the step numbers go on top of everything.
        cy = FIELD_Y + FIELD_H / 2
        mine_x, theirs_x = dice_x(game)   # two players: Black's dice on the left, also while it moves
        for dv, cx, dark, who in [(dice_view(game), mine_x, flip, 'white'), (opp_dice_view(game), theirs_x, not flip, 'black')]:
            rolling = game.is_rolling and game.rolling_for == who
            for n, (v, used) in enumerate(dv):
                jit = (random.uniform(-4, 4), random.uniform(-4, 4)) if rolling else (0, 0)
                self.die((cx + (n - (len(dv) - 1) / 2) * 54, cy), v, used, jitter=jit, dark=dark)
        if game.chosen_die is not None:   # the die you tapped: a gold frame
            c = next((c for c, v, used in die_spots(game) if v == game.chosen_die and not used), None)
            if c: pygame.draw.rect(self.screen, (255, 200, 40), self.R((c[0] - 27, c[1] - 27, 54, 54)), max(2, self.S(3)), border_radius=self.S(9))

        for m, fill, edge, num, ink in badges:
            self.circle(m, 10, fill)
            self.ring(m, 10, edge, 1.5)
            self.text(self.num_fnt, str(num), ink, m, "center")

        if self.layout == 'phone': self.render_phone(game); return

        # Buttons (greyed when unavailable, lighter on hover) and hand cursor. The big button follows the turn.
        label = {'white_done': "END TURN", 'black_start': "START", 'over': "NEW GAME"}.get(game.phase, "ROLL DICE")
        go_sub = "Space"
        if game.phase == 'white_move' and game.coaching:   # during your move the big button accepts the coach's plan
            label, go_sub = ("PLAYING..." if game.autoplay else "PLAY PLAN"), "Enter"
        go_ok = game.can_roll() or game.can_hand_over() or game.phase == 'over' or game.can_accept_plan()
        undo, redo_ok = ("UNDO", "Ctrl+Z", game.can_undo()), game.can_redo()
        undo_col = (220, 85, 85)
        if game.phase == 'cube_offer': label, go_sub, go_ok, undo = "TAKE", "T", True, ("PASS", "P", True)
        elif game.can_double(): undo, undo_col = ("DOUBLE", "D", True), (150, 100, 200)
        if game.practice is not None: label, go_sub, go_ok = "NEXT PUZZLE", "Space", game.phase == 'white_done'
        if getattr(game, 'is_review', False):
            label, go_sub, go_ok = ("NEXT" if self.reviewing + 1 < self.review_count else "DONE"), "Space", True
            undo, redo_ok = ("BACK", "Backspace", self.reviewing > 0), False
        mouse = self.to_logical(pygame.mouse.get_pos())
        hand = False
        shown = self.show_undo or getattr(game, 'is_review', False)   # MENU > Undo button: HIDDEN takes them away
        for rect, text, sub, base, fg, ok in [
                (self.btn_r, label, go_sub, (220, 220, 220), (20, 20, 20), go_ok),
                (self.btn_u, *undo[:2], undo_col, COLOR_TEXT, undo[2]),
                (self.btn_redo, "REDO", "Ctrl+Y", (85, 95, 220), COLOR_TEXT, redo_ok)]:
            if not shown and (rect is self.btn_redo or (rect is self.btn_u and undo[0] == "UNDO")): continue
            hov = rect.collidepoint(mouse)
            hand |= hov and ok
            self.button(rect, text, sub, base, fg, ok, hov)
        for rect, draw in [(self.btn_coach, lambda h: self.coach_switch(game, h)), (self.btn_new, self.new_game_button),
                           (self.btn_sound, self.sound_button), (self.btn_opp, lambda h: self.opponent_button(game, h)),
                           (self.btn_rules, self.rules_button), (self.btn_home, self.home_button),
                           (self.btn_auto, lambda h: self.auto_button(game, h)), (self.btn_menu, self.menu_button)]:
            hov = rect.collidepoint(mouse)
            hand |= hov
            draw(hov)
        self.score_text(game)
        if hand != self._hand:
            self._hand = hand
            pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_HAND if hand else pygame.SYSTEM_CURSOR_ARROW)

        self.coach_panel(game)
        if self.confirming():   # make the question impossible to miss
            p = self.panel
            pygame.draw.rect(scr, (60, 30, 30), self.R(p), border_radius=self.S(8))
            self.text(self.msg_bold, "Start a new game? Your current game will be lost.", (255, 190, 60), (p.x + 16, p.y + 14))
            self.text(self.msg_fnt, "Click CONFIRM? or press Y to start over. Press Esc (or wait 3 seconds) to keep playing.", COLOR_TEXT, (p.x + 16, p.y + 42))
        if self.overlay: self.desk_overlay(game)
        if self.entry: self.entry_box()

    # ------------------------------------------------------------------------------------------------------------
    # Touch layout (landscape). Phones: the board fills the height on the left; a column on the right holds the coach
    # summary, the big action button, UNDO/REDO and a menu. Tablets: the board fills the width; the same controls
    # sit in a strip below it. Everything here is in screen pixels, sized from the screen height so it stays
    # readable and easy to tap whatever the device.
    # ------------------------------------------------------------------------------------------------------------
    def phone_resize(self, w, h):
        pad, u = max(4, h // 60), h / 100                                # u = 1% of the screen height
        # A gap above the board: Android takes a swipe that starts at the top edge (it shows the status bar and
        # leaves full screen), so the top checkers sit below that zone and can be dragged.
        gap = int(5 * u)
        if w / h >= 1.9:   # phone shapes (about 20:9): the board fills the height, the controls in a column beside it
            col_w = max(int(w * 0.16), int(h * 0.38))
            # The board is 460 logical px tall (frame included). Narrow the points so its width fits beside the
            # column, but not below 56 (still about 7 mm to tap on a phone); wide screens keep 74.
            k_full = (h - 2 * pad - gap) / 460
            room = (w - col_w - 3 * pad) / k_full                        # logical width the board may use
            set_point_width(int(max(56, min(74, (room - 2 * FRAME - BAR_W) / 12))))
            right = FIELD_R + FRAME                                      # board spans logical 8..right x 60..520
            self.k = max(0.2, min((w - col_w - 3 * pad) / (right - 8), k_full))
            self.ox = round(pad - 8 * self.k)                            # whole pixels: the drawing calls need ints
            self.oy = round(gap + (h - gap - 460 * self.k) / 2 - 60 * self.k)
            x0 = int(right * self.k + self.ox) + pad
            self.col = c = pygame.Rect(x0, pad, w - x0 - pad, h - 2 * pad)
            self.p_menu = pygame.Rect(c.x, c.y, int(12 * u), int(12 * u))
            self.p_pips = (self.p_menu.right + self.p_menu.w // 4, self.p_menu.y)
            self.p_card = pygame.Rect(c.x, c.y + int(14 * u), c.w, int(42 * u))
            hint_w = c.w * 32 // 100
            self.p_hint = pygame.Rect(c.x, c.y + int(59 * u), hint_w, int(19 * u))
            self.p_go = pygame.Rect(c.x + hint_w + int(1.5 * u), c.y + int(59 * u), c.w - hint_w - int(1.5 * u), int(19 * u))
            self.p_whatif = pygame.Rect(c.x, c.bottom - int(17 * u), hint_w, int(17 * u))   # under HINT
            gx = self.p_go.x
            half = (c.right - gx - int(1.5 * u)) // 2
            self.p_undo = pygame.Rect(gx, c.bottom - int(17 * u), half, int(17 * u))
            self.p_redo = pygame.Rect(c.right - half, c.bottom - int(17 * u), half, int(17 * u))
            self.sheet = pygame.Rect(pad, pad, x0 - 2 * pad, h - 2 * pad)   # menu / details cover the board
        else:              # tablet shapes (3:2, 16:10, 4:3): the board across the full width, the controls in a strip below
            set_point_width(74)
            right = FIELD_R + FRAME
            self.k = max(0.2, min((w - 2 * pad) / (right - 8), (h * 0.78 - 2 * pad) / 460))   # the gap comes off the strip
            bw, bh = (right - 8) * self.k, 460 * self.k
            self.ox = round((w - bw) / 2 - 8 * self.k)
            self.oy = round(pad + gap - 60 * self.k)
            top = int(pad + gap + bh) + pad
            self.col = s = pygame.Rect(pad, top, w - 2 * pad, h - top - pad)
            left_w, right_w = int(max(13 * u, w * 0.13)), int(max(30 * u, w * 0.26))
            self.p_menu = pygame.Rect(s.x, s.y, left_w, int(s.h * 0.42))
            self.p_pips = (s.x + left_w // 10, self.p_menu.bottom + int(s.h * 0.08))
            gx = s.right - right_w
            self.p_go = pygame.Rect(gx, s.y, right_w, int(s.h * 0.52))
            self.p_hint = pygame.Rect(gx - int(right_w * 0.42) - int(u), s.y, int(right_w * 0.42), int(s.h * 0.52))
            half, uh = (right_w - int(u)) // 2, s.h - int(s.h * 0.52) - int(u)
            self.p_undo = pygame.Rect(gx, s.bottom - uh, half, uh)
            self.p_redo = pygame.Rect(s.right - half, s.bottom - uh, half, uh)
            self.p_whatif = pygame.Rect(self.p_hint.x, s.bottom - uh, self.p_hint.w, uh)   # under HINT
            self.p_card = pygame.Rect(s.x + left_w + pad, s.y, self.p_hint.x - pad - (s.x + left_w + pad), s.h)
            self.sheet = pygame.Rect(pad, pad + gap, w - 2 * pad, int(bh))  # menu / details cover the board
        f = lambda px, bold=False: (pygame.font.Font(None, int(px * 1.3)) if WEB else pygame.font.SysFont("Arial", int(px), bold))
        k = self.text_scale   # MENU > Text size
        self.pf_big, self.pf, self.pf_small = f(6.5 * u * k, True), f(4.6 * u * k, True), f(4.2 * u * k)

    def phone_text(self, font, s, color, pos, anchor="topleft"):
        img = font.render(s, True, color)
        rect = img.get_rect(**{anchor: pos}); self.screen.blit(img, rect)
        return rect

    def wrap_px(self, font, text, width):
        """Wrap text to a pixel width (phone fonts vary, so wrap by measuring rather than by character count)."""
        lines = []
        for para in text.split("\n"):
            line = ""
            for word in para.split():
                test = (line + " " + word).strip()
                if font.size(test)[0] <= width or not line: line = test
                else: lines.append(line); line = word
            lines.append(line)
        return lines

    def phone_words(self, game, text):
        """The engine's messages mention keys (SPACE); on a phone they mean the big button."""
        label = self.phone_go_label(game)[0].title()
        for key_text in ("Press SPACE to roll.", "Press SPACE for a new game.", "Press SPACE to let it roll.", "Press SPACE to roll"):
            text = text.replace(key_text, f"Tap {label}.")
        return text

    def phone_summary(self, game):
        """(lines, stripe colour) for the coach card: what just happened, the next move, how many are left."""
        lines, colour = self.phone_summary_raw(game)
        return [self.phone_words(game, l) for l in lines], colour

    def phone_summary_raw(self, game):
        c = game.coach
        if getattr(game, 'is_review', False): return [c['verdict'], c['status']], KIND_COLORS['critique']   # a mistake, in full
        if game.is_rolling: return ["Rolling..."], KIND_COLORS['info']
        if c.get('whatif'):   # WHAT IF: a trial roll being played, or the verdict on it (then put back)
            w = c['whatif']
            if w[0] == 'trying':
                so_far = f"So far: {', '.join(w[1])}. " if w[1] else ""
                return ["What if?", f"{so_far}{w[2]} move{'s' if w[2] != 1 else ''} to go. Tap WHAT IF to cancel."], (120, 200, 230)
            return ([f"What if {', '.join(w[1])}? " + ("Good." if w[2] else "Not the best - tap for why."),
                     "Not played: everything is back.", c['status']], KIND_COLORS['good' if w[2] else 'critique'])
        if not game.coaching:
            review = c.get('review', '') if game.review else ''
            kind = 'invalid' if c['kind'] == 'invalid' else (('good' if c.get('review_ok', True) else 'critique') if review else 'info')
            lines = [c['neutral']] if c['neutral'] else []
            if verdict_shown(game):   # hints hidden: still good or not
                kind, lines = c['kind'], ["Good move." if c['kind'] == 'good' else "Not the coach's move - tap for why."]
            if review: lines.append("Review ready - tap to read" if len(review) > 90 else review)
            return lines + [c['status']], KIND_COLORS[kind] if kind != 'info' else (110, 110, 110)
        lines, kind = [], c['kind']
        if kind == 'good': lines.append("Good move.")
        elif kind == 'critique': lines.append("Not the coach's move - tap for why.")
        elif c['verdict']: lines.append(c['verdict'])
        if c['plan']:
            lines.append("Next: " + "  ".join(c['plan'][:4]))
            lines.append(c['status'] + "  Tap for why.")
        else:
            if c['why']: lines.append(c['why'])
            lines.append(c['status'])
        return lines, KIND_COLORS[kind]

    def phone_details(self, game):
        """The full coach text for the details sheet."""
        c, parts = game.coach, []
        if c.get('whatif') and c['whatif'][0] == 'done': parts.append(c['verdict'])   # WHAT IF: the verdict, whatever the coach mode
        elif game.coaching or game.what_if:
            if c['verdict']: parts.append(c['verdict'])
            if c['plan']:
                label = f"Book plan, {book_for(game.book_key)[0]}" if game.plan_kind == 'book' and game.book_key else "Plan"
                parts.append(f"{label}: " + ", ".join(c['done'] + c['plan']) + ".")
            if c['why']: parts.append(c['why'])
        else:
            if verdict_shown(game): parts.append(c['verdict'])   # hints hidden: still good or not, and why
            elif c['neutral']: parts.append(c['neutral'])
            if game.review and c.get('review'): parts.append(c['review'])
        parts.append(c['status'])
        return self.phone_words(game, "\n\n".join(p for p in parts if p))

    def phone_button(self, rect, label, base, fg, ok, font=None):
        pygame.draw.rect(self.screen, (10, 10, 10), rect.move(0, max(2, rect.h // 25)), border_radius=rect.h // 5)
        pygame.draw.rect(self.screen, base if ok else (58, 58, 58), rect, border_radius=rect.h // 5)
        font = font or self.pf
        if font.size(label)[0] > rect.w * 0.9: font = self.pf   # long labels (PLAY PLAN) on narrow columns
        if font.size(label)[0] > rect.w * 0.9: font = self.pf_small
        img = font.render(label, True, fg if ok else (125, 125, 125))
        if img.get_width() > rect.w * 0.9:   # still too wide (narrow column, large text): shrink it to fit
            k = rect.w * 0.9 / img.get_width()
            img = pygame.transform.smoothscale(img, (int(img.get_width() * k), max(1, int(img.get_height() * k))))
        self.screen.blit(img, img.get_rect(center=rect.center))

    def phone_go_label(self, game):
        label = {'white_done': "END TURN", 'black_start': "START", 'over': "NEW GAME"}.get(game.phase, "ROLL")
        if game.practice is not None: return "NEXT PUZZLE", game.phase == 'white_done'
        if game.phase == 'cube_offer': return "TAKE", True
        if game.phase == 'white_move' and game.coaching: label = "PLAYING..." if game.autoplay else "PLAY PLAN"
        ok = game.can_roll() or game.can_hand_over() or game.phase == 'over' or game.can_accept_plan()
        return label, ok

    def phone_menu_rows(self, game):
        m, n = game.session
        mode = chosen_coach_mode(game)   # your setting, not the HINT
        note = (" (hidden - tap HINT to show)" if mode == "hints" else " (hint showing)") if game.hint_saved else ""
        on = lambda x: "ON" if x else "OFF"
        practice = ("leavepractice", "Leave practice") if game.practice is not None else ("practice", "Practice puzzles")
        return [("player", f"Player: {self.player}  (change)"),
                ("coaching", f"Coach: {mode.upper()}" + note), ("opponent", f"Opponent: {game.opp_level.upper()}"),
                ("rules", f"Rules: {'EGYPTIAN' if egyptian() else 'STANDARD'}"), ("home", f"Home board: {'RIGHT' if HOME_RIGHT else 'LEFT'}"),
                ("sound", f"Sound: {on(self.sound_on)}"), ("autoroll", f"Auto-roll: {on(game.autoroll)}"),
                ("autoforced", f"Auto-play forced moves: {on(game.auto_forced)}"),
                ("opparrows", f"Opponent's moves as arrows: {on(game.opp_arrows)}"),
                ("autorace", f"Auto-play the race: {on(game.auto_race)}"),
                ("owndice", f"Enter your own dice: {on(self.own_dice)}"), ("whostarts", starts_label(game)),
                ("twoplayer", play_against(game)), ("cube", f"Doubling cube: {on(game.cube_on)}"),
                ("cubehelp", "How the doubling cube works"), ("showundo", undo_label(self)),
                ("textsize", f"Text size: {'LARGE' if self.text_scale > 1 else 'NORMAL'}"),
                ("mistakes", f"Mistakes this game ({len(game.mistakes)})"), ("progress", "Your progress"),
                ("dicestats", "Dice statistics"), practice,
                ("new", "Tap again to start a new game" if self.confirming() else "New game"),
                (None, (f"Games: White {game.match2[0]} - {game.match2[1]} Black" if game.two_player else
                        f"Games: you {game.match[0]} - {game.match[1]} opponent    Coach score: " + (f"{m}/{n} ({round(100 * m / n)}%)" if n else "-"))
                       + f"      (version {BUILD})")]   # no Close row: tap MENU again

    def phone_menu_rects(self, game):
        return self.sheet_rects(self.phone_menu_rows(game))

    def sheet_rects(self, rows):
        """Rows of (action, label) laid out on the sheet that covers the board: [(action, label, rect)].
        Long lists go in two columns, with their last row (the scores, Cancel) across the bottom."""
        s = self.sheet
        if len(rows) <= 10:
            h = s.h // len(rows)
            return [(name, label, pygame.Rect(s.x + h // 4, s.y + i * h + 2, s.w - h // 2, h - 4)) for i, (name, label) in enumerate(rows)]
        body, tail = rows[:-1], rows[-1:]
        per = (len(body) + 1) // 2
        h = s.h // (per + len(tail))
        col = (s.w - h // 2) // 2
        out = [(name, label, pygame.Rect(s.x + h // 4 + (i // per) * col, s.y + (i % per) * h + 2, col - h // 6, h - 4))
               for i, (name, label) in enumerate(body)]
        return out + [(name, label, pygame.Rect(s.x + h // 4, s.y + (per + j) * h + 2, s.w - h // 2, h - 4))
                      for j, (name, label) in enumerate(tail)]

    def render_phone(self, game):
        scr, (w, h) = self.screen, self.screen.get_size()
        if h > w:   # held upright: the board needs landscape
            scr.fill(COLOR_BG)
            f = pygame.font.Font(None, max(24, w // 12)) if WEB else pygame.font.SysFont("Arial", max(18, w // 16), True)
            for i, line in enumerate(["Turn your phone", "sideways to play"]):
                self.phone_text(f, line, COLOR_TEXT, (w // 2, h // 2 + (i - 0.5) * f.get_linesize()), "center")
            return
        # Menu button and pip counts
        self.phone_button(self.p_menu, "MENU", (70, 70, 70), COLOR_TEXT, True, self.pf_small)
        wp, bp = real_pips(game)
        px, py = self.p_pips
        names = ("White", "Black") if game.two_player else ("You", "Opp")
        you = f"{names[0]} {wp} ({race_text(wp, bp, short=True)})"
        room = (self.p_card.x - px if self.p_card.x > px else self.col.right - px) - 4   # tablets: the card is to the right
        if self.pf_small.size(you)[0] > room: you = f"{names[0]} {wp}"   # no room for the race (large text, narrow column)
        self.phone_text(self.pf_small, you, COLOR_WHITE, (px, py))
        self.phone_text(self.pf_small, f"{names[1]} {bp}", (180, 180, 180), (px, py + self.pf_small.get_linesize()))
        # Coach card
        card = self.p_card
        pygame.draw.rect(scr, (32, 36, 34), card, border_radius=card.h // 12)
        lines, stripe = self.phone_summary(game)
        pygame.draw.rect(scr, stripe, (card.x, card.y, max(4, card.w // 40), card.h), border_radius=card.h // 12)
        y, pad = card.y + card.h // 16, card.w // 14
        wrapped = [l for text in lines for l in self.wrap_px(self.pf_small, text, card.w - 2 * pad)]
        room = (card.bottom - y) // self.pf_small.get_linesize()
        if len(wrapped) > room: wrapped = wrapped[:room - 1] + [wrapped[room - 1].rstrip(".") + "..."]
        for line in wrapped:
            self.phone_text(self.pf_small, line, COLOR_TEXT, (card.x + pad, y)); y += self.pf_small.get_linesize()
        # Big action button, UNDO / REDO
        label, ok = self.phone_go_label(game)
        review = getattr(game, 'is_review', False)
        if review: label, ok = ("NEXT" if self.reviewing + 1 < self.review_count else "DONE"), True
        self.phone_button(self.p_go, label, (220, 220, 220), (20, 20, 20), ok, self.pf_big)
        cube = None if review else cube_action(game)   # the HINT button doubles as DOUBLE / PASS for the cube
        if cube == 'pass': self.phone_button(self.p_hint, "PASS", (220, 85, 85), COLOR_TEXT, True, self.pf)
        elif cube == 'double': self.phone_button(self.p_hint, "DOUBLE", (150, 100, 200), COLOR_TEXT, True, self.pf)
        else:
            self.phone_button(self.p_hint, "HIDE" if game.coaching else "HINT", (230, 190, 60), (20, 20, 20),
                              not review and (game.hint_saved is not None or game.phase == 'white_move'), self.pf)
        if self.show_undo or review:   # MENU > Undo button: HIDDEN takes them away (BACK still steps through mistakes)
            self.phone_button(self.p_undo, "BACK" if review else "UNDO", (220, 85, 85), COLOR_TEXT,
                              self.reviewing > 0 if review else game.can_undo())
            self.phone_button(self.p_redo, "REDO", (85, 95, 220), COLOR_TEXT, game.can_redo() and not review)
        self.phone_button(self.p_whatif, "WHAT IF", (120, 200, 230) if game.what_if else (70, 110, 125),
                          (20, 20, 20) if game.what_if else COLOR_TEXT, not review and (game.what_if or game.can_what_if()), self.pf_small)
        # Overlays on top of the board: the menu or the full coach explanation
        if self.overlay:
            s = self.sheet
            shade = pygame.Surface(s.size, pygame.SRCALPHA); shade.fill((15, 18, 16, 235)); scr.blit(shade, s.topleft)
            if self.overlay in self.LISTS:
                for name, text, r in self.sheet_rects(self.overlay_rows(game)[1]):
                    if name and name != 'close': pygame.draw.rect(scr, (200, 60, 60) if name == 'new' and self.confirming() else (55, 60, 58), r, border_radius=r.h // 5)
                    font = self.pf if self.pf.size(text)[0] < r.w - r.h // 2 else self.pf_small
                    self.phone_text(font, text, COLOR_TEXT if name else (190, 196, 192), (r.x + r.h // 3, r.centery), "midleft")
            elif self.overlay == 'dice':
                box, rects = self.dice_rects()
                self.phone_text(self.pf, self.dice_title(game), COLOR_TEXT, (box.centerx, box.y + box.h // 6), "center")
                for v, r in rects:
                    pygame.draw.rect(scr, (232, 230, 220), r, border_radius=r.h // 6)
                    self.phone_text(self.pf_big, str(v), (20, 20, 20), r.center, "center")
                self.phone_text(self.pf_small, "Tap outside the dice to cancel.", (190, 196, 192), (box.centerx, box.bottom - box.h // 8), "center")
            else:
                y, pad = s.y + s.h // 20, s.w // 30
                pages = self.phone_pages(game)
                n = min(self.page_no, len(pages) - 1)
                tail = f"(Tap for more: page {n + 1} of {len(pages)}.)" if n + 1 < len(pages) else "(Tap anywhere to close.)"
                for line in pages[n] + ["", tail]:
                    if y + self.pf_small.get_linesize() > s.bottom: break
                    self.phone_text(self.pf_small, line, COLOR_TEXT, (s.x + pad, y)); y += self.pf_small.get_linesize()
        if self.entry: self.entry_box()

    def phone_tap(self, pos, game):
        """What a tap in the phone column or an open overlay does: an action name, or None to pass it to the board."""
        if self.overlay in self.LISTS:
            for name, _, r in self.sheet_rects(self.overlay_rows(game)[1]):
                if r.collidepoint(pos) and name: return name
            if self.p_menu.collidepoint(pos): return 'close'   # MENU again closes it
            return 'close' if self.sheet.collidepoint(pos) or self.overlay != 'menu' else None
        if self.overlay == 'dice':
            for v, r in self.dice_rects()[1]:
                if r.collidepoint(pos): return ('die', v)
            return 'close'
        if self.overlay:   # details, progress...: a tap turns the page, or closes the last one
            return 'nextpage' if self.page_no + 1 < len(self.phone_pages(game)) else 'close'
        for name, r in (('menu', self.p_menu), ('details', self.p_card), ('go', self.p_go), ('hint', self.p_hint),
                        ('undo', self.p_undo), ('redo', self.p_redo), ('whatif', self.p_whatif)):
            if name in ('undo', 'redo') and not self.show_undo and self.reviewing is None: continue   # hidden
            if r.collidepoint(pos): return (cube_action(game) or name) if name == 'hint' else name
        return None

roll_snd = None

def find_file(name):
    """Look next to the script/exe first, then inside the PyInstaller bundle. Returns None if missing."""
    dirs = [os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))]
    if hasattr(sys, "_MEIPASS"): dirs.append(sys._MEIPASS)
    for d in dirs:
        if os.path.exists(os.path.join(d, name)): return os.path.join(d, name)
    return None

WEB = sys.platform == "emscripten"   # running in a web browser (built with pygbag)
BUILD = "08 Nov 06:54"                        # build_web.bat stamps the date and time here, shown in the phone menu

def js(code):
    """Run JavaScript in the web page and return the result as text (web build only)."""
    import platform as page   # in pygbag this is the bridge to the page (on desktop, the standard library module)
    return str(page.window.eval(code))

# pygbag mis-places mouse positions on high-resolution screens (laptops at 200%, every phone), so the page itself
# records where each press landed on the canvas (as a fraction of its size). A touch held for half a second
# counts as a right-click (button 3): the long-press that replaces right-click on phones. A drag is a press where
# the finger went down plus a drop (button 4) where it was lifted.
WEB_INPUT_JS = """
window.bgq = [];
const c = document.getElementById('canvas');
let down = null, timer = null;
const at = e => { const r = c.getBoundingClientRect(); return [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height]; };
// Phones: the first tap asks for full screen (no address bar or status bar) and locks the screen sideways.
// Browsers only allow that from a tap. Only the first: after a swipe from the edge, Android shows its buttons
// for a few seconds and then goes back to full screen by itself.
let triedFull = false;
const goFull = () => { const d = document.documentElement;
  if (document.fullscreenElement || !d.requestFullscreen) return;
  d.requestFullscreen({navigationUI: 'hide'}).then(() => { try { screen.orientation.lock('landscape').catch(() => {}); } catch (err) {} })
   .catch(() => {}); };
c.addEventListener('pointerdown', e => {
  const [x, y] = at(e);
  if (e.pointerType !== 'mouse' && !triedFull) { triedFull = true; goFull(); }
  down = {x, y, b: e.button, long: false};
  clearTimeout(timer);
  if (e.pointerType !== 'mouse') timer = setTimeout(() => { if (down) { down.long = true; window.bgq.push([down.x, down.y, 3]);
                                                      if (navigator.vibrate) navigator.vibrate(25); } }, 500);
});
c.addEventListener('pointermove', e => { if (!down) return; const [x, y] = at(e);
  const r = c.getBoundingClientRect(); if (Math.hypot((x - down.x) * r.width, (y - down.y) * r.height) > 15) clearTimeout(timer); });
c.addEventListener('pointerup', e => { clearTimeout(timer);
  if (down && !down.long) { window.bgq.push([down.x, down.y, down.b === 2 ? 3 : 1]);
    const [x, y] = at(e), r = c.getBoundingClientRect();
    if (Math.hypot((x - down.x) * r.width, (y - down.y) * r.height) > 20) window.bgq.push([x, y, 4]); }
  down = null; });
c.addEventListener('pointercancel', () => { clearTimeout(timer); down = null; });
c.addEventListener('contextmenu', e => e.preventDefault());
// Android's Back button closes the app (it drops out of the running apps). So each tap keeps one extra page
// in the history (browsers only count ones added during a tap): Back uses it up and the game opens or closes
// its menu instead (button 5). Back again before any tap leaves the game as usual.
let backArmed = false;
c.addEventListener('pointerdown', () => { if (!backArmed) { history.pushState({bgcoach: 1}, ''); backArmed = true; } });
window.addEventListener('popstate', () => { backArmed = false; window.bgq.push([0, 0, 5]); });
"""

def web_presses():
    """Presses recorded by the page since last frame: [(fraction_x, fraction_y, button)]."""
    return json.loads(js("JSON.stringify(window.bgq ? window.bgq.splice(0) : [])"))

VISIBLE_JS = ("(() => { const v = window.visualViewport, d = document.documentElement;"
              " return [Math.round(v ? v.width : d.clientWidth), Math.round(v ? v.height : d.clientHeight)]; })()")

def web_screen_size():
    """The visible part of the page, in CSS pixels. Not innerWidth/innerHeight: on phones those can describe the
    whole (possibly larger) page, which made the game measure and grow itself in a loop."""
    w, h = json.loads(js(f"JSON.stringify({VISIBLE_JS})"))
    s = 1.0   # pygbag shows only part of a larger-than-page surface on high-DPI screens, so draw at page size
    return max(320, int(w * s)), max(200, int(h * s))

def web_fit_canvas():
    """Make the canvas fill the page. pygbag keeps the on-page shape it chose at start-up, so after turning the
    phone sideways it would squeeze the landscape picture into the old upright strip."""
    js(f"""const [w, h] = {VISIBLE_JS}, c = document.getElementById('canvas'), s = c.style;
           document.documentElement.style.overflow = document.body.style.overflow = 'hidden';   // no scrolling page
           s.position = 'fixed'; s.inset = 'auto'; s.left = s.top = '0px'; s.margin = '0px';   // pinned top-left
           s.width = w + 'px'; s.height = h + 'px';""")

def web_wants_phone_layout():
    """Touch screens (phones, tablets) get the phone layout; add ?phone to the address to try it on a laptop."""
    return js("(matchMedia('(pointer: coarse)').matches || location.search.includes('phone')) ? 1 : 0") == "1"

DEFAULT_SETTINGS = {"coach_mode": "hints", "sound": True, "opponent": "strong", "rules": "egyptian", "home": "left",
                    "autoroll": False,   # off: you roll your own dice after the opponent's turn
                    "autoforced": True,  # on: when only one way to play is left, it plays itself
                    "opparrows": True,   # on: the opponent's moves show as numbered arrows until you roll
                    "hidehints": False,  # coach on HINTS but HIDE pressed: stays hidden until HINT, even after a restart
                    "owndice": False,    # on: you tap in your own dice (e.g. thrown on a real board)
                    "textsize": "normal",   # phones: "large" makes the column, menus and coach text bigger
                    "autorace": False,   # on: once there is no contact, the coach plays your moves for you
                    "whostarts": "turns",   # "turns": the other side starts each new game; "rolloff": one die each
                    "cube": False,       # on: play with the doubling cube
                    "showundo": True,    # off: no UNDO / REDO buttons (play without take-backs)
                    "twoplayer": False}  # on: two people play each other on this screen (no computer opponent)
COACH_MODES = ["hints", "review", "off"]   # the C key / COACH button cycles through these

def coach_mode(game):
    return "hints" if game.coaching else ("review" if game.review else "off")

def verdict_shown(game):
    """Hints hidden (coach on HINTS): the verdict on your last move still shows - good or not - but no hints."""
    return game.hints_hidden() and game.coach.get("kind") in ("good", "critique")

def chosen_coach_mode(game):
    """Your coach setting, even while HINT/HIDE has changed it for this turn."""
    if game.hint_saved is None: return coach_mode(game)
    return "hints" if game.hint_saved[0] else ("review" if game.hint_saved[1] else "off")

def set_coach_mode(game, mode):
    """hints: arrows, plan and comments.  review: no hints, a verdict on your whole play when the turn ends.  off: neither."""
    game.coaching, game.review, game.autoplay = mode == "hints", mode == "review", False
    game.hint_saved = None   # a deliberate change of mode replaces any HINT that was showing
OPP_LEVELS = ["easy", "intermediate", "strong"]   # the O key / OPPONENT button cycles through these

def settings_path():
    return os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "BackgammonCoach", "settings.json")

DEFAULT_PLAYER = "Player 1"

def load_store():
    """Everything saved: {'player': who is playing, 'players': {name: settings}, 'scores': {name: {'match', 'session'}}}.
    A file from before players existed holds one person's settings: they become Player 1's."""
    try:
        if WEB: raw = json.loads(js("localStorage.getItem('bgcoach') || '{}'"))   # the web has no lasting files
        else:
            with open(settings_path(), encoding="utf-8") as f: raw = json.load(f)
    except Exception: raw = {}
    if not isinstance(raw.get("players"), dict):
        raw = {"player": DEFAULT_PLAYER, "players": {DEFAULT_PLAYER: raw} if raw else {}}
    raw.setdefault("player", DEFAULT_PLAYER); raw.setdefault("scores", {})
    return raw

def write_store(store):
    try:
        if WEB: js(f"localStorage.setItem('bgcoach', {json.dumps(json.dumps(store))})"); return
        os.makedirs(os.path.dirname(settings_path()), exist_ok=True)
        with open(settings_path(), "w", encoding="utf-8") as f: json.dump(store, f, indent=2)
    except Exception: pass   # settings are a convenience; never stop the game over them

def load_settings(name=None):
    """A player's settings (default: whoever played last), with defaults for anything not saved yet."""
    store = load_store()
    saved = dict(store["players"].get(name or store["player"], {}))
    if "coach_mode" not in saved and "coaching" in saved:   # settings saved before REVIEW existed: on/off switch
        saved["coach_mode"] = "hints" if saved.pop("coaching") else "off"
    saved.pop("coaching", None)
    return {**DEFAULT_SETTINGS, **saved}

def save_settings(settings, name=None):
    store = load_store(); name = name or store["player"]
    store["players"][name], store["player"] = settings, name
    write_store(store)

def load_scores(name):
    """A player's (games won [you, opponent], coach score [matched, moves])."""
    s = load_store()["scores"].get(name, {})
    return list(s.get("match", [0, 0])), list(s.get("session", [0, 0]))

def save_scores(name, match, session):
    store = load_store()
    store["scores"][name] = {"match": list(match), "session": list(session)}
    write_store(store)

def load_dice(name):
    """A player's dice totals over their finished games against the computer: [[you], [opponent]]."""
    d = load_store().get("dice", {}).get(name)
    return [list(d[0]), list(d[1])] if d else [[0, 0, 0, 0], [0, 0, 0, 0]]

def save_dice(name, totals):
    store = load_store()
    store.setdefault("dice", {})[name] = [list(totals[0]), list(totals[1])]
    write_store(store)

TWO_PLAYERS = " (2 players)"   # a player's two-player game is kept under their name + this, apart from their own

def player_names():
    """Everyone who has played on this device, the current player first."""
    store = load_store()
    return [store["player"]] + sorted(n for n in store["players"] if n != store["player"])

def switch_player(name):
    """Make name the current player (a new name starts with the default settings)."""
    store = load_store()
    store["players"].setdefault(store["player"], dict(DEFAULT_SETTINGS))   # the one leaving stays on the list
    store["player"] = name; store["players"].setdefault(name, dict(DEFAULT_SETTINGS))
    write_store(store)

def add_history(name, record):
    """A finished game, for the player's progress (the last 100 are kept)."""
    store = load_store()
    store.setdefault("history", {}).setdefault(name, []).append(record)
    store["history"][name] = store["history"][name][-100:]
    write_store(store)

def load_history(name):
    return load_store().get("history", {}).get(name, [])

def load_game(name):
    """A player's unfinished game (Engine.snapshot()), or None."""
    return load_store().get("games", {}).get(name)

def save_game(name, snap):
    """Keep a player's game in progress (None: there is none, e.g. it just ended)."""
    store = load_store(); games = store.setdefault("games", {})
    if snap is None: games.pop(name, None)
    else: games[name] = snap
    write_store(store)

def remove_player(name):
    """Forget a player: settings, scores, game and history. Returns who plays next (Player 1 if nobody is left)."""
    store = load_store()
    for part in ("players", "scores", "games", "history", "dice"): store.get(part, {}).pop(name, None)
    store.get("games", {}).pop(name + TWO_PLAYERS, None)
    store["player"] = sorted(store["players"])[0] if store["players"] else DEFAULT_PLAYER
    write_store(store)
    return store["player"]

def rename_player(old, new):
    store = load_store()
    store["players"][new] = store["players"].pop(old, dict(DEFAULT_SETTINGS))
    for part in ("scores", "games", "history", "dice"):
        if old in store.get(part, {}): store[part][new] = store[part].pop(old)
    if old + TWO_PLAYERS in store.get("games", {}): store["games"][new + TWO_PLAYERS] = store["games"].pop(old + TWO_PLAYERS)
    store["player"] = new
    write_store(store)

SOUND_RATE = 22050

def synth(parts, dur):
    """Short sound mixed from decaying tones (freq in Hz) or noise (freq None): parts = [(start s, freq, decay s, volume)]."""
    n, rnd = int(SOUND_RATE * dur), random.Random(7)
    buf = [0.0] * n
    for start, freq, decay, vol in parts:
        s0 = int(start * SOUND_RATE)
        for k in range(s0, min(n, s0 + int(decay * 6 * SOUND_RATE))):
            t = (k - s0) / SOUND_RATE
            buf[k] += vol * math.exp(-t / decay) * (math.sin(2 * math.pi * freq * t) if freq else rnd.uniform(-1, 1))
    return to_sound(buf)

def to_sound(buf):
    """Samples (any scale) -> a pygame Sound, as loud as it can be without clipping."""
    scale = 30000 / max(1.0, max(abs(v) for v in buf))
    channels = (pygame.mixer.get_init() or (0, 0, 1))[2]
    data = array.array('h', (int(v * scale) for v in buf for _ in range(channels)))
    return pygame.mixer.Sound(buffer=data.tobytes())

def dice_roll_wave(seed=None):
    """Two dice thrown onto a wooden board, as samples: each lands, bounces with shorter and shorter gaps, then
    tumbles over a few times and stops. Every impact is a bright 'tock' (hard plastic) over a soft thud (the board),
    a little different each time, and the room adds two faint echoes."""
    rnd, dur = random.Random(seed), 0.95
    n = int(SOUND_RATE * dur); buf = [0.0] * n
    def impact(t, vol, bright):
        s0 = int(t * SOUND_RATE)
        for freq, decay, v in ((rnd.uniform(2600, 4200) * bright, 0.006, 0.55), (rnd.uniform(1300, 1900) * bright, 0.012, 0.45),
                               (rnd.uniform(160, 240), 0.035, 0.5)):
            # a decaying tone, one complex multiplication per sample (cheap enough for phones)
            ph, w = rnd.uniform(0, 2 * math.pi), 2 * math.pi * freq / SOUND_RATE
            z, step = complex(math.cos(ph), math.sin(ph)) * vol * v, math.exp(-1 / (decay * SOUND_RATE)) * complex(math.cos(w), math.sin(w))
            for k in range(s0, min(n, s0 + int(decay * 5 * SOUND_RATE))):
                buf[k] += z.imag; z *= step
        soft, fade = 0.0, 1.0   # the click itself: a few milliseconds of softened noise
        for k in range(s0, min(n, s0 + int(0.004 * SOUND_RATE))):
            soft = 0.5 * soft + 0.5 * rnd.uniform(-1, 1); buf[k] += vol * 0.6 * soft * fade; fade *= 0.96
    for die in range(2):
        t, gap, vol = 0.02 + die * rnd.uniform(0.02, 0.05), rnd.uniform(0.11, 0.14), 1.0
        while gap > 0.018:                          # bouncing: each bounce lower and sooner
            impact(t, vol, rnd.uniform(0.85, 1.15))
            t += gap * rnd.uniform(0.85, 1.15); gap *= 0.68; vol *= 0.72
        for _ in range(rnd.randint(3, 5)):          # tumbling over before it settles
            t += rnd.uniform(0.03, 0.06)
            if t < dur - 0.05: impact(t, vol * rnd.uniform(0.3, 0.6), rnd.uniform(0.7, 0.9))
    for delay, gain in ((0.021, 0.22), (0.037, 0.12)):   # the room
        d = int(delay * SOUND_RATE)
        for k in range(n - 1, d - 1, -1): buf[k] += gain * buf[k - d]
    return buf

def make_sounds():
    """Wooden 'clack' sounds for moves, hits, dice and invalid clicks. {} if there is no audio device."""
    if not getattr(pygame, "mixer", None) or not pygame.mixer.get_init(): return {}
    clack = lambda t, v=1.0, p=1.0: [(t, None, 0.004, 0.6 * v), (t, 1900 * p, 0.018, 0.5 * v), (t, 650 * p, 0.03, 0.6 * v)]
    sounds = {'move': synth(clack(0), 0.15),
              'hit': synth(clack(0, 1.0, 0.9) + [(0, 150, 0.07, 0.7)] + clack(0.06, 0.8, 0.75), 0.3),
              'rolls': [to_sound(dice_roll_wave(seed)) for seed in (1, 2, 3)],   # a different throw each time
              'invalid': synth([(0, 180, 0.06, 0.5), (0, 90, 0.08, 0.4)], 0.25)}
    for s in [v for v in sounds.values() if not isinstance(v, list)] + sounds['rolls']: s.set_volume(0.6)
    return sounds

def dpi_scale():
    """Make the process DPI-aware on Windows (so Windows doesn't blur-stretch the window) and return the scale (1.0 = 96 dpi)."""
    if sys.platform != "win32": return 1.0
    try:
        import ctypes
        try: ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception: ctypes.windll.user32.SetProcessDPIAware()
        return ctypes.windll.user32.GetDpiForSystem() / 96
    except Exception: return 1.0

def work_area():
    """Screen area not covered by the taskbar, in physical pixels (Windows only; None elsewhere)."""
    if sys.platform != "win32": return None
    try:
        import ctypes, ctypes.wintypes
        r = ctypes.wintypes.RECT()
        ctypes.windll.user32.SystemParametersInfoW(0x30, 0, ctypes.byref(r), 0)  # SPI_GETWORKAREA
        return (r.left, r.top, r.right - r.left, r.bottom - r.top)
    except Exception: return None

def title_bar_size():
    """(height above the client area, border width) of a normal window, in physical pixels."""
    u = __import__("ctypes").windll.user32
    border = u.GetSystemMetrics(33) + u.GetSystemMetrics(92)   # SM_CYSIZEFRAME + SM_CXPADDEDBORDER
    return u.GetSystemMetrics(4) + border, border                # SM_CYCAPTION

async def main():   # async so the same loop runs in a web browser (pygbag), which needs a pause every frame
    global roll_snd
    k = dpi_scale()
    area = work_area()   # (left, top, width, height) the window must fit in, title bar and borders included
    if area:
        x0, y0, aw, ah = area
        top, side = title_bar_size()
        k = max(0.5, min(k, (aw - 2*side) / WIDTH, (ah - top - side) / HEIGHT))
        w, h = round(WIDTH * k), round(HEIGHT * k)
        os.environ["SDL_VIDEO_WINDOW_POS"] = f"{x0 + (aw - w) // 2},{y0 + top + (ah - top - side - h) // 2}"
    try:   # the web build of pygame loads its sound module separately, and a computer may have no sound at all
        importlib.import_module("pygame.mixer")
        pygame.mixer.pre_init(SOUND_RATE, -16, 1, 512)
    except Exception: pass
    pygame.init()
    if not area:
        info = pygame.display.Info()
        k = max(0.5, min(k, info.current_w * 0.95 / WIDTH, info.current_h * 0.85 / HEIGHT))
    phone = os.environ.get("BG_LAYOUT") == "phone" or (WEB and web_wants_phone_layout())
    if WEB: screen = pygame.display.set_mode(web_screen_size())   # fill the browser window
    elif phone: screen = pygame.display.set_mode((1170, 540), pygame.RESIZABLE)   # BG_LAYOUT=phone: preview the phone layout
    else: screen = pygame.display.set_mode((round(WIDTH * k), round(HEIGHT * k)), pygame.RESIZABLE)   # resizable: maximise works
    if WEB:
        js(WEB_INPUT_JS)
        web_fit_canvas()
    pygame.display.set_caption("Backgammon Coach")
    if find_file("icon.png"): pygame.display.set_icon(pygame.image.load(find_file("icon.png")))
    game, view = Engine(), UI(screen, k); clock = pygame.time.Clock()
    if phone or WEB: view.layout = 'phone' if phone else 'desktop'; view.resize(screen)
    try: view.sounds = make_sounds()
    except Exception: view.sounds = {}
    try: roll_snd = pygame.mixer.Sound(find_file("dice_roll.wav"))   # your own recording wins if present
    except Exception: roll_snd = None   # otherwise one of the made-up throws, a different one each time
    player = load_store()["player"]   # who played last; settings and scores are kept per player
    settings = load_settings(player)

    def apply_settings():
        set_coach_mode(game, settings["coach_mode"] if settings["coach_mode"] in COACH_MODES else "hints")
        view.sound_on = bool(settings["sound"])
        game.opp_level = settings["opponent"] if settings["opponent"] in OPP_LEVELS else "strong"
        set_rules("standard" if settings["rules"] == "standard" else "egyptian")
        set_home_side("left" if settings["home"] == "left" else "right")
        game.autoroll, game.auto_forced = bool(settings["autoroll"]), bool(settings["autoforced"])
        game.opp_arrows, game.auto_race = bool(settings["opparrows"]), bool(settings["autorace"])
        game.who_starts = "rolloff" if settings["whostarts"] == "rolloff" else "turns"
        if settings["hidehints"] and game.coaching: game.hint_saved, game.coaching = (True, False), False
        view.own_dice = bool(settings["owndice"])
        view.text_scale = 1.25 if settings["textsize"] == "large" else 1.0
        game.cube_on, game.two_player = bool(settings["cube"]), bool(settings["twoplayer"])
        view.show_undo = bool(settings["showundo"])
        set_cube_layout(game.cube_on)
        if view.layout == 'phone': view.resize(view.screen)

    def show_player():
        view.player, view.players = player, player_names()
        pygame.display.set_caption(f"Backgammon Coach - {player}")

    def game_key():
        """Where the game in progress is kept: the player's own game, or their two-player game."""
        return player + TWO_PLAYERS if game.two_player else player

    def resume():
        """Carry on with this player's unfinished game (or two-player game), if there is one."""
        snap = load_game(game_key())
        if snap:
            try: game.restore(snap)
            except Exception: game.new_game()   # saved by an older version: start afresh rather than stop

    apply_settings()
    resume()
    game.match, game.session = load_scores(player)
    game.dice_done = load_dice(player)
    saved_scores, saved_dice = (list(game.match), list(game.session)), [list(s) for s in game.dice_done]
    show_player()

    def use_player(name, keep_old=True):
        """Switch to another player (or a new one): their settings, scores and unfinished game (or a fresh one)."""
        nonlocal player, saved_scores, saved_dice
        if keep_old: save_scores(player, game.match, game.session); save_dice(player, game.dice_done)
        player = name; switch_player(name)
        settings.clear(); settings.update(load_settings(name))
        view.reviewing = None
        game.new_game(); apply_settings(); resume()
        game.match, game.session = load_scores(name)
        game.dice_done = load_dice(name)
        saved_scores, saved_dice = (list(game.match), list(game.session)), [list(s) for s in game.dice_done]
        show_player()

    def got_name(name, purpose):
        nonlocal player
        name = " ".join(name.split())[:20]
        if not name or name == player: return
        if purpose == "rename" and name not in player_names():
            save_scores(player, game.match, game.session); rename_player(player, name); player = name; show_player()
        else: use_player(name)   # a new name, or one already on the list: switch to them

    def ask_name(title, purpose):
        """Phones and browsers: their own text box (and on-screen keyboard). Laptop: type into the game."""
        if WEB: got_name(js(f"(window.prompt({json.dumps(title)}, '') || '')"), purpose)
        else:
            view.entry = {"title": title, "text": "", "purpose": purpose}
            pygame.key.start_text_input()

    def player_action(act):
        """A choice on the player list."""
        view.overlay = None
        if isinstance(act, tuple): use_player(act[1]) if act[1] != player else None
        elif act == "newplayer": ask_name("New player's name:", "new")
        elif act == "rename": ask_name(f"New name for {player}:", "rename")
        elif act == "removeplayer":   # asks twice
            if time.time() < view.remove_until: view.remove_until = 0.0; use_player(remove_player(player), keep_old=False)
            else: view.remove_until, view.overlay = time.time() + 3, 'players'

    def leave_practice():
        """Back to the game you were playing before the puzzles (or a fresh one)."""
        game.new_game(); resume()

    def toggle(name):
        """Flip a preference (coaching, sound, opponent strength, rules) and remember it for next time."""
        if name == "coaching":
            current = chosen_coach_mode(game)
            settings["coach_mode"] = COACH_MODES[(COACH_MODES.index(current) + 1) % len(COACH_MODES)]
            set_coach_mode(game, settings["coach_mode"]); settings["hidehints"] = False   # a new mode shows as chosen
        elif name == "sound": view.sound_on = not view.sound_on; settings[name] = view.sound_on
        elif name == "autoroll": game.autoroll = settings[name] = not game.autoroll
        elif name == "autoforced": game.auto_forced = settings[name] = not game.auto_forced
        elif name == "autorace": game.auto_race = settings[name] = not game.auto_race
        elif name == "whostarts":
            game.who_starts = settings[name] = "turns" if game.who_starts == "rolloff" else "rolloff"
            game.starts_changed()
        elif name == "opparrows": game.opp_arrows = settings[name] = not game.opp_arrows
        elif name == "cube":   # a cube already doubled in this game stays in play until the game ends
            game.cube_on = settings[name] = not game.cube_on
            set_cube_layout(game.cube_on)
            game.coach = {**game.coach, 'status': game.roll_status()} if game.phase == 'white_roll' and not game.opening else game.coach
        elif name == "twoplayer":   # each kind of game is kept: switching back carries on where it was
            if game.practice is None and not game.is_rolling and not game.what_if:
                save_game(game_key(), None if game.phase == 'over' else game.snapshot())
            game.two_player = settings[name] = not game.two_player
            view.reviewing = None
            game.new_game(); resume()
        elif name == "owndice": view.own_dice = settings[name] = not view.own_dice
        elif name == "showundo": view.show_undo = settings[name] = not view.show_undo
        elif name == "textsize":
            settings[name] = "normal" if view.text_scale > 1 else "large"
            view.text_scale = 1.25 if settings[name] == "large" else 1.0
            view.resize(view.screen)
        elif name == "home":
            settings[name] = "left" if HOME_RIGHT else "right"
            set_home_side(settings[name])
        elif name == "rules":
            settings[name] = "standard" if egyptian() else "egyptian"
            set_rules(settings[name]); game.rules_changed()
        else: game.opp_level = settings[name] = OPP_LEVELS[(OPP_LEVELS.index(game.opp_level) + 1) % len(OPP_LEVELS)]
        save_settings(settings)

    def roll_sound():
        snd = roll_snd or (random.choice(view.sounds['rolls']) if view.sounds.get('rolls') else None)
        if snd and view.sound_on: snd.play()

    def begin_roll():
        """Your roll: tap in your own dice (if chosen in the menu), or throw them."""
        if view.own_dice: view.overlay, view.dice_pick = 'dice', []
        else: game.start_rolling('white'); roll_sound()

    def go():
        """SPACE: roll, hand the turn over, or start the next game - whichever fits. Never plays your moves for you,
        and never answers a double (TAKE and PASS are their own buttons)."""
        nonlocal my_roll_at
        if game.practice is not None:
            if game.phase == 'white_done': game.start_puzzle(game.practice + 1)   # puzzles: the next one
        elif game.can_roll(): begin_roll()
        elif game.can_hand_over():
            game.hand_over()
            if game.is_rolling: roll_sound()   # (not when the computer doubles first)
            if game.two_player and game.autoroll and not game.can_double(): my_roll_at = time.time() + 0.9
        elif game.phase == 'over': game.new_game()

    def big_button():
        """The big button follows its label: PLAY PLAN during your move (like Enter), TAKE when you've been doubled,
        otherwise the same as SPACE."""
        if game.phase == 'cube_offer': answer_double(True)
        elif game.can_accept_plan(): game.accept_plan()
        else: go()

    def answer_double(take):
        """TAKE or PASS a double (the computer's, or the other player's)."""
        if take: game.take()
        else: game.pass_double()
        if game.is_rolling: roll_sound()   # you took the computer's double: it rolls

    def small_button():
        """The laptop's UNDO button is DOUBLE before you roll (cube on) and PASS when you've been doubled."""
        act = cube_action(game)
        if act == 'pass': answer_double(False)
        elif act == 'double': game.double()
        elif view.show_undo: game.undo()

    def step_review(act):
        """Stepping through this game's mistakes: NEXT, BACK, or MENU / Esc when done."""
        if act == 'go': view.reviewing = view.reviewing + 1 if view.reviewing + 1 < len(game.mistakes) else None
        elif act == 'undo': view.reviewing = max(0, view.reviewing - 1)
        elif act == 'menu': view.reviewing = None
        elif act == 'details': view.overlay = 'details'   # the whole explanation

    def do(act):
        """What a tap or click does: a button, a menu row or a choice in a list."""
        nonlocal auto_next, opp_next
        if isinstance(act, tuple):
            kind, value = act
            if kind == 'pick': player_action(act)
            elif kind == 'die':   # Enter your own dice: two taps, then they are your roll
                view.dice_pick.append(value)
                if len(view.dice_pick) == 2:
                    view.overlay = None
                    game.start_rolling('white'); game.finish_roll(*view.dice_pick); roll_sound()
                    if game.opening_wait: game.play_opening_wait()
                    auto_next = opp_next = time.time() + 1.5   # opp_next: it may have won the opening roll
            elif kind == 'mistake': view.overlay, view.reviewing = None, value
            elif kind == 'puzzle': view.overlay = None; game.start_puzzle(value)
            return
        if act == 'close': view.overlay, view.confirm_until = None, 0.0
        elif act == 'nextpage': view.page_no += 1
        elif act == 'player': view.overlay = 'players'
        elif act in ('menu', 'details', 'mistakes', 'practice'): view.overlay, view.page_no = act, 0
        elif act in ('progress', 'dicestats', 'cubehelp'):   # pages of text
            view.page_title = {'progress': "Your progress", 'dicestats': "Dice statistics", 'cubehelp': "How the doubling cube works"}[act]
            view.progress = (progress_text(load_history(player), game) if act == 'progress'
                             else dice_stats_text(game) if act == 'dicestats' else list(CUBE_HELP))
            view.overlay, view.page_no = 'progress', 0
        elif act == 'double': game.double()
        elif act == 'pass': answer_double(False)
        elif act in ('newplayer', 'rename', 'removeplayer'): player_action(act)
        elif act == 'leavepractice': view.overlay = None; leave_practice()
        elif act == 'go': big_button()
        elif act == 'undo': game.undo()
        elif act == 'redo': game.redo()
        elif act == 'whatif': view.overlay = None; game.toggle_what_if()
        elif act == 'hint':
            game.show_hint()
            if settings['hidehints'] != game.hints_hidden(): settings['hidehints'] = game.hints_hidden(); save_settings(settings)
        elif act == 'new':
            asking = view.confirming(); view.request_new_game(game)
            if asking: view.overlay = None
        elif act: toggle(act)

    def press(px, button):
        """A click or tap at screen position px: the mistake on show, an open overlay or the phone's column first.
        button 5: Android's Back button (web): opens the menu, or closes whatever is open."""
        nonlocal auto_next
        if view.entry: return   # typing a name: Enter or Esc first
        if button == 5:
            if view.reviewing is not None: view.reviewing = None
            elif view.layout == 'phone': view.overlay, view.confirm_until = (None if view.overlay else 'menu'), 0.0
            return
        pos = view.to_logical(px)
        if view.reviewing is not None:
            if view.overlay: view.overlay = None; return   # closing the explanation
            if view.layout == 'phone': act = view.phone_tap(px, game)
            else: act = next((a for r, a in ((view.btn_r, 'go'), (view.btn_u, 'undo'), (view.btn_menu, 'menu')) if r.collidepoint(pos)), None)
            step_review(act); return
        if view.layout == 'phone' or view.overlay:
            act = view.phone_tap(px, game) if view.layout == 'phone' else view.desk_tap(pos, game)
            if act: do(act); return
            if view.overlay: return
        pt = board_pt(game, pos)   # (two players: turned round while Black moves)
        if button == 3 and pt is not None: game.auto_move(pt)
        elif button == 4:   # drop at the end of a drag: move the checker picked up where the drag started
            if pt is not None and game.selected is not None and pt != game.selected:
                game.click(pt)
                if game.queue: auto_next = time.time() + 0.3
        elif button == 1:
            if view.layout != 'phone':
                for rect, action in ((view.btn_r, big_button), (view.btn_u, small_button),
                                     (view.btn_redo, game.redo if view.show_undo else (lambda: None)),
                                     (view.btn_coach, lambda: toggle("coaching")), (view.btn_sound, lambda: toggle("sound")),
                                     (view.btn_opp, lambda: toggle("opponent")), (view.btn_rules, lambda: toggle("rules")),
                                     (view.btn_home, lambda: toggle("home")), (view.btn_auto, lambda: toggle("autoroll")),
                                     (view.btn_menu, lambda: do('menu')),
                                     (view.btn_new, lambda: view.request_new_game(game))):
                    if rect.collidepoint(pos): action(); return
            if cube_hit(game, pos) and game.can_double(): game.double(); return   # tapping the cube doubles
            v = die_at(game, pos)
            if v is not None and game.choose_die(v): return   # picked a die (or moved the checker picked up by it)
            if pt is not None:
                game.click(pt)
                if game.queue: auto_next = time.time() + 0.3   # let the first hop finish sliding

    opp_next, my_roll_at, auto_next = 0.0, 0.0, 0.0   # when the opponent's / PLAY PLAN's next move is due; when your dice roll
    size_check = 0.0                                  # web: when to next check whether the browser window changed size
    drag_from = None                                  # desktop: where the left button went down (for drag and drop)
    saved_key = None                                  # the game as last saved (to carry on after the app is closed)
    while True:
        now = time.time()
        if view.reviewing is not None: pass   # looking at a mistake: the game waits
        elif game.is_rolling:
            if now - game.roll_start < 0.6:
                dice = [random.randint(1,6), random.randint(1,6)]
                if game.opening: game.display_dice, game.opp_display = dice[:1], dice[1:]   # one die each side
                elif game.rolling_for == 'white': game.display_dice = dice
                else: game.opp_display = dice
            elif game.rolling_for == 'white':
                game.finish_roll(random.randint(1,6), random.randint(1,6)); auto_next = opp_next = now + 1.5   # see the dice first
            else: game.opp_roll_done(random.randint(1,6), random.randint(1,6)); opp_next = now + 1.2   # see its dice first
        elif game.phase == 'opening' and now >= opp_next:   # you won the opening roll: after a look at both dice, your move
            game.play_opening_wait(); auto_next = now + 1.0
        elif game.phase == 'black' and now >= opp_next:   # the opponent plays one move at a time so you can follow it
            if not game.opp_step() and game.phase == 'black':   # AUTO-ROLL off, or you may double: wait for you
                game.opp_finish(); my_roll_at = (now + 0.9) if game.autoroll and not game.can_double() else 0.0
            opp_next = now + ANIM_SLOW + 0.7   # slide, then a pause to take it in
        elif now >= auto_next and game.wants_forced_move():   # only one way left to play the dice: play it
            game.play_forced_step(); auto_next = now + ANIM_SLOW + 1.0   # slide, then a pause to take it in
        elif now >= auto_next and game.wants_race_move():     # Auto-play the race: the coach's move, slowly
            game.play_race_step(); auto_next = now + ANIM_SLOW + 1.0
        elif game.queue and now >= auto_next:      # the rest of a one-go move (13/9/8), one hop at a time
            game.play_queued(); auto_next = now + 0.3
        elif game.autoplay and now >= auto_next:   # PLAY PLAN: one coach move at a time, like the opponent
            game.autoplay_step(); auto_next = now + 0.6
        elif game.phase == 'white_roll' and my_roll_at and now >= my_roll_at and not game.opening:   # the opening roll waits for you
            my_roll_at = 0.0
            begin_roll()
        for e in pygame.event.get():
            if e.type == pygame.QUIT: return
            if e.type in (pygame.VIDEORESIZE, pygame.WINDOWSIZECHANGED): view.resize(pygame.display.get_surface())
            if view.entry:   # typing a name: letters go into it, not to the shortcuts
                if e.type == pygame.TEXTINPUT: view.entry['text'] = (view.entry['text'] + e.text)[:20]
                elif e.type == pygame.KEYDOWN and e.key == pygame.K_BACKSPACE: view.entry['text'] = view.entry['text'][:-1]
                elif e.type == pygame.KEYDOWN and e.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_ESCAPE):
                    entry, view.entry = view.entry, None
                    if e.key != pygame.K_ESCAPE: got_name(entry['text'], entry['purpose'])
                continue
            if e.type == pygame.KEYDOWN and view.reviewing is not None:
                step_review({pygame.K_SPACE: 'go', pygame.K_RIGHT: 'go', pygame.K_BACKSPACE: 'undo', pygame.K_LEFT: 'undo',
                             pygame.K_ESCAPE: 'menu'}.get(e.key)); continue
            if e.type == pygame.KEYDOWN and view.overlay:
                if view.overlay == 'dice' and pygame.K_1 <= e.key <= pygame.K_6: do(('die', e.key - pygame.K_0)); continue
                if e.key == pygame.K_ESCAPE: view.overlay = None; continue
            if e.type == pygame.KEYDOWN:
                ctrl, shift = e.mod & pygame.KMOD_CTRL, e.mod & pygame.KMOD_SHIFT
                if e.key == pygame.K_SPACE: go()
                elif e.key in (pygame.K_RETURN, pygame.K_KP_ENTER): game.accept_plan()
                elif e.key == pygame.K_r and not ctrl: toggle("rules")
                elif e.key == pygame.K_h and not ctrl: toggle("home")
                elif e.key == pygame.K_a and not ctrl: toggle("autoroll")
                elif e.key == pygame.K_m and not ctrl: toggle("opparrows")   # the opponent's Moves as arrows
                elif e.key == pygame.K_w and not ctrl: game.toggle_what_if()
                elif e.key == pygame.K_d and not ctrl: game.double()
                elif e.key == pygame.K_t and not ctrl and game.phase == 'cube_offer': answer_double(True)
                elif e.key == pygame.K_p and not ctrl and game.phase == 'cube_offer': answer_double(False)
                elif ctrl and e.key == pygame.K_z and view.show_undo: game.redo() if shift else game.undo()
                elif ctrl and e.key == pygame.K_y and view.show_undo: game.redo()
                elif e.key == pygame.K_c and not ctrl: toggle("coaching")
                elif e.key == pygame.K_s and not ctrl: toggle("sound")
                elif e.key == pygame.K_o and not ctrl: toggle("opponent")
                elif e.key == pygame.K_n and not ctrl: view.request_new_game(game)
                elif e.key == pygame.K_y and view.confirming(): view.request_new_game(game, confirm=True)
                elif e.key == pygame.K_ESCAPE: view.confirm_until = 0.0
            if e.type == pygame.MOUSEBUTTONDOWN and not WEB:   # the web uses the page's presses
                press(e.pos, e.button)
                if e.button == 1: drag_from = e.pos
            if e.type == pygame.MOUSEBUTTONUP and not WEB and e.button == 1 and drag_from:
                if math.dist(drag_from, e.pos) > 12: press(e.pos, 4)   # dragged a checker: drop it here
                drag_from = None
        if WEB:
            w, h = screen.get_size()
            for fx, fy, button in web_presses(): press((fx * w, fy * h), button)
            if now >= size_check:   # rotated the phone or resized the browser window
                size_check = now + 0.5
                if web_screen_size() != (w, h): screen = pygame.display.set_mode(web_screen_size()); view.resize(screen)
                web_fit_canvas()   # every check: pygbag may reset the on-page size after a rotation
        if game.phase != 'white_roll' or game.opening: my_roll_at = 0.0   # e.g. New Game during the opponent's turn
        if (game.match, game.session) != saved_scores:   # games won and coach score, kept per player
            save_scores(player, game.match, game.session); saved_scores = (list(game.match), list(game.session))
        if game.finished: add_history(player, game.finished); game.finished = None   # for Your progress
        if game.dice_done != saved_dice: save_dice(player, game.dice_done); saved_dice = [list(s) for s in game.dice_done]
        if game.practice is None and not game.is_rolling and not game.what_if:   # keep the game to carry on later
            key = (game_key(), game.move_seq, game.phase, tuple(game.dice), tuple(game.display_dice), game.cube, game.flipped)
            if key != saved_key: save_game(game_key(), None if game.phase == 'over' else game.snapshot()); saved_key = key
        view.render(game, get_sug(game)); pygame.display.flip(); clock.tick(30 if WEB else 60)   # 30 fps saves phone battery
        await asyncio.sleep(0)   # lets the browser draw and handle input

if __name__ == "__main__": asyncio.run(main())
